# Documentação do Photo Booth

## Visão Geral
Este é um aplicativo web simples de Photo Booth que permite aos usuários:
- Capturar fotos usando a câmera do dispositivo
- Aplicar uma moldura decorativa à foto
- Tirar fotos com contagem regressiva de 3 segundos
- Visualizar a foto capturada
- Acessar a foto através de um QR code
- Visualizar todas as fotos capturadas em uma área administrativa

## Estrutura do Projeto
```
photo_booth/
├── venv/                  # Ambiente virtual Python
├── src/                   # Código-fonte do aplicativo
│   ├── main.py            # Arquivo principal do Flask
│   ├── static/            # Arquivos estáticos
│   │   ├── css/           # Estilos CSS
│   │   │   └── style.css  # Arquivo de estilo principal
│   │   ├── js/            # Scripts JavaScript
│   │   │   └── camera.js  # Lógica da câmera e captura
│   │   └── images/        # Imagens
│   │       ├── frame.png  # Moldura para as fotos
│   │       ├── uploads/   # Fotos capturadas (criada automaticamente)
│   │       └── qrcodes/   # QR codes gerados (criada automaticamente)
│   └── templates/         # Templates HTML
│       ├── index.html     # Página principal de captura
│       └── admin.html     # Página administrativa
└── todo.md                # Lista de tarefas do projeto
```

## Requisitos
- Python 3.x
- Flask
- Pillow (PIL)
- qrcode

## Instalação
1. Clone ou baixe este repositório
2. Crie um ambiente virtual Python:
   ```
   python -m venv venv
   ```
3. Ative o ambiente virtual:
   - Windows: `venv\Scripts\activate`
   - Linux/Mac: `source venv/bin/activate`
4. Instale as dependências:
   ```
   pip install flask pillow qrcode
   ```

## Execução
1. Ative o ambiente virtual (se ainda não estiver ativado)
2. Execute o aplicativo:
   ```
   cd src
   python main.py
   ```
3. Acesse o aplicativo em seu navegador:
   ```
   http://localhost:5000
   ```

## Funcionalidades

### Página Principal (Captura)
- Acessa a câmera do dispositivo
- Exibe uma moldura decorativa sobre a imagem da câmera
- Botão "Tirar Foto" inicia uma contagem regressiva de 3 segundos
- Após a contagem, captura a foto e a exibe na tela
- Gera um QR code para acesso à foto
- Botão "Nova Foto" permite capturar outra imagem

### Página Administrativa
- Lista todas as fotos capturadas
- Exibe a data e hora de cada captura
- Permite visualizar a foto em tamanho completo
- Permite visualizar o QR code de cada foto

## API Endpoints

### POST /api/upload
- Recebe uma imagem em base64
- Salva a imagem no servidor
- Gera um QR code para acesso à foto
- Retorna URLs para a foto e o QR code

### GET /api/photos
- Lista todas as fotos capturadas
- Retorna informações como nome do arquivo, URL, timestamp e URL do QR code

### GET /photo/<filename>
- Retorna uma foto específica

### GET /qrcode/<filename>
- Retorna um QR code específico

## Personalização
- Para alterar a moldura, substitua o arquivo `src/static/images/frame.png`
- Para modificar o estilo visual, edite o arquivo `src/static/css/style.css`
- Para alterar o comportamento da câmera, edite o arquivo `src/static/js/camera.js`

## Considerações para Produção
- Em ambiente de produção, configure um servidor web como Nginx ou Apache
- Configure o Flask para usar um servidor WSGI como Gunicorn
- Considere usar um serviço de armazenamento externo para as imagens em caso de alto volume
- Implemente autenticação para a área administrativa se necessário
