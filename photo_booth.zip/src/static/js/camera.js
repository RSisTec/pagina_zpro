// Variáveis globais
let videoStream;
let video;
let canvas;
let captureBtn;
let newPhotoBtn;
let countdownElement;
let resultContainer;
let capturedPhotoElement;
let qrcodeElement;
let statusMessage;

// Inicialização quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', () => {
    // Elementos do DOM
    video = document.getElementById('camera');
    canvas = document.getElementById('canvas');
    captureBtn = document.getElementById('capture-btn');
    newPhotoBtn = document.getElementById('new-photo-btn');
    countdownElement = document.getElementById('countdown');
    resultContainer = document.getElementById('result-container');
    capturedPhotoElement = document.getElementById('captured-photo');
    qrcodeElement = document.getElementById('qrcode');
    statusMessage = document.getElementById('status-message');

    // Iniciar a câmera
    initCamera();

    // Event listeners
    captureBtn.addEventListener('click', startCountdown);
    newPhotoBtn.addEventListener('click', resetCamera);
});

// Função para iniciar a câmera
async function initCamera() {
    try {
        // Solicitar acesso à câmera
        videoStream = await navigator.mediaDevices.getUserMedia({
            video: {
                width: { ideal: 1280 },
                height: { ideal: 720 },
                facingMode: 'user'
            },
            audio: false
        });

        // Conectar o stream ao elemento de vídeo
        video.srcObject = videoStream;
        
        // Exibir mensagem de sucesso
        showStatus('Câmera iniciada com sucesso!', 'success');
    } catch (error) {
        console.error('Erro ao acessar a câmera:', error);
        showStatus('Erro ao acessar a câmera. Verifique as permissões do navegador.', 'error');
    }
}

// Função para iniciar a contagem regressiva
function startCountdown() {
    // Desabilitar o botão durante a contagem
    captureBtn.disabled = true;
    
    // Exibir o elemento de contagem
    countdownElement.style.display = 'block';
    
    // Iniciar contagem de 3
    let count = 3;
    countdownElement.textContent = count;
    
    // Atualizar a contagem a cada segundo
    const countdownInterval = setInterval(() => {
        count--;
        
        if (count > 0) {
            countdownElement.textContent = count;
        } else {
            // Quando a contagem chegar a zero, tirar a foto
            clearInterval(countdownInterval);
            countdownElement.textContent = '';
            countdownElement.style.display = 'none';
            capturePhoto();
        }
    }, 1000);
}

// Função para capturar a foto
function capturePhoto() {
    // Configurar o canvas com as dimensões do vídeo
    const videoWidth = video.videoWidth;
    const videoHeight = video.videoHeight;
    canvas.width = videoWidth;
    canvas.height = videoHeight;
    
    // Desenhar o frame atual do vídeo no canvas
    const context = canvas.getContext('2d');
    context.drawImage(video, 0, 0, videoWidth, videoHeight);
    
    // Adicionar a moldura à imagem (simulação - na prática, a moldura já está visualmente sobreposta)
    // Aqui poderíamos desenhar uma moldura no canvas se necessário
    
    // Converter para base64
    const imageDataUrl = canvas.toDataURL('image/png');
    
    // Exibir a imagem capturada
    capturedPhotoElement.src = imageDataUrl;
    
    // Ocultar a câmera e mostrar o resultado
    document.querySelector('.camera-container').style.display = 'none';
    resultContainer.style.display = 'block';
    
    // Mostrar o botão de nova foto
    captureBtn.style.display = 'none';
    newPhotoBtn.style.display = 'inline-block';
    
    // Enviar a foto para o servidor
    uploadPhoto(imageDataUrl);
}

// Função para enviar a foto para o servidor
async function uploadPhoto(imageDataUrl) {
    try {
        showStatus('Enviando foto...', 'info');
        
        const response = await fetch('/api/upload', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                image: imageDataUrl
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Exibir o QR code
            qrcodeElement.src = data.qr_url;
            
            showStatus('Foto enviada com sucesso!', 'success');
        } else {
            showStatus(`Erro ao enviar foto: ${data.error}`, 'error');
        }
    } catch (error) {
        console.error('Erro ao enviar foto:', error);
        showStatus('Erro ao enviar foto. Verifique sua conexão.', 'error');
    }
}

// Função para reiniciar a câmera
function resetCamera() {
    // Mostrar a câmera novamente
    document.querySelector('.camera-container').style.display = 'block';
    resultContainer.style.display = 'none';
    
    // Restaurar os botões
    captureBtn.style.display = 'inline-block';
    captureBtn.disabled = false;
    newPhotoBtn.style.display = 'none';
    
    // Limpar o status
    statusMessage.textContent = '';
    statusMessage.className = 'status-message';
}

// Função para exibir mensagens de status
function showStatus(message, type) {
    statusMessage.textContent = message;
    statusMessage.className = `status-message ${type}`;
    
    // Limpar a mensagem após alguns segundos (exceto para erros)
    if (type !== 'error') {
        setTimeout(() => {
            statusMessage.textContent = '';
            statusMessage.className = 'status-message';
        }, 5000);
    }
}
