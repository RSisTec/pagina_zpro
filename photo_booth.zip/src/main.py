import os
import sys
from flask import Flask, render_template, request, jsonify, send_from_directory
import json
from datetime import datetime
import qrcode
from PIL import Image
import base64
import io

# Configuração do Flask
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static/images/uploads')
app.config['QR_FOLDER'] = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static/images/qrcodes')

# Garantir que as pastas existam
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['QR_FOLDER'], exist_ok=True)

# Rota principal - página de captura de fotos
@app.route('/')
def index():
    return render_template('index.html')

# Rota para a página administrativa
@app.route('/admin')
def admin():
    return render_template('admin.html')

# API para enviar foto
@app.route('/api/upload', methods=['POST'])
def upload_photo():
    try:
        # Receber a imagem em base64
        data = request.json
        image_data = data.get('image')
        
        if not image_data:
            return jsonify({'success': False, 'error': 'Nenhuma imagem recebida'}), 400
        
        # Remover o prefixo de data URL se existir
        if 'base64,' in image_data:
            image_data = image_data.split('base64,')[1]
        
        # Decodificar a imagem
        image_bytes = base64.b64decode(image_data)
        image = Image.open(io.BytesIO(image_bytes))
        
        # Gerar nome de arquivo único
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"photo_{timestamp}.png"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        # Salvar a imagem
        image.save(filepath)
        
        # Gerar QR Code para acesso à foto
        qr_filename = f"qr_{timestamp}.png"
        qr_filepath = os.path.join(app.config['QR_FOLDER'], qr_filename)
        
        # URL para acessar a foto
        photo_url = f"/photo/{filename}"
        
        # Criar QR Code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(request.host_url.rstrip('/') + photo_url)
        qr.make(fit=True)
        
        qr_img = qr.make_image(fill_color="black", back_color="white")
        qr_img.save(qr_filepath)
        
        return jsonify({
            'success': True, 
            'filename': filename,
            'photo_url': photo_url,
            'qr_url': f"/qrcode/{qr_filename}"
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# API para listar todas as fotos
@app.route('/api/photos', methods=['GET'])
def list_photos():
    try:
        photos = []
        for filename in os.listdir(app.config['UPLOAD_FOLDER']):
            if filename.startswith('photo_') and (filename.endswith('.png') or filename.endswith('.jpg')):
                photo_url = f"/photo/{filename}"
                timestamp = filename.replace('photo_', '').replace('.png', '').replace('.jpg', '')
                
                # Tentar converter o timestamp para um formato mais legível
                try:
                    date_obj = datetime.strptime(timestamp, "%Y%m%d_%H%M%S")
                    formatted_date = date_obj.strftime("%d/%m/%Y %H:%M:%S")
                except:
                    formatted_date = timestamp
                
                photos.append({
                    'filename': filename,
                    'url': photo_url,
                    'timestamp': formatted_date,
                    'qr_url': f"/qrcode/qr_{timestamp}.png"
                })
        
        # Ordenar por timestamp (mais recente primeiro)
        photos.sort(key=lambda x: x['filename'], reverse=True)
        
        return jsonify({'success': True, 'photos': photos})
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# Rota para acessar uma foto específica
@app.route('/photo/<filename>')
def get_photo(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# Rota para acessar um QR code específico
@app.route('/qrcode/<filename>')
def get_qrcode(filename):
    return send_from_directory(app.config['QR_FOLDER'], filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
