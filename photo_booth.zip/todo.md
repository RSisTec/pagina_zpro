# Lista de Tarefas para o Projeto Photo Booth

## Estrutura do Projeto
- [x] Analisar requisitos do site
- [x] Criar estrutura do projeto Flask
- [x] Configurar ambiente virtual e dependências
- [x] Criar arquivo principal main.py

## Frontend
- [x] Implementar página de captura com acesso à câmera
- [x] Criar moldura para a foto
- [x] Implementar contagem regressiva de 3 segundos
- [x] Exibir foto capturada com moldura
- [x] Implementar geração de QR code para acesso à foto
- [x] Criar página administrativa para listar fotos

## Backend
- [x] Criar endpoint para receber e salvar fotos
- [x] Implementar rota para acessar fotos individuais
- [x] Criar rota para listar todas as fotos (área administrativa)

## Testes e Finalização
- [ ] Testar fluxo completo de captura e envio
- [ ] Validar funcionamento em diferentes navegadores
- [ ] Preparar documentação e instruções de uso
- [ ] Entregar projeto ao usuário
