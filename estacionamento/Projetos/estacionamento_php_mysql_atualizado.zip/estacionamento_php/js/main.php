<?php
/**
 * Arquivo JavaScript principal do sistema
 * 
 * Este arquivo contém funções JavaScript comuns usadas em todo o sistema
 */

// Incluir arquivo de inicialização
require_once 'init.php';
?>

// Funções utilitárias
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Inicializar popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Toggle sidebar
    const sidebarToggle = document.getElementById('sidebarCollapse');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
            document.getElementById('content').classList.toggle('active');
        });
    }
    
    // Auto-dismiss para alertas
    const alerts = document.querySelectorAll('.alert-dismissible');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const closeButton = alert.querySelector('.btn-close');
            if (closeButton) {
                closeButton.click();
            }
        }, 5000);
    });
    
    // Confirmação para exclusão
    const deleteButtons = document.querySelectorAll('[data-confirm]');
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            if (!confirm(this.getAttribute('data-confirm') || 'Tem certeza que deseja excluir este item?')) {
                e.preventDefault();
            }
        });
    });
    
    // Máscaras para inputs
    const maskInputs = document.querySelectorAll('[data-mask]');
    maskInputs.forEach(function(input) {
        const maskType = input.getAttribute('data-mask');
        
        input.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            
            switch (maskType) {
                case 'cpf':
                    if (value.length <= 11) {
                        value = value.replace(/(\d{3})(\d)/, '$1.$2');
                        value = value.replace(/(\d{3})(\d)/, '$1.$2');
                        value = value.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
                    }
                    break;
                    
                case 'cnpj':
                    if (value.length <= 14) {
                        value = value.replace(/(\d{2})(\d)/, '$1.$2');
                        value = value.replace(/(\d{3})(\d)/, '$1.$2');
                        value = value.replace(/(\d{3})(\d)/, '$1/$2');
                        value = value.replace(/(\d{4})(\d{1,2})$/, '$1-$2');
                    }
                    break;
                    
                case 'telefone':
                    if (value.length <= 11) {
                        if (value.length > 2) {
                            value = '(' + value.substring(0, 2) + ') ' + value.substring(2);
                        }
                        if (value.length > 10) {
                            value = value.substring(0, 10) + '-' + value.substring(10);
                        }
                    }
                    break;
                    
                case 'cep':
                    if (value.length <= 8) {
                        value = value.replace(/(\d{5})(\d)/, '$1-$2');
                    }
                    break;
                    
                case 'data':
                    if (value.length <= 8) {
                        value = value.replace(/(\d{2})(\d)/, '$1/$2');
                        value = value.replace(/(\d{2})(\d)/, '$1/$2');
                    }
                    break;
                    
                case 'placa':
                    // Formato antigo: AAA-9999
                    if (value.length <= 7) {
                        const letras = e.target.value.substring(0, 3).toUpperCase();
                        const numeros = value.substring(3);
                        value = letras + '-' + numeros;
                    }
                    break;
            }
            
            e.target.value = value;
        });
    });
    
    // Validação de formulários
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
    
    // Formatação de valores monetários
    const moneyInputs = document.querySelectorAll('[data-type="money"]');
    moneyInputs.forEach(function(input) {
        input.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            
            if (value === '') {
                e.target.value = '';
                return;
            }
            
            value = (parseInt(value) / 100).toFixed(2);
            e.target.value = value;
        });
    });
    
    // Formatação de datas
    const dateInputs = document.querySelectorAll('[data-type="date"]');
    dateInputs.forEach(function(input) {
        input.addEventListener('blur', function(e) {
            const value = e.target.value;
            
            if (value === '') {
                return;
            }
            
            const parts = value.split('/');
            
            if (parts.length === 3) {
                const day = parseInt(parts[0]);
                const month = parseInt(parts[1]) - 1;
                const year = parseInt(parts[2]);
                
                const date = new Date(year, month, day);
                
                if (date.getFullYear() === year && date.getMonth() === month && date.getDate() === day) {
                    return;
                }
            }
            
            e.target.value = '';
            alert('Data inválida. Use o formato DD/MM/AAAA.');
        });
    });
    
    // Formatação de CPF/CNPJ
    const documentInputs = document.querySelectorAll('[data-type="document"]');
    documentInputs.forEach(function(input) {
        input.addEventListener('blur', function(e) {
            const value = e.target.value.replace(/\D/g, '');
            
            if (value === '') {
                return;
            }
            
            if (value.length === 11) {
                // Validar CPF
                let sum = 0;
                let remainder;
                
                if (
                    value === '00000000000' || 
                    value === '11111111111' || 
                    value === '22222222222' || 
                    value === '33333333333' || 
                    value === '44444444444' || 
                    value === '55555555555' || 
                    value === '66666666666' || 
                    value === '77777777777' || 
                    value === '88888888888' || 
                    value === '99999999999'
                ) {
                    e.target.value = '';
                    alert('CPF inválido.');
                    return;
                }
                
                for (let i = 1; i <= 9; i++) {
                    sum = sum + parseInt(value.substring(i - 1, i)) * (11 - i);
                }
                
                remainder = (sum * 10) % 11;
                
                if ((remainder === 10) || (remainder === 11)) {
                    remainder = 0;
                }
                
                if (remainder !== parseInt(value.substring(9, 10))) {
                    e.target.value = '';
                    alert('CPF inválido.');
                    return;
                }
                
                sum = 0;
                
                for (let i = 1; i <= 10; i++) {
                    sum = sum + parseInt(value.substring(i - 1, i)) * (12 - i);
                }
                
                remainder = (sum * 10) % 11;
                
                if ((remainder === 10) || (remainder === 11)) {
                    remainder = 0;
                }
                
                if (remainder !== parseInt(value.substring(10, 11))) {
                    e.target.value = '';
                    alert('CPF inválido.');
                    return;
                }
            } else if (value.length === 14) {
                // Validar CNPJ
                if (
                    value === '00000000000000' || 
                    value === '11111111111111' || 
                    value === '22222222222222' || 
                    value === '33333333333333' || 
                    value === '44444444444444' || 
                    value === '55555555555555' || 
                    value === '66666666666666' || 
                    value === '77777777777777' || 
                    value === '88888888888888' || 
                    value === '99999999999999'
                ) {
                    e.target.value = '';
                    alert('CNPJ inválido.');
                    return;
                }
                
                // Validar primeiro dígito verificador
                let size = value.length - 2;
                let numbers = value.substring(0, size);
                const digits = value.substring(size);
                let sum = 0;
                let pos = size - 7;
                
                for (let i = size; i >= 1; i--) {
                    sum += numbers.charAt(size - i) * pos--;
                    if (pos < 2) {
                        pos = 9;
                    }
                }
                
                let result = sum % 11 < 2 ? 0 : 11 - sum % 11;
                
                if (result !== parseInt(digits.charAt(0))) {
                    e.target.value = '';
                    alert('CNPJ inválido.');
                    return;
                }
                
                // Validar segundo dígito verificador
                size = size + 1;
                numbers = value.substring(0, size);
                sum = 0;
                pos = size - 7;
                
                for (let i = size; i >= 1; i--) {
                    sum += numbers.charAt(size - i) * pos--;
                    if (pos < 2) {
                        pos = 9;
                    }
                }
                
                result = sum % 11 < 2 ? 0 : 11 - sum % 11;
                
                if (result !== parseInt(digits.charAt(1))) {
                    e.target.value = '';
                    alert('CNPJ inválido.');
                    return;
                }
            } else {
                e.target.value = '';
                alert('Documento inválido. Use CPF (11 dígitos) ou CNPJ (14 dígitos).');
            }
        });
    });
});

// Função para formatar data
function formatarData(data, incluirHora = false) {
    if (!data) {
        return '';
    }
    
    const date = new Date(data);
    
    if (isNaN(date.getTime())) {
        return '';
    }
    
    const dia = String(date.getDate()).padStart(2, '0');
    const mes = String(date.getMonth() + 1).padStart(2, '0');
    const ano = date.getFullYear();
    
    if (incluirHora) {
        const hora = String(date.getHours()).padStart(2, '0');
        const minuto = String(date.getMinutes()).padStart(2, '0');
        const segundo = String(date.getSeconds()).padStart(2, '0');
        
        return `${dia}/${mes}/${ano} ${hora}:${minuto}:${segundo}`;
    }
    
    return `${dia}/${mes}/${ano}`;
}

// Função para formatar moeda
function formatarMoeda(valor) {
    if (valor === null || valor === undefined || valor === '') {
        return 'R$ 0,00';
    }
    
    return 'R$ ' + parseFloat(valor).toFixed(2).replace('.', ',').replace(/(\d)(?=(\d{3})+\,)/g, '$1.');
}

// Função para calcular diferença entre datas em horas e minutos
function calcularDiferencaHoras(dataInicio, dataFim) {
    const inicio = new Date(dataInicio);
    const fim = dataFim ? new Date(dataFim) : new Date();
    
    const diff = fim - inicio;
    const minutos = Math.floor(diff / 60000);
    const horas = Math.floor(minutos / 60);
    const minutosRestantes = minutos % 60;
    
    return `${horas}h ${minutosRestantes}min`;
}

// Função para validar e-mail
function validarEmail(email) {
    const re = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return re.test(String(email).toLowerCase());
}

// Função para validar CPF
function validarCPF(cpf) {
    cpf = cpf.replace(/[^\d]/g, '');
    
    if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) {
        return false;
    }
    
    let sum = 0;
    let remainder;
    
    for (let i = 1; i <= 9; i++) {
        sum = sum + parseInt(cpf.substring(i - 1, i)) * (11 - i);
    }
    
    remainder = (sum * 10) % 11;
    
    if ((remainder === 10) || (remainder === 11)) {
        remainder = 0;
    }
    
    if (remainder !== parseInt(cpf.substring(9, 10))) {
        return false;
    }
    
    sum = 0;
    
    for (let i = 1; i <= 10; i++) {
        sum = sum + parseInt(cpf.substring(i - 1, i)) * (12 - i);
    }
    
    remainder = (sum * 10) % 11;
    
    if ((remainder === 10) || (remainder === 11)) {
        remainder = 0;
    }
    
    if (remainder !== parseInt(cpf.substring(10, 11))) {
        return false;
    }
    
    return true;
}

// Função para validar CNPJ
function validarCNPJ(cnpj) {
    cnpj = cnpj.replace(/[^\d]/g, '');
    
    if (cnpj.length !== 14 || /^(\d)\1+$/.test(cnpj)) {
        return false;
    }
    
    // Validar primeiro dígito verificador
    let size = cnpj.length - 2;
    let numbers = cnpj.substring(0, size);
    const digits = cnpj.substring(size);
    let sum = 0;
    let pos = size - 7;
    
    for (let i = size; i >= 1; i--) {
        sum += numbers.charAt(size - i) * pos--;
        if (pos < 2) {
            pos = 9;
        }
    }
    
    let result = sum % 11 < 2 ? 0 : 11 - sum % 11;
    
    if (result !== parseInt(digits.charAt(0))) {
        return false;
    }
    
    // Validar segundo dígito verificador
    size = size + 1;
    numbers = cnpj.substring(0, size);
    sum = 0;
    pos = size - 7;
    
    for (let i = size; i >= 1; i--) {
        sum += numbers.charAt(size - i) * pos--;
        if (pos < 2) {
            pos = 9;
        }
    }
    
    result = sum % 11 < 2 ? 0 : 11 - sum % 11;
    
    if (result !== parseInt(digits.charAt(1))) {
        return false;
    }
    
    return true;
}

// Função para validar placa de veículo
function validarPlaca(placa) {
    // Formato antigo: AAA-9999
    const padrao1 = /^[A-Z]{3}\-[0-9]{4}$/;
    
    // Formato Mercosul: AAA9A99
    const padrao2 = /^[A-Z]{3}[0-9][A-Z][0-9]{2}$/;
    
    // Formato simplificado (sem hífen): AAA9999
    const padrao3 = /^[A-Z]{3}[0-9]{4}$/;
    
    return padrao1.test(placa) || padrao2.test(placa) || padrao3.test(placa);
}

// Função para validar telefone
function validarTelefone(telefone) {
    telefone = telefone.replace(/[^\d]/g, '');
    return telefone.length >= 10 && telefone.length <= 11;
}

// Função para validar data
function validarData(data) {
    // Formato DD/MM/AAAA
    if (!/^\d{2}\/\d{2}\/\d{4}$/.test(data)) {
        return false;
    }
    
    const parts = data.split('/');
    const day = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10) - 1;
    const year = parseInt(parts[2], 10);
    
    const date = new Date(year, month, day);
    
    return date.getFullYear() === year && date.getMonth() === month && date.getDate() === day;
}

// Função para converter data do formato brasileiro para o formato do banco de dados
function converterDataParaBanco(data) {
    if (!data) {
        return null;
    }
    
    const parts = data.split('/');
    
    if (parts.length !== 3) {
        return null;
    }
    
    return parts[2] + '-' + parts[1] + '-' + parts[0];
}

// Função para converter data do formato do banco de dados para o formato brasileiro
function converterDataDoBanco(data) {
    if (!data) {
        return null;
    }
    
    const parts = data.split('-');
    
    if (parts.length !== 3) {
        return null;
    }
    
    return parts[2] + '/' + parts[1] + '/' + parts[0];
}

// Função para gerar alerta
function gerarAlerta(mensagem, tipo = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${tipo} alert-dismissible fade show`;
    alertDiv.setAttribute('role', 'alert');
    
    alertDiv.innerHTML = `
        ${mensagem}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    `;
    
    // Adicionar alerta ao topo da página
    const container = document.querySelector('.container-fluid');
    container.insertBefore(alertDiv, container.firstChild);
    
    // Auto-dismiss após 5 segundos
    setTimeout(function() {
        alertDiv.classList.remove('show');
        setTimeout(function() {
            alertDiv.remove();
        }, 150);
    }, 5000);
}

// Função para confirmar ação
function confirmarAcao(mensagem, callback) {
    if (confirm(mensagem)) {
        callback();
    }
}

// Função para redirecionar
function redirecionar(url) {
    window.location.href = url;
}

// Função para recarregar página
function recarregarPagina() {
    window.location.reload();
}

// Função para obter parâmetro da URL
function obterParametroURL(nome) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(nome);
}

// Função para adicionar parâmetro à URL
function adicionarParametroURL(nome, valor) {
    const url = new URL(window.location.href);
    url.searchParams.set(nome, valor);
    window.history.replaceState({}, '', url);
}

// Função para remover parâmetro da URL
function removerParametroURL(nome) {
    const url = new URL(window.location.href);
    url.searchParams.delete(nome);
    window.history.replaceState({}, '', url);
}

// Função para limpar formulário
function limparFormulario(formId) {
    document.getElementById(formId).reset();
}

// Função para desabilitar botão durante submissão
function desabilitarBotaoSubmit(formId) {
    const form = document.getElementById(formId);
    
    form.addEventListener('submit', function() {
        const buttons = form.querySelectorAll('button[type="submit"]');
        
        buttons.forEach(function(button) {
            button.disabled = true;
            button.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Aguarde...';
        });
    });
}

// Função para copiar texto para a área de transferência
function copiarTexto(texto) {
    const textarea = document.createElement('textarea');
    textarea.value = texto;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    
    gerarAlerta('Texto copiado para a área de transferência!', 'success');
}

// Função para imprimir elemento
function imprimirElemento(elementId) {
    const conteudo = document.getElementById(elementId).innerHTML;
    const janela = window.open('', '', 'width=800,height=600');
    
    janela.document.write('<html><head><title>Impressão</title>');
    janela.document.write('<link rel="stylesheet" href="../css/style.php">');
    janela.document.write('<link rel="stylesheet" href="../css/components.php">');
    janela.document.write('</head><body>');
    janela.document.write(conteudo);
    janela.document.write('</body></html>');
    
    janela.document.close();
    janela.focus();
    janela.print();
}

// Função para exportar tabela para CSV
function exportarTabelaCSV(tableId, filename = 'dados.csv') {
    const table = document.getElementById(tableId);
    let csv = [];
    const rows = table.querySelectorAll('tr');
    
    for (let i = 0; i < rows.length; i++) {
        const row = [], cols = rows[i].querySelectorAll('td, th');
        
        for (let j = 0; j < cols.length; j++) {
            // Remover HTML e limpar texto
            let text = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, '').replace(/(\s\s)/gm, ' ');
            // Escapar aspas duplas
            text = text.replace(/"/g, '""');
            // Adicionar aspas duplas ao redor do texto
            row.push('"' + text + '"');
        }
        
        csv.push(row.join(','));
    }
    
    // Criar link de download
    const csvFile = new Blob([csv.join('\n')], {type: 'text/csv;charset=utf-8;'});
    const downloadLink = document.createElement('a');
    
    downloadLink.href = URL.createObjectURL(csvFile);
    downloadLink.setAttribute('download', filename);
    downloadLink.style.display = 'none';
    
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
}
