<?php
/**
 * Arquivo de imagem padrão para o logo
 * Este arquivo será usado caso o logo.png não seja encontrado
 */

// Definir tipo de conteúdo como imagem PNG
header('Content-Type: image/png');

// Criar uma imagem de 200x80 pixels
$image = imagecreatetruecolor(200, 80);

// Definir cores
$background = imagecolorallocate($image, 255, 255, 255);
$textColor = imagecolorallocate($image, 41, 128, 185);
$borderColor = imagecolorallocate($image, 52, 152, 219);

// Preencher o fundo
imagefilledrectangle($image, 0, 0, 200, 80, $background);

// Desenhar borda
imagerectangle($image, 0, 0, 199, 79, $borderColor);

// Adicionar texto
$font = 5; // Fonte interna do GD
$text = "ESTACIONAMENTO";
$textWidth = imagefontwidth($font) * strlen($text);
$textHeight = imagefontheight($font);
$x = (200 - $textWidth) / 2;
$y = (80 - $textHeight) / 2;

imagestring($image, $font, $x, $y - 10, $text, $textColor);
imagestring($image, 3, $x + 20, $y + 10, "SISTEMA", $textColor);

// Enviar a imagem para o navegador
imagepng($image);

// Liberar memória
imagedestroy($image);
