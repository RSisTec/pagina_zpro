<?php
/**
 * Funções auxiliares para validação de dados
 * 
 * Este arquivo contém funções para validação de dados de entrada
 */

/**
 * Valida um endereço de e-mail
 * 
 * @param string $email E-mail a ser validado
 * @return bool Verdadeiro se o e-mail for válido
 */
function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Valida uma placa de veículo (formato brasileiro)
 * 
 * @param string $placa Placa a ser validada
 * @return bool Verdadeiro se a placa for válida
 */
function validarPlaca($placa) {
    // Formato antigo: AAA-9999
    $padrao1 = '/^[A-Z]{3}\-[0-9]{4}$/';
    
    // Formato Mercosul: AAA9A99
    $padrao2 = '/^[A-Z]{3}[0-9][A-Z][0-9]{2}$/';
    
    // Formato simplificado (sem hífen): AAA9999
    $padrao3 = '/^[A-Z]{3}[0-9]{4}$/';
    
    return preg_match($padrao1, $placa) || preg_match($padrao2, $placa) || preg_match($padrao3, $placa);
}

/**
 * Valida um CPF
 * 
 * @param string $cpf CPF a ser validado
 * @return bool Verdadeiro se o CPF for válido
 */
function validarCPF($cpf) {
    // Remover caracteres não numéricos
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    
    // Verificar se tem 11 dígitos
    if (strlen($cpf) != 11) {
        return false;
    }
    
    // Verificar se todos os dígitos são iguais
    if (preg_match('/^(\d)\1+$/', $cpf)) {
        return false;
    }
    
    // Calcular dígitos verificadores
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return false;
        }
    }
    
    return true;
}

/**
 * Valida um CNPJ
 * 
 * @param string $cnpj CNPJ a ser validado
 * @return bool Verdadeiro se o CNPJ for válido
 */
function validarCNPJ($cnpj) {
    // Remover caracteres não numéricos
    $cnpj = preg_replace('/[^0-9]/', '', $cnpj);
    
    // Verificar se tem 14 dígitos
    if (strlen($cnpj) != 14) {
        return false;
    }
    
    // Verificar se todos os dígitos são iguais
    if (preg_match('/^(\d)\1+$/', $cnpj)) {
        return false;
    }
    
    // Calcular primeiro dígito verificador
    $soma = 0;
    $multiplicador = 5;
    for ($i = 0; $i < 12; $i++) {
        $soma += $cnpj[$i] * $multiplicador;
        $multiplicador = ($multiplicador == 2) ? 9 : $multiplicador - 1;
    }
    $resto = $soma % 11;
    $dv1 = ($resto < 2) ? 0 : 11 - $resto;
    
    // Calcular segundo dígito verificador
    $soma = 0;
    $multiplicador = 6;
    for ($i = 0; $i < 12; $i++) {
        $soma += $cnpj[$i] * $multiplicador;
        $multiplicador = ($multiplicador == 2) ? 9 : $multiplicador - 1;
    }
    $soma += $dv1 * 2;
    $resto = $soma % 11;
    $dv2 = ($resto < 2) ? 0 : 11 - $resto;
    
    // Verificar dígitos verificadores
    return ($cnpj[12] == $dv1 && $cnpj[13] == $dv2);
}

/**
 * Valida um documento (CPF ou CNPJ)
 * 
 * @param string $documento Documento a ser validado
 * @return bool Verdadeiro se o documento for válido
 */
function validarDocumento($documento) {
    // Remover caracteres não numéricos
    $documento = preg_replace('/[^0-9]/', '', $documento);
    
    // Verificar se é CPF ou CNPJ
    if (strlen($documento) === 11) {
        return validarCPF($documento);
    } elseif (strlen($documento) === 14) {
        return validarCNPJ($documento);
    }
    
    return false;
}

/**
 * Valida um número de telefone
 * 
 * @param string $telefone Telefone a ser validado
 * @return bool Verdadeiro se o telefone for válido
 */
function validarTelefone($telefone) {
    // Remover caracteres não numéricos
    $telefone = preg_replace('/[^0-9]/', '', $telefone);
    
    // Verificar se tem entre 10 e 11 dígitos (com DDD)
    return strlen($telefone) >= 10 && strlen($telefone) <= 11;
}

/**
 * Valida uma data
 * 
 * @param string $data Data a ser validada (formato Y-m-d)
 * @return bool Verdadeiro se a data for válida
 */
function validarData($data) {
    $d = DateTime::createFromFormat('Y-m-d', $data);
    return $d && $d->format('Y-m-d') === $data;
}

/**
 * Valida um valor monetário
 * 
 * @param mixed $valor Valor a ser validado
 * @return bool Verdadeiro se o valor for válido
 */
function validarValor($valor) {
    return is_numeric($valor) && $valor >= 0;
}

/**
 * Formata um documento (CPF ou CNPJ)
 * 
 * @param string $documento Documento a ser formatado
 * @return string Documento formatado
 */
function formatarDocumento($documento) {
    // Remover caracteres não numéricos
    $documento = preg_replace('/[^0-9]/', '', $documento);
    
    // Verificar se é CPF ou CNPJ
    if (strlen($documento) === 11) {
        // Formatar CPF: 000.000.000-00
        return preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $documento);
    } elseif (strlen($documento) === 14) {
        // Formatar CNPJ: 00.000.000/0000-00
        return preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $documento);
    }
    
    return $documento;
}

/**
 * Formata um telefone
 * 
 * @param string $telefone Telefone a ser formatado
 * @return string Telefone formatado
 */
function formatarTelefone($telefone) {
    // Remover caracteres não numéricos
    $telefone = preg_replace('/[^0-9]/', '', $telefone);
    
    // Verificar se tem 11 dígitos (com DDD e 9 na frente)
    if (strlen($telefone) === 11) {
        return preg_replace('/(\d{2})(\d{1})(\d{4})(\d{4})/', '($1) $2 $3-$4', $telefone);
    } 
    // Verificar se tem 10 dígitos (com DDD)
    elseif (strlen($telefone) === 10) {
        return preg_replace('/(\d{2})(\d{4})(\d{4})/', '($1) $2-$3', $telefone);
    }
    
    return $telefone;
}

/**
 * Limpa uma string para uso em consultas SQL
 * 
 * @param string $str String a ser limpa
 * @return string String limpa
 */
function limparString($str) {
    return trim(preg_replace('/[^\p{L}\p{N}\s]/u', '', $str));
}

/**
 * Verifica se uma string contém caracteres especiais
 * 
 * @param string $str String a ser verificada
 * @return bool Verdadeiro se a string contiver caracteres especiais
 */
function contemCaracteresEspeciais($str) {
    return preg_match('/[^\p{L}\p{N}\s]/u', $str);
}

/**
 * Verifica se uma string contém apenas letras e espaços
 * 
 * @param string $str String a ser verificada
 * @return bool Verdadeiro se a string contiver apenas letras e espaços
 */
function apenasLetrasEEspacos($str) {
    return preg_match('/^[\p{L}\s]+$/u', $str);
}

/**
 * Verifica se uma string contém apenas números
 * 
 * @param string $str String a ser verificada
 * @return bool Verdadeiro se a string contiver apenas números
 */
function apenasNumeros($str) {
    return preg_match('/^[0-9]+$/', $str);
}

/**
 * Verifica se uma string contém apenas letras, números e espaços
 * 
 * @param string $str String a ser verificada
 * @return bool Verdadeiro se a string contiver apenas letras, números e espaços
 */
function apenasLetrasNumerosEEspacos($str) {
    return preg_match('/^[\p{L}\p{N}\s]+$/u', $str);
}

/**
 * Verifica se uma string é segura para uso em URLs
 * 
 * @param string $str String a ser verificada
 * @return bool Verdadeiro se a string for segura para URLs
 */
function stringSeguaParaURL($str) {
    return preg_match('/^[a-zA-Z0-9_\-]+$/', $str);
}

/**
 * Verifica se uma senha é forte
 * 
 * @param string $senha Senha a ser verificada
 * @return bool Verdadeiro se a senha for forte
 */
function senhaForte($senha) {
    // Pelo menos 8 caracteres
    if (strlen($senha) < 8) {
        return false;
    }
    
    // Pelo menos uma letra maiúscula
    if (!preg_match('/[A-Z]/', $senha)) {
        return false;
    }
    
    // Pelo menos uma letra minúscula
    if (!preg_match('/[a-z]/', $senha)) {
        return false;
    }
    
    // Pelo menos um número
    if (!preg_match('/[0-9]/', $senha)) {
        return false;
    }
    
    // Pelo menos um caractere especial
    if (!preg_match('/[^a-zA-Z0-9]/', $senha)) {
        return false;
    }
    
    return true;
}
