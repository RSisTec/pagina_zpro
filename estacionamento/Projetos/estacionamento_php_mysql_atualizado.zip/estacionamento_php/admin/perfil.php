<?php
/**
 * Página de perfil do usuário
 */
$tituloPagina = 'Meu Perfil - Sistema de Estacionamento';
require_once '../includes/header.php';
require_once '../config/database.php';

// Obter ID do usuário atual
$usuarioId = getCurrentUserId();
$mensagem = '';
$tipoMensagem = '';

// Processar formulário de atualização de perfil
if (isPostRequest() && isset($_POST['atualizar_perfil'])) {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $nome = $_POST['nome'] ?? '';
            $email = $_POST['email'] ?? '';
            
            // Validar dados
            if (empty($nome)) {
                $mensagem = 'Por favor, preencha o nome.';
                $tipoMensagem = 'danger';
            } else {
                // Atualizar perfil
                $query = "UPDATE usuarios 
                          SET nome = :nome, 
                              email = :email 
                          WHERE id = :id";
                $stmt = $conn->prepare($query);
                $stmt->bindParam(':nome', $nome);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':id', $usuarioId);
                $stmt->execute();
                
                // Atualizar sessão
                $_SESSION['user_nome'] = $nome;
                $_SESSION['user_email'] = $email;
                
                $mensagem = 'Perfil atualizado com sucesso!';
                $tipoMensagem = 'success';
            }
        } catch (PDOException $e) {
            logError('Erro ao atualizar perfil', $e);
            $mensagem = 'Erro ao atualizar perfil. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
        }
    }
}

// Processar formulário de alteração de senha
if (isPostRequest() && isset($_POST['alterar_senha'])) {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            // Obter dados do formulário
            $senhaAtual = $_POST['senha_atual'] ?? '';
            $novaSenha = $_POST['nova_senha'] ?? '';
            $confirmarSenha = $_POST['confirmar_senha'] ?? '';
            
            // Validar dados
            if (empty($senhaAtual) || empty($novaSenha) || empty($confirmarSenha)) {
                $mensagem = 'Por favor, preencha todos os campos.';
                $tipoMensagem = 'danger';
            } elseif ($novaSenha !== $confirmarSenha) {
                $mensagem = 'A nova senha e a confirmação não coincidem.';
                $tipoMensagem = 'danger';
            } elseif (strlen($novaSenha) < 6) {
                $mensagem = 'A nova senha deve ter pelo menos 6 caracteres.';
                $tipoMensagem = 'danger';
            } else {
                // Alterar senha
                $resultado = alterarSenhaUsuario($usuarioId, $senhaAtual, $novaSenha);
                
                if ($resultado) {
                    $mensagem = 'Senha alterada com sucesso!';
                    $tipoMensagem = 'success';
                } else {
                    $mensagem = 'Senha atual incorreta.';
                    $tipoMensagem = 'danger';
                }
            }
        } catch (Exception $e) {
            logError('Erro ao alterar senha', $e);
            $mensagem = 'Erro ao alterar senha. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
        }
    }
}

// Obter dados do usuário
try {
    $conn = getConnection();
    
    $query = "SELECT nome, email, login, nivel FROM usuarios WHERE id = :id";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':id', $usuarioId);
    $stmt->execute();
    
    $usuario = $stmt->fetch();
} catch (PDOException $e) {
    logError('Erro ao obter dados do usuário', $e);
    $usuario = [
        'nome' => $_SESSION['user_nome'] ?? '',
        'email' => $_SESSION['user_email'] ?? '',
        'login' => $_SESSION['user_login'] ?? '',
        'nivel' => $_SESSION['user_nivel'] ?? ''
    ];
}
?>

<h1 class="mb-4">Meu Perfil</h1>

<?php if (!empty($mensagem)): ?>
    <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
        <?php echo $mensagem; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Informações Pessoais</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="perfil.php">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    <input type="hidden" name="atualizar_perfil" value="1">
                    
                    <div class="form-group mb-3">
                        <label for="nome">Nome*</label>
                        <input type="text" id="nome" name="nome" class="form-control" value="<?php echo sanitizeOutput($usuario['nome']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="email">E-mail</label>
                        <input type="email" id="email" name="email" class="form-control" value="<?php echo sanitizeOutput($usuario['email']); ?>">
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="login">Login</label>
                        <input type="text" id="login" class="form-control" value="<?php echo sanitizeOutput($usuario['login']); ?>" readonly>
                        <small class="form-text text-muted">O login não pode ser alterado.</small>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="nivel">Nível de Acesso</label>
                        <input type="text" id="nivel" class="form-control" value="<?php echo $usuario['nivel'] === 'admin' ? 'Administrador' : 'Operador'; ?>" readonly>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Atualizar Perfil</button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Alterar Senha</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="perfil.php">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    <input type="hidden" name="alterar_senha" value="1">
                    
                    <div class="form-group mb-3">
                        <label for="senha_atual">Senha Atual*</label>
                        <input type="password" id="senha_atual" name="senha_atual" class="form-control" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="nova_senha">Nova Senha*</label>
                        <input type="password" id="nova_senha" name="nova_senha" class="form-control" required>
                        <small class="form-text text-muted">A senha deve ter pelo menos 6 caracteres.</small>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="confirmar_senha">Confirmar Nova Senha*</label>
                        <input type="password" id="confirmar_senha" name="confirmar_senha" class="form-control" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Alterar Senha</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
