<?php
/**
 * Página de relatórios
 */
$tituloPagina = 'Relatórios - Sistema de Estacionamento';
require_once '../includes/header.php';
require_once '../config/database.php';

// Verificar permissão
requirePermission('operador');

// Processar filtros
$dataInicio = $_GET['data_inicio'] ?? date('Y-m-d', strtotime('-30 days'));
$dataFim = $_GET['data_fim'] ?? date('Y-m-d');
$tipoRelatorio = $_GET['tipo'] ?? 'movimentacao';

// Obter empresa atual
$empresaId = getCurrentEmpresaId();

// Inicializar variáveis para os relatórios
$dadosRelatorio = [];
$totalGeral = 0;
$totalVeiculos = 0;

try {
    $conn = getConnection();
    
    switch ($tipoRelatorio) {
        case 'movimentacao':
            // Relatório de movimentação
            $query = "SELECT DATE(entrada) as data, COUNT(*) as total_veiculos, SUM(valor_total) as total_valor 
                      FROM veiculos 
                      WHERE empresa_id = :empresa_id 
                      AND DATE(entrada) BETWEEN :data_inicio AND :data_fim 
                      GROUP BY DATE(entrada) 
                      ORDER BY data";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':empresa_id', $empresaId);
            $stmt->bindParam(':data_inicio', $dataInicio);
            $stmt->bindParam(':data_fim', $dataFim);
            $stmt->execute();
            $dadosRelatorio = $stmt->fetchAll();
            
            // Calcular totais
            $queryTotais = "SELECT COUNT(*) as total_veiculos, SUM(valor_total) as total_valor 
                           FROM veiculos 
                           WHERE empresa_id = :empresa_id 
                           AND DATE(entrada) BETWEEN :data_inicio AND :data_fim";
            $stmtTotais = $conn->prepare($queryTotais);
            $stmtTotais->bindParam(':empresa_id', $empresaId);
            $stmtTotais->bindParam(':data_inicio', $dataInicio);
            $stmtTotais->bindParam(':data_fim', $dataFim);
            $stmtTotais->execute();
            $totais = $stmtTotais->fetch();
            
            $totalVeiculos = $totais['total_veiculos'] ?? 0;
            $totalGeral = $totais['total_valor'] ?? 0;
            break;
            
        case 'mensalistas':
            // Relatório de mensalistas
            $query = "SELECT m.id, m.nome, m.documento, m.plano, m.data_inicio, m.data_fim, m.valor, 
                             (SELECT COUNT(*) FROM veiculos v WHERE v.mensalista_id = m.id) as total_acessos 
                      FROM mensalistas m 
                      WHERE m.empresa_id = :empresa_id 
                      AND m.ativo = 1 
                      ORDER BY m.nome";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':empresa_id', $empresaId);
            $stmt->execute();
            $dadosRelatorio = $stmt->fetchAll();
            
            // Calcular totais
            $queryTotais = "SELECT COUNT(*) as total_mensalistas, SUM(valor) as total_valor 
                           FROM mensalistas 
                           WHERE empresa_id = :empresa_id 
                           AND ativo = 1";
            $stmtTotais = $conn->prepare($queryTotais);
            $stmtTotais->bindParam(':empresa_id', $empresaId);
            $stmtTotais->execute();
            $totais = $stmtTotais->fetch();
            
            $totalVeiculos = $totais['total_mensalistas'] ?? 0;
            $totalGeral = $totais['total_valor'] ?? 0;
            break;
            
        case 'faturamento':
            // Relatório de faturamento
            $query = "SELECT DATE(saida) as data, 
                             COUNT(*) as total_veiculos, 
                             SUM(CASE WHEN tipo_cliente = 'normal' THEN valor_total ELSE 0 END) as total_normal,
                             SUM(CASE WHEN tipo_cliente = 'mensalista' THEN valor_total ELSE 0 END) as total_mensalista,
                             SUM(valor_total) as total_valor 
                      FROM veiculos 
                      WHERE empresa_id = :empresa_id 
                      AND saida IS NOT NULL 
                      AND DATE(saida) BETWEEN :data_inicio AND :data_fim 
                      GROUP BY DATE(saida) 
                      ORDER BY data";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':empresa_id', $empresaId);
            $stmt->bindParam(':data_inicio', $dataInicio);
            $stmt->bindParam(':data_fim', $dataFim);
            $stmt->execute();
            $dadosRelatorio = $stmt->fetchAll();
            
            // Calcular totais
            $queryTotais = "SELECT COUNT(*) as total_veiculos, 
                                  SUM(CASE WHEN tipo_cliente = 'normal' THEN valor_total ELSE 0 END) as total_normal,
                                  SUM(CASE WHEN tipo_cliente = 'mensalista' THEN valor_total ELSE 0 END) as total_mensalista,
                                  SUM(valor_total) as total_valor 
                           FROM veiculos 
                           WHERE empresa_id = :empresa_id 
                           AND saida IS NOT NULL 
                           AND DATE(saida) BETWEEN :data_inicio AND :data_fim";
            $stmtTotais = $conn->prepare($queryTotais);
            $stmtTotais->bindParam(':empresa_id', $empresaId);
            $stmtTotais->bindParam(':data_inicio', $dataInicio);
            $stmtTotais->bindParam(':data_fim', $dataFim);
            $stmtTotais->execute();
            $totais = $stmtTotais->fetch();
            
            $totalVeiculos = $totais['total_veiculos'] ?? 0;
            $totalGeral = $totais['total_valor'] ?? 0;
            break;
    }
} catch (PDOException $e) {
    logError('Erro ao gerar relatório', $e);
    $dadosRelatorio = [];
}
?>

<h1 class="mb-4">Relatórios</h1>

<div class="card mb-4">
    <div class="card-header">
        <h5 class="card-title">Filtros</h5>
    </div>
    <div class="card-body">
        <form method="GET" action="relatorios.php" class="row g-3">
            <div class="col-md-3">
                <label for="tipo" class="form-label">Tipo de Relatório</label>
                <select id="tipo" name="tipo" class="form-control">
                    <option value="movimentacao" <?php echo $tipoRelatorio === 'movimentacao' ? 'selected' : ''; ?>>Movimentação</option>
                    <option value="mensalistas" <?php echo $tipoRelatorio === 'mensalistas' ? 'selected' : ''; ?>>Mensalistas</option>
                    <option value="faturamento" <?php echo $tipoRelatorio === 'faturamento' ? 'selected' : ''; ?>>Faturamento</option>
                </select>
            </div>
            
            <div class="col-md-3 data-filter <?php echo $tipoRelatorio === 'mensalistas' ? 'd-none' : ''; ?>">
                <label for="data_inicio" class="form-label">Data Inicial</label>
                <input type="date" id="data_inicio" name="data_inicio" class="form-control" value="<?php echo $dataInicio; ?>">
            </div>
            
            <div class="col-md-3 data-filter <?php echo $tipoRelatorio === 'mensalistas' ? 'd-none' : ''; ?>">
                <label for="data_fim" class="form-label">Data Final</label>
                <input type="date" id="data_fim" name="data_fim" class="form-control" value="<?php echo $dataFim; ?>">
            </div>
            
            <div class="col-md-3 d-flex align-items-end">
                <button type="submit" class="btn btn-primary">Gerar Relatório</button>
                <button type="button" id="btn-imprimir" class="btn btn-secondary ms-2">Imprimir</button>
            </div>
        </form>
    </div>
</div>

<div class="card" id="relatorio-container">
    <div class="card-header">
        <h5 class="card-title">
            <?php 
                switch ($tipoRelatorio) {
                    case 'movimentacao':
                        echo 'Relatório de Movimentação';
                        break;
                    case 'mensalistas':
                        echo 'Relatório de Mensalistas';
                        break;
                    case 'faturamento':
                        echo 'Relatório de Faturamento';
                        break;
                }
            ?>
        </h5>
        <p class="card-subtitle mb-2 text-muted">
            <?php if ($tipoRelatorio !== 'mensalistas'): ?>
                Período: <?php echo formatarData($dataInicio); ?> a <?php echo formatarData($dataFim); ?>
            <?php else: ?>
                Mensalistas Ativos
            <?php endif; ?>
        </p>
    </div>
    <div class="card-body">
        <?php if (count($dadosRelatorio) > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <?php if ($tipoRelatorio === 'movimentacao'): ?>
                            <tr>
                                <th>Data</th>
                                <th>Veículos</th>
                                <th>Valor Total</th>
                            </tr>
                        <?php elseif ($tipoRelatorio === 'mensalistas'): ?>
                            <tr>
                                <th>Nome</th>
                                <th>Documento</th>
                                <th>Plano</th>
                                <th>Validade</th>
                                <th>Valor</th>
                                <th>Acessos</th>
                            </tr>
                        <?php elseif ($tipoRelatorio === 'faturamento'): ?>
                            <tr>
                                <th>Data</th>
                                <th>Veículos</th>
                                <th>Normal</th>
                                <th>Mensalista</th>
                                <th>Total</th>
                            </tr>
                        <?php endif; ?>
                    </thead>
                    <tbody>
                        <?php foreach ($dadosRelatorio as $item): ?>
                            <?php if ($tipoRelatorio === 'movimentacao'): ?>
                                <tr>
                                    <td><?php echo formatarData($item['data']); ?></td>
                                    <td><?php echo $item['total_veiculos']; ?></td>
                                    <td><?php echo formatarMoeda($item['total_valor'] ?? 0); ?></td>
                                </tr>
                            <?php elseif ($tipoRelatorio === 'mensalistas'): ?>
                                <tr>
                                    <td><?php echo sanitizeOutput($item['nome']); ?></td>
                                    <td><?php echo sanitizeOutput($item['documento']); ?></td>
                                    <td><?php echo sanitizeOutput($item['plano']); ?></td>
                                    <td>
                                        <?php echo formatarData($item['data_inicio']); ?> a 
                                        <?php echo formatarData($item['data_fim']); ?>
                                    </td>
                                    <td><?php echo formatarMoeda($item['valor'] ?? 0); ?></td>
                                    <td><?php echo $item['total_acessos']; ?></td>
                                </tr>
                            <?php elseif ($tipoRelatorio === 'faturamento'): ?>
                                <tr>
                                    <td><?php echo formatarData($item['data']); ?></td>
                                    <td><?php echo $item['total_veiculos']; ?></td>
                                    <td><?php echo formatarMoeda($item['total_normal'] ?? 0); ?></td>
                                    <td><?php echo formatarMoeda($item['total_mensalista'] ?? 0); ?></td>
                                    <td><?php echo formatarMoeda($item['total_valor'] ?? 0); ?></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <?php if ($tipoRelatorio === 'movimentacao'): ?>
                            <tr class="table-dark">
                                <th>Total</th>
                                <th><?php echo $totalVeiculos; ?></th>
                                <th><?php echo formatarMoeda($totalGeral); ?></th>
                            </tr>
                        <?php elseif ($tipoRelatorio === 'mensalistas'): ?>
                            <tr class="table-dark">
                                <th colspan="4">Total</th>
                                <th><?php echo formatarMoeda($totalGeral); ?></th>
                                <th><?php echo $totalVeiculos; ?></th>
                            </tr>
                        <?php elseif ($tipoRelatorio === 'faturamento'): ?>
                            <tr class="table-dark">
                                <th>Total</th>
                                <th><?php echo $totalVeiculos; ?></th>
                                <th><?php echo formatarMoeda($totais['total_normal'] ?? 0); ?></th>
                                <th><?php echo formatarMoeda($totais['total_mensalista'] ?? 0); ?></th>
                                <th><?php echo formatarMoeda($totalGeral); ?></th>
                            </tr>
                        <?php endif; ?>
                    </tfoot>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                Nenhum dado encontrado para o período selecionado.
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Mostrar/ocultar filtros de data conforme o tipo de relatório
    document.getElementById('tipo').addEventListener('change', function() {
        const tipoRelatorio = this.value;
        const dataFilters = document.querySelectorAll('.data-filter');
        
        if (tipoRelatorio === 'mensalistas') {
            dataFilters.forEach(filter => filter.classList.add('d-none'));
        } else {
            dataFilters.forEach(filter => filter.classList.remove('d-none'));
        }
    });
    
    // Botão de impressão
    document.getElementById('btn-imprimir').addEventListener('click', function() {
        const conteudo = document.getElementById('relatorio-container').innerHTML;
        const estilo = `
            <style>
                body { font-family: Arial, sans-serif; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                .table-dark th { background-color: #343a40; color: white; }
                h5 { margin-bottom: 5px; }
                .text-muted { color: #6c757d; }
                .card-header { margin-bottom: 20px; }
            </style>
        `;
        
        const janela = window.open('', '', 'width=800,height=600');
        janela.document.write('<html><head><title>Relatório</title>');
        janela.document.write(estilo);
        janela.document.write('</head><body>');
        janela.document.write('<h3>Sistema de Estacionamento - <?php echo $_SESSION['empresa_nome']; ?></h3>');
        janela.document.write(conteudo);
        janela.document.write('</body></html>');
        janela.document.close();
        janela.focus();
        janela.print();
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>
