<?php
/**
 * Página de logout do sistema
 */
require_once '../includes/session.php';
require_once '../includes/auth.php';

// Encerrar a sessão
encerrarSessao();

// Redirecionar para a página de login
header('Location: ../login.php');
exit;
