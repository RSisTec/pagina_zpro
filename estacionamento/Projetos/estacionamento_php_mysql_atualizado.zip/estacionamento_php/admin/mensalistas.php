<?php
/**
 * Página de gestão de mensalistas
 */
$tituloPagina = 'Mensalistas - Sistema de Estacionamento';
require_once '../includes/header.php';
require_once '../config/database.php';

// Verificar permissão
requirePermission('operador');

// Processar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? '';
$mensagem = '';
$tipoMensagem = '';

// Obter empresa atual
$empresaId = getCurrentEmpresaId();

// Inicializar variáveis para o formulário
$mensalista = [
    'id' => '',
    'nome' => '',
    'documento' => '',
    'telefone' => '',
    'email' => '',
    'plano' => 'Mensal',
    'data_inicio' => date('Y-m-d'),
    'data_fim' => date('Y-m-d', strtotime('+1 month')),
    'valor' => '',
    'observacoes' => '',
    'ativo' => 1
];

// Processar exclusão
if ($acao === 'excluir' && !empty($id)) {
    try {
        $conn = getConnection();
        
        // Verificar se existem veículos associados
        $queryVerificar = "SELECT COUNT(*) as total FROM veiculos 
                          WHERE mensalista_id = :id 
                          AND empresa_id = :empresa_id 
                          AND saida IS NULL";
        $stmtVerificar = $conn->prepare($queryVerificar);
        $stmtVerificar->bindParam(':id', $id);
        $stmtVerificar->bindParam(':empresa_id', $empresaId);
        $stmtVerificar->execute();
        
        if ($stmtVerificar->fetch()['total'] > 0) {
            $mensagem = 'Não é possível excluir este mensalista pois existem veículos associados.';
            $tipoMensagem = 'danger';
        } else {
            // Excluir mensalista
            $query = "DELETE FROM mensalistas 
                      WHERE id = :id 
                      AND empresa_id = :empresa_id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':empresa_id', $empresaId);
            $stmt->execute();
            
            $mensagem = 'Mensalista excluído com sucesso!';
            $tipoMensagem = 'success';
        }
    } catch (PDOException $e) {
        logError('Erro ao excluir mensalista', $e);
        $mensagem = 'Erro ao excluir mensalista. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    }
}

// Carregar dados para edição
if ($acao === 'editar' && !empty($id)) {
    try {
        $conn = getConnection();
        
        $query = "SELECT * FROM mensalistas 
                  WHERE id = :id 
                  AND empresa_id = :empresa_id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':empresa_id', $empresaId);
        $stmt->execute();
        
        $result = $stmt->fetch();
        
        if ($result) {
            $mensalista = $result;
        } else {
            $mensagem = 'Mensalista não encontrado.';
            $tipoMensagem = 'danger';
        }
    } catch (PDOException $e) {
        logError('Erro ao carregar mensalista para edição', $e);
        $mensagem = 'Erro ao carregar dados do mensalista. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    }
}

// Processar formulário
if (isPostRequest()) {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $mensalistaId = $_POST['id'] ?? '';
            $nome = $_POST['nome'] ?? '';
            $documento = $_POST['documento'] ?? '';
            $telefone = $_POST['telefone'] ?? '';
            $email = $_POST['email'] ?? '';
            $plano = $_POST['plano'] ?? '';
            $dataInicio = $_POST['data_inicio'] ?? '';
            $dataFim = $_POST['data_fim'] ?? '';
            $valor = $_POST['valor'] ?? '';
            $observacoes = $_POST['observacoes'] ?? '';
            $ativo = isset($_POST['ativo']) ? 1 : 0;
            
            // Validar dados
            if (empty($nome) || empty($documento) || empty($plano) || empty($dataInicio) || empty($dataFim)) {
                $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
                $tipoMensagem = 'danger';
                
                // Manter dados do formulário
                $mensalista = [
                    'id' => $mensalistaId,
                    'nome' => $nome,
                    'documento' => $documento,
                    'telefone' => $telefone,
                    'email' => $email,
                    'plano' => $plano,
                    'data_inicio' => $dataInicio,
                    'data_fim' => $dataFim,
                    'valor' => $valor,
                    'observacoes' => $observacoes,
                    'ativo' => $ativo
                ];
            } else {
                if (empty($mensalistaId)) {
                    // Inserir novo mensalista
                    $query = "INSERT INTO mensalistas (nome, documento, telefone, email, plano, data_inicio, data_fim, valor, observacoes, ativo, empresa_id) 
                              VALUES (:nome, :documento, :telefone, :email, :plano, :data_inicio, :data_fim, :valor, :observacoes, :ativo, :empresa_id)";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':nome', $nome);
                    $stmt->bindParam(':documento', $documento);
                    $stmt->bindParam(':telefone', $telefone);
                    $stmt->bindParam(':email', $email);
                    $stmt->bindParam(':plano', $plano);
                    $stmt->bindParam(':data_inicio', $dataInicio);
                    $stmt->bindParam(':data_fim', $dataFim);
                    $stmt->bindParam(':valor', $valor);
                    $stmt->bindParam(':observacoes', $observacoes);
                    $stmt->bindParam(':ativo', $ativo);
                    $stmt->bindParam(':empresa_id', $empresaId);
                    $stmt->execute();
                    
                    $mensagem = 'Mensalista cadastrado com sucesso!';
                    $tipoMensagem = 'success';
                } else {
                    // Atualizar mensalista existente
                    $query = "UPDATE mensalistas 
                              SET nome = :nome, 
                                  documento = :documento, 
                                  telefone = :telefone, 
                                  email = :email, 
                                  plano = :plano, 
                                  data_inicio = :data_inicio, 
                                  data_fim = :data_fim, 
                                  valor = :valor, 
                                  observacoes = :observacoes, 
                                  ativo = :ativo 
                              WHERE id = :id 
                              AND empresa_id = :empresa_id";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':nome', $nome);
                    $stmt->bindParam(':documento', $documento);
                    $stmt->bindParam(':telefone', $telefone);
                    $stmt->bindParam(':email', $email);
                    $stmt->bindParam(':plano', $plano);
                    $stmt->bindParam(':data_inicio', $dataInicio);
                    $stmt->bindParam(':data_fim', $dataFim);
                    $stmt->bindParam(':valor', $valor);
                    $stmt->bindParam(':observacoes', $observacoes);
                    $stmt->bindParam(':ativo', $ativo);
                    $stmt->bindParam(':id', $mensalistaId);
                    $stmt->bindParam(':empresa_id', $empresaId);
                    $stmt->execute();
                    
                    $mensagem = 'Mensalista atualizado com sucesso!';
                    $tipoMensagem = 'success';
                }
                
                // Limpar formulário após sucesso
                $mensalista = [
                    'id' => '',
                    'nome' => '',
                    'documento' => '',
                    'telefone' => '',
                    'email' => '',
                    'plano' => 'Mensal',
                    'data_inicio' => date('Y-m-d'),
                    'data_fim' => date('Y-m-d', strtotime('+1 month')),
                    'valor' => '',
                    'observacoes' => '',
                    'ativo' => 1
                ];
            }
        } catch (PDOException $e) {
            logError('Erro ao salvar mensalista', $e);
            $mensagem = 'Erro ao salvar mensalista. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
        }
    }
}

// Obter lista de mensalistas
try {
    $conn = getConnection();
    
    $query = "SELECT * FROM mensalistas 
              WHERE empresa_id = :empresa_id 
              ORDER BY nome";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':empresa_id', $empresaId);
    $stmt->execute();
    $mensalistas = $stmt->fetchAll();
} catch (PDOException $e) {
    logError('Erro ao obter lista de mensalistas', $e);
    $mensalistas = [];
}
?>

<h1 class="mb-4">Gestão de Mensalistas</h1>

<?php if (!empty($mensagem)): ?>
    <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
        <?php echo $mensagem; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title"><?php echo empty($mensalista['id']) ? 'Novo Mensalista' : 'Editar Mensalista'; ?></h5>
            </div>
            <div class="card-body">
                <form method="POST" action="mensalistas.php">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    <input type="hidden" name="id" value="<?php echo sanitizeOutput($mensalista['id']); ?>">
                    
                    <div class="form-group mb-3">
                        <label for="nome">Nome*</label>
                        <input type="text" id="nome" name="nome" class="form-control" value="<?php echo sanitizeOutput($mensalista['nome']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="documento">Documento*</label>
                        <input type="text" id="documento" name="documento" class="form-control" value="<?php echo sanitizeOutput($mensalista['documento']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="telefone">Telefone</label>
                        <input type="text" id="telefone" name="telefone" class="form-control" value="<?php echo sanitizeOutput($mensalista['telefone']); ?>">
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="email">E-mail</label>
                        <input type="email" id="email" name="email" class="form-control" value="<?php echo sanitizeOutput($mensalista['email']); ?>">
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="plano">Plano*</label>
                        <select id="plano" name="plano" class="form-control" required>
                            <option value="Mensal" <?php echo $mensalista['plano'] === 'Mensal' ? 'selected' : ''; ?>>Mensal</option>
                            <option value="Trimestral" <?php echo $mensalista['plano'] === 'Trimestral' ? 'selected' : ''; ?>>Trimestral</option>
                            <option value="Semestral" <?php echo $mensalista['plano'] === 'Semestral' ? 'selected' : ''; ?>>Semestral</option>
                            <option value="Anual" <?php echo $mensalista['plano'] === 'Anual' ? 'selected' : ''; ?>>Anual</option>
                        </select>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="data_inicio">Data de Início*</label>
                        <input type="date" id="data_inicio" name="data_inicio" class="form-control" value="<?php echo sanitizeOutput($mensalista['data_inicio']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="data_fim">Data de Fim*</label>
                        <input type="date" id="data_fim" name="data_fim" class="form-control" value="<?php echo sanitizeOutput($mensalista['data_fim']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="valor">Valor</label>
                        <input type="number" id="valor" name="valor" class="form-control" step="0.01" min="0" value="<?php echo sanitizeOutput($mensalista['valor']); ?>">
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="observacoes">Observações</label>
                        <textarea id="observacoes" name="observacoes" class="form-control" rows="3"><?php echo sanitizeOutput($mensalista['observacoes']); ?></textarea>
                    </div>
                    
                    <div class="form-check mb-3">
                        <input type="checkbox" id="ativo" name="ativo" class="form-check-input" <?php echo $mensalista['ativo'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="ativo">Ativo</label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    <?php if (!empty($mensalista['id'])): ?>
                        <a href="mensalistas.php" class="btn btn-secondary">Cancelar</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Lista de Mensalistas</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Documento</th>
                                <th>Plano</th>
                                <th>Validade</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($mensalistas) > 0): ?>
                                <?php foreach ($mensalistas as $m): ?>
                                    <tr>
                                        <td><?php echo sanitizeOutput($m['nome']); ?></td>
                                        <td><?php echo sanitizeOutput($m['documento']); ?></td>
                                        <td><?php echo sanitizeOutput($m['plano']); ?></td>
                                        <td>
                                            <?php echo formatarData($m['data_inicio']); ?> a 
                                            <?php echo formatarData($m['data_fim']); ?>
                                        </td>
                                        <td>
                                            <?php if ($m['ativo']): ?>
                                                <span class="badge bg-success">Ativo</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Inativo</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="mensalistas.php?acao=editar&id=<?php echo $m['id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="mensalistas.php?acao=excluir&id=<?php echo $m['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir este mensalista?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center">Nenhum mensalista cadastrado.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Atualizar data de fim com base no plano selecionado
    document.getElementById('plano').addEventListener('change', function() {
        const plano = this.value;
        const dataInicio = document.getElementById('data_inicio').value;
        
        if (dataInicio) {
            const inicio = new Date(dataInicio);
            let fim = new Date(inicio);
            
            switch (plano) {
                case 'Mensal':
                    fim.setMonth(inicio.getMonth() + 1);
                    break;
                case 'Trimestral':
                    fim.setMonth(inicio.getMonth() + 3);
                    break;
                case 'Semestral':
                    fim.setMonth(inicio.getMonth() + 6);
                    break;
                case 'Anual':
                    fim.setFullYear(inicio.getFullYear() + 1);
                    break;
            }
            
            document.getElementById('data_fim').value = fim.toISOString().split('T')[0];
        }
    });
    
    // Atualizar data de fim quando a data de início mudar
    document.getElementById('data_inicio').addEventListener('change', function() {
        const planoSelect = document.getElementById('plano');
        planoSelect.dispatchEvent(new Event('change'));
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>
