<?php
/**
 * Página de gestão de veículos
 */
$tituloPagina = 'Veículos - Sistema de Estacionamento';
require_once '../includes/header.php';
require_once '../config/database.php';

// Verificar permissão
requirePermission('operador');

// Processar ações
$acao = $_GET['acao'] ?? '';
$mensagem = '';
$tipoMensagem = '';

// Obter empresa atual
$empresaId = getCurrentEmpresaId();

// Processar formulário de entrada de veículo
if (isPostRequest() && isset($_POST['form_entrada'])) {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $placa = $_POST['placa'] ?? '';
            $modelo = $_POST['modelo'] ?? '';
            $cor = $_POST['cor'] ?? '';
            $tipoCliente = $_POST['tipo_cliente'] ?? 'normal';
            $telefone = $_POST['telefone'] ?? '';
            $ticket = $_POST['ticket'] ?? '';
            
            // Validar dados
            if (empty($placa) || empty($modelo) || empty($cor)) {
                $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
                $tipoMensagem = 'danger';
            } else {
                // Verificar se o veículo já está no estacionamento
                $queryVerificar = "SELECT id FROM veiculos 
                                  WHERE placa = :placa 
                                  AND empresa_id = :empresa_id 
                                  AND saida IS NULL";
                $stmtVerificar = $conn->prepare($queryVerificar);
                $stmtVerificar->bindParam(':placa', $placa);
                $stmtVerificar->bindParam(':empresa_id', $empresaId);
                $stmtVerificar->execute();
                
                if ($stmtVerificar->rowCount() > 0) {
                    $mensagem = 'Este veículo já está no estacionamento.';
                    $tipoMensagem = 'danger';
                } else {
                    // Inserir veículo
                    $query = "INSERT INTO veiculos (placa, modelo, cor, tipo_cliente, telefone, ticket, entrada, empresa_id) 
                              VALUES (:placa, :modelo, :cor, :tipo_cliente, :telefone, :ticket, NOW(), :empresa_id)";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':placa', $placa);
                    $stmt->bindParam(':modelo', $modelo);
                    $stmt->bindParam(':cor', $cor);
                    $stmt->bindParam(':tipo_cliente', $tipoCliente);
                    $stmt->bindParam(':telefone', $telefone);
                    $stmt->bindParam(':ticket', $ticket);
                    $stmt->bindParam(':empresa_id', $empresaId);
                    $stmt->execute();
                    
                    $mensagem = 'Entrada de veículo registrada com sucesso!';
                    $tipoMensagem = 'success';
                }
            }
        } catch (PDOException $e) {
            logError('Erro ao registrar entrada de veículo', $e);
            $mensagem = 'Erro ao registrar entrada de veículo. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
        }
    }
}

// Processar formulário de saída de veículo
if (isPostRequest() && isset($_POST['form_saida'])) {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $veiculoId = $_POST['veiculo_id'] ?? '';
            $formaPagamento = $_POST['forma_pagamento'] ?? '';
            $valorTotal = $_POST['valor_total'] ?? 0;
            
            // Validar dados
            if (empty($veiculoId) || empty($formaPagamento)) {
                $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
                $tipoMensagem = 'danger';
            } else {
                // Atualizar veículo
                $query = "UPDATE veiculos 
                          SET saida = NOW(), 
                              forma_pagamento = :forma_pagamento, 
                              valor_total = :valor_total 
                          WHERE id = :id 
                          AND empresa_id = :empresa_id 
                          AND saida IS NULL";
                $stmt = $conn->prepare($query);
                $stmt->bindParam(':forma_pagamento', $formaPagamento);
                $stmt->bindParam(':valor_total', $valorTotal);
                $stmt->bindParam(':id', $veiculoId);
                $stmt->bindParam(':empresa_id', $empresaId);
                $stmt->execute();
                
                if ($stmt->rowCount() > 0) {
                    $mensagem = 'Saída de veículo registrada com sucesso!';
                    $tipoMensagem = 'success';
                } else {
                    $mensagem = 'Veículo não encontrado ou já registrou saída.';
                    $tipoMensagem = 'danger';
                }
            }
        } catch (PDOException $e) {
            logError('Erro ao registrar saída de veículo', $e);
            $mensagem = 'Erro ao registrar saída de veículo. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
        }
    }
}

// Obter veículos no estacionamento
try {
    $conn = getConnection();
    
    $query = "SELECT id, placa, modelo, cor, tipo_cliente, telefone, ticket, entrada 
              FROM veiculos 
              WHERE empresa_id = :empresa_id 
              AND saida IS NULL 
              ORDER BY entrada DESC";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':empresa_id', $empresaId);
    $stmt->execute();
    $veiculos = $stmt->fetchAll();
} catch (PDOException $e) {
    logError('Erro ao obter veículos', $e);
    $veiculos = [];
}

// Obter tabela de preços ativa
try {
    $conn = getConnection();
    
    $query = "SELECT id, nome, valor_primeira_hora, valor_hora_adicional, valor_diaria 
              FROM precos 
              WHERE empresa_id = :empresa_id 
              AND ativo = 1 
              LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':empresa_id', $empresaId);
    $stmt->execute();
    $tabelaPrecos = $stmt->fetch();
} catch (PDOException $e) {
    logError('Erro ao obter tabela de preços', $e);
    $tabelaPrecos = null;
}
?>

<h1 class="mb-4">Gestão de Veículos</h1>

<?php if (!empty($mensagem)): ?>
    <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
        <?php echo $mensagem; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Registrar Entrada</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="veiculos.php">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    <input type="hidden" name="form_entrada" value="1">
                    
                    <div class="form-group mb-3">
                        <label for="placa">Placa*</label>
                        <input type="text" id="placa" name="placa" class="form-control" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="modelo">Modelo*</label>
                        <input type="text" id="modelo" name="modelo" class="form-control" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="cor">Cor*</label>
                        <input type="text" id="cor" name="cor" class="form-control" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="tipo_cliente">Tipo de Cliente</label>
                        <select id="tipo_cliente" name="tipo_cliente" class="form-control">
                            <option value="normal">Normal</option>
                            <option value="mensalista">Mensalista</option>
                            <option value="isento">Isento</option>
                        </select>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="telefone">Telefone</label>
                        <input type="text" id="telefone" name="telefone" class="form-control">
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="ticket">Ticket</label>
                        <input type="text" id="ticket" name="ticket" class="form-control">
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Registrar Entrada</button>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Registrar Saída</h5>
            </div>
            <div class="card-body">
                <form method="POST" action="veiculos.php" id="form-saida">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    <input type="hidden" name="form_saida" value="1">
                    <input type="hidden" name="veiculo_id" id="veiculo_id">
                    
                    <div class="form-group mb-3">
                        <label for="placa_saida">Placa*</label>
                        <select id="placa_saida" name="placa_saida" class="form-control" required>
                            <option value="">Selecione um veículo</option>
                            <?php foreach ($veiculos as $veiculo): ?>
                                <option value="<?php echo $veiculo['id']; ?>" 
                                        data-entrada="<?php echo $veiculo['entrada']; ?>"
                                        data-tipo="<?php echo $veiculo['tipo_cliente']; ?>">
                                    <?php echo sanitizeOutput($veiculo['placa']); ?> - 
                                    <?php echo sanitizeOutput($veiculo['modelo']); ?> - 
                                    <?php echo sanitizeOutput($veiculo['cor']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="entrada">Entrada</label>
                        <input type="text" id="entrada" class="form-control" readonly>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="permanencia">Permanência</label>
                        <input type="text" id="permanencia" class="form-control" readonly>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="valor_total">Valor Total</label>
                        <input type="number" id="valor_total" name="valor_total" class="form-control" step="0.01" min="0">
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="forma_pagamento">Forma de Pagamento*</label>
                        <select id="forma_pagamento" name="forma_pagamento" class="form-control" required>
                            <option value="">Selecione</option>
                            <option value="dinheiro">Dinheiro</option>
                            <option value="cartao_credito">Cartão de Crédito</option>
                            <option value="cartao_debito">Cartão de Débito</option>
                            <option value="pix">PIX</option>
                            <option value="mensalidade">Mensalidade</option>
                            <option value="isento">Isento</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Registrar Saída</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Veículos no Estacionamento</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Placa</th>
                                <th>Modelo</th>
                                <th>Cor</th>
                                <th>Tipo</th>
                                <th>Entrada</th>
                                <th>Permanência</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($veiculos) > 0): ?>
                                <?php foreach ($veiculos as $veiculo): ?>
                                    <tr>
                                        <td><?php echo sanitizeOutput($veiculo['placa']); ?></td>
                                        <td><?php echo sanitizeOutput($veiculo['modelo']); ?></td>
                                        <td><?php echo sanitizeOutput($veiculo['cor']); ?></td>
                                        <td>
                                            <?php 
                                                switch ($veiculo['tipo_cliente']) {
                                                    case 'mensalista':
                                                        echo '<span class="badge bg-success">Mensalista</span>';
                                                        break;
                                                    case 'isento':
                                                        echo '<span class="badge bg-warning">Isento</span>';
                                                        break;
                                                    default:
                                                        echo '<span class="badge bg-primary">Normal</span>';
                                                }
                                            ?>
                                        </td>
                                        <td><?php echo formatarData($veiculo['entrada'], true); ?></td>
                                        <td class="permanencia" data-entrada="<?php echo $veiculo['entrada']; ?>">
                                            Calculando...
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-primary btn-registrar-saida" 
                                                    data-id="<?php echo $veiculo['id']; ?>"
                                                    data-placa="<?php echo sanitizeOutput($veiculo['placa']); ?>"
                                                    data-tipo="<?php echo $veiculo['tipo_cliente']; ?>"
                                                    data-entrada="<?php echo $veiculo['entrada']; ?>">
                                                Registrar Saída
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center">Nenhum veículo no estacionamento.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Tabela de preços
    const tabelaPrecos = {
        valorPrimeiraHora: <?php echo $tabelaPrecos ? $tabelaPrecos['valor_primeira_hora'] : 0; ?>,
        valorHoraAdicional: <?php echo $tabelaPrecos ? $tabelaPrecos['valor_hora_adicional'] : 0; ?>,
        valorDiaria: <?php echo $tabelaPrecos ? $tabelaPrecos['valor_diaria'] : 0; ?>
    };
    
    // Função para calcular permanência
    function calcularPermanencia(dataEntrada) {
        const entrada = new Date(dataEntrada);
        const agora = new Date();
        
        const diff = agora - entrada;
        const minutos = Math.floor(diff / 60000);
        const horas = Math.floor(minutos / 60);
        const minutosRestantes = minutos % 60;
        
        return `${horas}h ${minutosRestantes}min`;
    }
    
    // Função para calcular valor
    function calcularValor(dataEntrada, tipoCliente) {
        if (tipoCliente === 'mensalista' || tipoCliente === 'isento') {
            return 0;
        }
        
        const entrada = new Date(dataEntrada);
        const agora = new Date();
        
        const diff = agora - entrada;
        const minutos = Math.floor(diff / 60000);
        const horas = Math.ceil(minutos / 60);
        
        if (horas <= 24) {
            if (horas <= 1) {
                return tabelaPrecos.valorPrimeiraHora;
            } else {
                return tabelaPrecos.valorPrimeiraHora + (horas - 1) * tabelaPrecos.valorHoraAdicional;
            }
        } else {
            const dias = Math.ceil(horas / 24);
            return dias * tabelaPrecos.valorDiaria;
        }
    }
    
    // Atualizar permanência para todos os veículos na tabela
    document.querySelectorAll('.permanencia').forEach(function(element) {
        const dataEntrada = element.getAttribute('data-entrada');
        element.textContent = calcularPermanencia(dataEntrada);
        
        // Atualizar a cada minuto
        setInterval(function() {
            element.textContent = calcularPermanencia(dataEntrada);
        }, 60000);
    });
    
    // Selecionar veículo para saída
    document.getElementById('placa_saida').addEventListener('change', function() {
        const veiculoId = this.value;
        const option = this.options[this.selectedIndex];
        
        if (veiculoId) {
            const dataEntrada = option.getAttribute('data-entrada');
            const tipoCliente = option.getAttribute('data-tipo');
            
            document.getElementById('veiculo_id').value = veiculoId;
            document.getElementById('entrada').value = new Date(dataEntrada).toLocaleString('pt-BR');
            document.getElementById('permanencia').value = calcularPermanencia(dataEntrada);
            
            const valor = calcularValor(dataEntrada, tipoCliente);
            document.getElementById('valor_total').value = valor.toFixed(2);
            
            // Pré-selecionar forma de pagamento com base no tipo de cliente
            const formaPagamento = document.getElementById('forma_pagamento');
            if (tipoCliente === 'mensalista') {
                formaPagamento.value = 'mensalidade';
            } else if (tipoCliente === 'isento') {
                formaPagamento.value = 'isento';
            } else {
                formaPagamento.value = '';
            }
        } else {
            document.getElementById('veiculo_id').value = '';
            document.getElementById('entrada').value = '';
            document.getElementById('permanencia').value = '';
            document.getElementById('valor_total').value = '';
            document.getElementById('forma_pagamento').value = '';
        }
    });
    
    // Botões de registrar saída na tabela
    document.querySelectorAll('.btn-registrar-saida').forEach(function(button) {
        button.addEventListener('click', function() {
            const veiculoId = this.getAttribute('data-id');
            const dataEntrada = this.getAttribute('data-entrada');
            const tipoCliente = this.getAttribute('data-tipo');
            
            document.getElementById('veiculo_id').value = veiculoId;
            document.getElementById('placa_saida').value = veiculoId;
            document.getElementById('entrada').value = new Date(dataEntrada).toLocaleString('pt-BR');
            document.getElementById('permanencia').value = calcularPermanencia(dataEntrada);
            
            const valor = calcularValor(dataEntrada, tipoCliente);
            document.getElementById('valor_total').value = valor.toFixed(2);
            
            // Pré-selecionar forma de pagamento com base no tipo de cliente
            const formaPagamento = document.getElementById('forma_pagamento');
            if (tipoCliente === 'mensalista') {
                formaPagamento.value = 'mensalidade';
            } else if (tipoCliente === 'isento') {
                formaPagamento.value = 'isento';
            } else {
                formaPagamento.value = '';
            }
            
            // Rolar até o formulário de saída
            document.querySelector('.card-title:contains("Registrar Saída")').scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>
