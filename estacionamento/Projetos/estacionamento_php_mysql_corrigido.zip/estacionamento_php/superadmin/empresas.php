<?php
/**
 * Página de gestão de empresas do superadmin
 */
session_start();

// Incluir arquivo de configuração
require_once 'config.php';

// Verificar se está logado
requireSuperadminLogin();

// Incluir funções de banco de dados
require_once '../config/database.php';

// Inicializar variáveis
$mensagem = '';
$tipoMensagem = '';
$empresa = [
    'id' => '',
    'nome' => '',
    'cnpj' => '',
    'endereco' => '',
    'telefone' => '',
    'email' => '',
    'responsavel' => '',
    'logo' => '',
    'ativo' => 1,
    'data_cadastro' => date('Y-m-d H:i:s')
];

// Processar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? '';

// Processar exclusão
if ($acao === 'excluir' && !empty($id)) {
    try {
        $conn = getConnection();
        
        // Verificar se existem usuários vinculados
        $query = "SELECT COUNT(*) as total FROM usuarios WHERE empresa_id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $totalUsuarios = $stmt->fetch()['total'] ?? 0;
        
        if ($totalUsuarios > 0) {
            $mensagem = 'Não é possível excluir esta empresa pois existem usuários vinculados a ela.';
            $tipoMensagem = 'danger';
        } else {
            // Excluir empresa
            $query = "DELETE FROM empresas WHERE id = :id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            
            $mensagem = 'Empresa excluída com sucesso!';
            $tipoMensagem = 'success';
            
            // Registrar ação no log
            logSuperadminAction('Exclusão de empresa', "ID: $id");
        }
    } catch (PDOException $e) {
        $mensagem = 'Erro ao excluir empresa. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
        logError('Erro ao excluir empresa', $e);
    }
}

// Carregar dados para edição
if ($acao === 'editar' && !empty($id)) {
    try {
        $conn = getConnection();
        
        $query = "SELECT * FROM empresas WHERE id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        $result = $stmt->fetch();
        
        if ($result) {
            $empresa = $result;
        } else {
            $mensagem = 'Empresa não encontrada.';
            $tipoMensagem = 'danger';
        }
    } catch (PDOException $e) {
        $mensagem = 'Erro ao carregar dados da empresa. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
        logError('Erro ao carregar empresa para edição', $e);
    }
}

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifySuperadminCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $empresaId = $_POST['id'] ?? '';
            $nome = $_POST['nome'] ?? '';
            $cnpj = $_POST['cnpj'] ?? '';
            $endereco = $_POST['endereco'] ?? '';
            $telefone = $_POST['telefone'] ?? '';
            $email = $_POST['email'] ?? '';
            $responsavel = $_POST['responsavel'] ?? '';
            $ativo = isset($_POST['ativo']) ? 1 : 0;
            
            // Validar dados
            if (empty($nome) || empty($cnpj)) {
                $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
                $tipoMensagem = 'danger';
                
                // Manter dados do formulário
                $empresa = [
                    'id' => $empresaId,
                    'nome' => $nome,
                    'cnpj' => $cnpj,
                    'endereco' => $endereco,
                    'telefone' => $telefone,
                    'email' => $email,
                    'responsavel' => $responsavel,
                    'ativo' => $ativo
                ];
            } else {
                // Verificar se o CNPJ já existe
                $queryVerificar = "SELECT id FROM empresas WHERE cnpj = :cnpj AND id != :id";
                $stmtVerificar = $conn->prepare($queryVerificar);
                $stmtVerificar->bindParam(':cnpj', $cnpj);
                $stmtVerificar->bindParam(':id', $empresaId);
                $stmtVerificar->execute();
                
                if ($stmtVerificar->rowCount() > 0) {
                    $mensagem = 'Este CNPJ já está cadastrado para outra empresa.';
                    $tipoMensagem = 'danger';
                    
                    // Manter dados do formulário
                    $empresa = [
                        'id' => $empresaId,
                        'nome' => $nome,
                        'cnpj' => $cnpj,
                        'endereco' => $endereco,
                        'telefone' => $telefone,
                        'email' => $email,
                        'responsavel' => $responsavel,
                        'ativo' => $ativo
                    ];
                } else {
                    // Upload de logo, se houver
                    $logo = '';
                    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
                        $uploadDir = '../uploads/logos/';
                        
                        // Criar diretório se não existir
                        if (!file_exists($uploadDir)) {
                            mkdir($uploadDir, 0755, true);
                        }
                        
                        $fileName = uniqid() . '_' . basename($_FILES['logo']['name']);
                        $uploadFile = $uploadDir . $fileName;
                        
                        // Verificar se é uma imagem válida
                        $check = getimagesize($_FILES['logo']['tmp_name']);
                        if ($check !== false) {
                            if (move_uploaded_file($_FILES['logo']['tmp_name'], $uploadFile)) {
                                $logo = $fileName;
                            }
                        }
                    }
                    
                    if (empty($empresaId)) {
                        // Inserir nova empresa
                        $query = "INSERT INTO empresas (nome, cnpj, endereco, telefone, email, responsavel, logo, ativo, data_cadastro) 
                                  VALUES (:nome, :cnpj, :endereco, :telefone, :email, :responsavel, :logo, :ativo, NOW())";
                        $stmt = $conn->prepare($query);
                        $stmt->bindParam(':nome', $nome);
                        $stmt->bindParam(':cnpj', $cnpj);
                        $stmt->bindParam(':endereco', $endereco);
                        $stmt->bindParam(':telefone', $telefone);
                        $stmt->bindParam(':email', $email);
                        $stmt->bindParam(':responsavel', $responsavel);
                        $stmt->bindParam(':logo', $logo);
                        $stmt->bindParam(':ativo', $ativo);
                        $stmt->execute();
                        
                        $mensagem = 'Empresa cadastrada com sucesso!';
                        $tipoMensagem = 'success';
                        
                        // Registrar ação no log
                        logSuperadminAction('Cadastro de empresa', "Nome: $nome, CNPJ: $cnpj");
                        
                        // Limpar formulário após sucesso
                        $empresa = [
                            'id' => '',
                            'nome' => '',
                            'cnpj' => '',
                            'endereco' => '',
                            'telefone' => '',
                            'email' => '',
                            'responsavel' => '',
                            'logo' => '',
                            'ativo' => 1,
                            'data_cadastro' => date('Y-m-d H:i:s')
                        ];
                    } else {
                        // Atualizar empresa existente
                        if (!empty($logo)) {
                            $query = "UPDATE empresas 
                                      SET nome = :nome, 
                                          cnpj = :cnpj, 
                                          endereco = :endereco, 
                                          telefone = :telefone, 
                                          email = :email, 
                                          responsavel = :responsavel, 
                                          logo = :logo, 
                                          ativo = :ativo 
                                      WHERE id = :id";
                            $stmt = $conn->prepare($query);
                            $stmt->bindParam(':logo', $logo);
                        } else {
                            $query = "UPDATE empresas 
                                      SET nome = :nome, 
                                          cnpj = :cnpj, 
                                          endereco = :endereco, 
                                          telefone = :telefone, 
                                          email = :email, 
                                          responsavel = :responsavel, 
                                          ativo = :ativo 
                                      WHERE id = :id";
                            $stmt = $conn->prepare($query);
                        }
                        
                        $stmt->bindParam(':nome', $nome);
                        $stmt->bindParam(':cnpj', $cnpj);
                        $stmt->bindParam(':endereco', $endereco);
                        $stmt->bindParam(':telefone', $telefone);
                        $stmt->bindParam(':email', $email);
                        $stmt->bindParam(':responsavel', $responsavel);
                        $stmt->bindParam(':ativo', $ativo);
                        $stmt->bindParam(':id', $empresaId);
                        $stmt->execute();
                        
                        $mensagem = 'Empresa atualizada com sucesso!';
                        $tipoMensagem = 'success';
                        
                        // Registrar ação no log
                        logSuperadminAction('Atualização de empresa', "ID: $empresaId, Nome: $nome");
                        
                        // Limpar formulário após sucesso
                        $empresa = [
                            'id' => '',
                            'nome' => '',
                            'cnpj' => '',
                            'endereco' => '',
                            'telefone' => '',
                            'email' => '',
                            'responsavel' => '',
                            'logo' => '',
                            'ativo' => 1,
                            'data_cadastro' => date('Y-m-d H:i:s')
                        ];
                    }
                }
            }
        } catch (PDOException $e) {
            $mensagem = 'Erro ao salvar empresa. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
            logError('Erro ao salvar empresa', $e);
        }
    }
}

// Obter lista de empresas
try {
    $conn = getConnection();
    
    $query = "SELECT e.*, 
                    (SELECT COUNT(*) FROM usuarios u WHERE u.empresa_id = e.id) as total_usuarios,
                    (SELECT COUNT(*) FROM veiculos v WHERE v.empresa_id = e.id) as total_veiculos
              FROM empresas e 
              ORDER BY e.nome";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $empresas = $stmt->fetchAll();
} catch (PDOException $e) {
    $empresas = [];
    logError('Erro ao obter lista de empresas', $e);
}

// Função para formatar data
function formatarData($data, $incluirHora = false) {
    if (!$data) {
        return '-';
    }
    
    $date = new DateTime($data);
    
    if ($incluirHora) {
        return $date->format('d/m/Y H:i:s');
    }
    
    return $date->format('d/m/Y');
}

// Função para formatar CNPJ
function formatarCNPJ($cnpj) {
    $cnpj = preg_replace('/[^0-9]/', '', $cnpj);
    
    if (strlen($cnpj) === 14) {
        return preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $cnpj);
    }
    
    return $cnpj;
}

// Função para formatar telefone
function formatarTelefone($telefone) {
    $telefone = preg_replace('/[^0-9]/', '', $telefone);
    
    if (strlen($telefone) === 11) {
        return preg_replace('/(\d{2})(\d{5})(\d{4})/', '($1) $2-$3', $telefone);
    } elseif (strlen($telefone) === 10) {
        return preg_replace('/(\d{2})(\d{4})(\d{4})/', '($1) $2-$3', $telefone);
    }
    
    return $telefone;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Empresas - Superadmin</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        
        .superadmin-navbar {
            background-color: #212529;
            padding: 15px 10px;
        }
        
        .superadmin-sidebar {
            min-width: 250px;
            max-width: 250px;
            background: #343a40;
            color: #fff;
            transition: all 0.3s;
            height: 100vh;
            position: fixed;
            z-index: 999;
        }
        
        .superadmin-sidebar .sidebar-header {
            padding: 20px;
            background: #212529;
        }
        
        .superadmin-sidebar ul.components {
            padding: 20px 0;
            border-bottom: 1px solid #4b545c;
        }
        
        .superadmin-sidebar ul p {
            color: #fff;
            padding: 10px;
        }
        
        .superadmin-sidebar ul li a {
            padding: 10px;
            font-size: 1.1em;
            display: block;
            color: #fff;
            text-decoration: none;
        }
        
        .superadmin-sidebar ul li a:hover {
            color: #fff;
            background: #495057;
        }
        
        .superadmin-sidebar ul li.active > a {
            color: #fff;
            background: #dc3545;
        }
        
        .superadmin-content {
            width: 100%;
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s;
            margin-left: 250px;
        }
        
        .superadmin-content.active {
            margin-left: 0;
        }
        
        .superadmin-badge {
            background-color: #dc3545;
            color: #fff;
            padding: 2px 5px;
            border-radius: 4px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-left: 5px;
        }
        
        .company-logo {
            width: 50px;
            height: 50px;
            object-fit: contain;
            border-radius: 4px;
            background-color: #f8f9fa;
        }
        
        @media (max-width: 768px) {
            .superadmin-sidebar {
                margin-left: -250px;
            }
            .superadmin-sidebar.active {
                margin-left: 0;
            }
            .superadmin-content {
                margin-left: 0;
            }
            .superadmin-content.active {
                margin-left: 250px;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" class="superadmin-sidebar">
            <div class="sidebar-header">
                <h3>SUPERADMIN <span class="superadmin-badge">v1.0</span></h3>
            </div>
            
            <ul class="list-unstyled components">
                <li>
                    <a href="index.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
                </li>
                <li class="active">
                    <a href="empresas.php"><i class="fas fa-building me-2"></i> Empresas</a>
                </li>
                <li>
                    <a href="usuarios.php"><i class="fas fa-users me-2"></i> Usuários</a>
                </li>
                <li>
                    <a href="relatorios.php"><i class="fas fa-chart-bar me-2"></i> Relatórios</a>
                </li>
                <li>
                    <a href="configuracoes.php"><i class="fas fa-cogs me-2"></i> Configurações</a>
                </li>
                <li>
                    <a href="logs.php"><i class="fas fa-history me-2"></i> Logs do Sistema</a>
                </li>
                <li>
                    <a href="backup.php"><i class="fas fa-database me-2"></i> Backup</a>
                </li>
                <li>
                    <a href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a>
                </li>
            </ul>
        </nav>
        
        <!-- Page Content -->
        <div id="content" class="superadmin-content">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-dark superadmin-navbar">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <div class="ms-auto d-flex align-items-center">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle text-light" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-shield me-1"></i> Superadmin
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="perfil.php"><i class="fas fa-user-cog me-2"></i> Perfil</a></li>
                                <li><a class="dropdown-item" href="alterar_senha.php"><i class="fas fa-key me-2"></i> Alterar Senha</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            
            <h1 class="mb-4">Gestão de Empresas</h1>
            
            <?php if (!empty($mensagem)): ?>
                <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
                    <?php echo $mensagem; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                </div>
            <?php endif; ?>
            
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="card-title mb-0"><?php echo empty($empresa['id']) ? 'Nova Empresa' : 'Editar Empresa'; ?></h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="empresas.php" enctype="multipart/form-data">
                                <input type="hidden" name="csrf_token" value="<?php echo generateSuperadminCsrfToken(); ?>">
                                <input type="hidden" name="id" value="<?php echo htmlspecialchars($empresa['id']); ?>">
                                
                                <div class="mb-3">
                                    <label for="nome" class="form-label">Nome da Empresa*</label>
                                    <input type="text" class="form-control" id="nome" name="nome" value="<?php echo htmlspecialchars($empresa['nome']); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="cnpj" class="form-label">CNPJ*</label>
                                    <input type="text" class="form-control" id="cnpj" name="cnpj" value="<?php echo htmlspecialchars($empresa['cnpj']); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="endereco" class="form-label">Endereço</label>
                                    <input type="text" class="form-control" id="endereco" name="endereco" value="<?php echo htmlspecialchars($empresa['endereco']); ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="telefone" class="form-label">Telefone</label>
                                    <input type="text" class="form-control" id="telefone" name="telefone" value="<?php echo htmlspecialchars($empresa['telefone']); ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email" class="form-label">E-mail</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($empresa['email']); ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="responsavel" class="form-label">Responsável</label>
                                    <input type="text" class="form-control" id="responsavel" name="responsavel" value="<?php echo htmlspecialchars($empresa['responsavel']); ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="logo" class="form-label">Logo</label>
                                    <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
                                    <?php if (!empty($empresa['logo'])): ?>
                                        <div class="mt-2">
                                            <img src="../uploads/logos/<?php echo htmlspecialchars($empresa['logo']); ?>" alt="Logo atual" class="company-logo">
                                            <small class="text-muted">Logo atual</small>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="ativo" name="ativo" <?php echo $empresa['ativo'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="ativo">Empresa Ativa</label>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Salvar</button>
                                    <?php if (!empty($empresa['id'])): ?>
                                        <a href="empresas.php" class="btn btn-secondary">Cancelar</a>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="card-title mb-0">Lista de Empresas</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Logo</th>
                                            <th>Nome</th>
                                            <th>CNPJ</th>
                                            <th>Contato</th>
                                            <th>Status</th>
                                            <th>Usuários</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (count($empresas) > 0): ?>
                                            <?php foreach ($empresas as $emp): ?>
                                                <tr>
                                                    <td>
                                                        <?php if (!empty($emp['logo'])): ?>
                                                            <img src="../uploads/logos/<?php echo htmlspecialchars($emp['logo']); ?>" alt="Logo" class="company-logo">
                                                        <?php else: ?>
                                                            <div class="company-logo d-flex align-items-center justify-content-center bg-light">
                                                                <i class="fas fa-building text-secondary"></i>
                                                            </div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($emp['nome']); ?></td>
                                                    <td><?php echo formatarCNPJ($emp['cnpj']); ?></td>
                                                    <td>
                                                        <?php if (!empty($emp['telefone'])): ?>
                                                            <div><i class="fas fa-phone-alt me-1"></i> <?php echo formatarTelefone($emp['telefone']); ?></div>
                                                        <?php endif; ?>
                                                        <?php if (!empty($emp['email'])): ?>
                                                            <div><i class="fas fa-envelope me-1"></i> <?php echo htmlspecialchars($emp['email']); ?></div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if ($emp['ativo']): ?>
                                                            <span class="badge bg-success">Ativa</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-danger">Inativa</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-info"><?php echo $emp['total_usuarios']; ?> usuários</span>
                                                        <span class="badge bg-secondary"><?php echo $emp['total_veiculos']; ?> veículos</span>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group">
                                                            <a href="empresas.php?acao=editar&id=<?php echo $emp['id']; ?>" class="btn btn-sm btn-primary" title="Editar">
                                                                <i class="fas fa-edit"></i>
                                                            </a>
                                                            <?php if ($emp['total_usuarios'] == 0): ?>
                                                                <a href="empresas.php?acao=excluir&id=<?php echo $emp['id']; ?>" class="btn btn-sm btn-danger" title="Excluir" onclick="return confirm('Tem certeza que deseja excluir esta empresa?')">
                                                                    <i class="fas fa-trash"></i>
                                                                </a>
                                                            <?php else: ?>
                                                                <button class="btn btn-sm btn-danger" disabled title="Não é possível excluir empresas com usuários">
                                                                    <i class="fas fa-trash"></i>
                                                                </button>
                                                            <?php endif; ?>
                                                            <a href="usuarios.php?empresa_id=<?php echo $emp['id']; ?>" class="btn btn-sm btn-info" title="Gerenciar Usuários">
                                                                <i class="fas fa-users"></i>
                                                            </a>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="7" class="text-center">Nenhuma empresa cadastrada.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle sidebar
            document.getElementById('sidebarCollapse').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('active');
                document.getElementById('content').classList.toggle('active');
            });
            
            // Máscara para CNPJ
            const cnpjInput = document.getElementById('cnpj');
            if (cnpjInput) {
                cnpjInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    
                    if (value.length <= 14) {
                        value = value.replace(/(\d{2})(\d)/, '$1.$2');
                        value = value.replace(/(\d{3})(\d)/, '$1.$2');
                        value = value.replace(/(\d{3})(\d)/, '$1/$2');
                        value = value.replace(/(\d{4})(\d{1,2})$/, '$1-$2');
                    }
                    
                    e.target.value = value;
                });
            }
            
            // Máscara para telefone
            const telefoneInput = document.getElementById('telefone');
            if (telefoneInput) {
                telefoneInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    
                    if (value.length <= 11) {
                        if (value.length > 2) {
                            value = '(' + value.substring(0, 2) + ') ' + value.substring(2);
                        }
                        if (value.length > 10) {
                            value = value.substring(0, 10) + '-' + value.substring(10);
                        }
                    }
                    
                    e.target.value = value;
                });
            }
        });
    </script>
</body>
</html>
