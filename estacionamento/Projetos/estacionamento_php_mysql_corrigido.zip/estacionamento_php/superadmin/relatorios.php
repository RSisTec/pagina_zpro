<?php
/**
 * Página de relatórios do superadmin
 */
session_start();

// Incluir arquivo de configuração
require_once 'config.php';

// Verificar se está logado
requireSuperadminLogin();

// Incluir funções de banco de dados
require_once '../config/database.php';

// Inicializar variáveis
$tipoRelatorio = $_GET['tipo'] ?? 'geral';
$dataInicio = $_GET['data_inicio'] ?? date('Y-m-01'); // Primeiro dia do mês atual
$dataFim = $_GET['data_fim'] ?? date('Y-m-d'); // Dia atual
$empresaId = $_GET['empresa_id'] ?? '';

// Obter lista de empresas
try {
    $conn = getConnection();
    
    $query = "SELECT id, nome FROM empresas WHERE ativo = 1 ORDER BY nome";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $empresas = $stmt->fetchAll();
} catch (PDOException $e) {
    $empresas = [];
    logError('Erro ao obter lista de empresas para relatório', $e);
}

// Gerar relatório
$dadosRelatorio = [];
$tituloRelatorio = '';

try {
    $conn = getConnection();
    
    switch ($tipoRelatorio) {
        case 'faturamento':
            $tituloRelatorio = 'Relatório de Faturamento';
            
            $whereClause = "WHERE v.saida IS NOT NULL AND DATE(v.saida) BETWEEN :data_inicio AND :data_fim";
            $params = [
                ':data_inicio' => $dataInicio,
                ':data_fim' => $dataFim
            ];
            
            if (!empty($empresaId)) {
                $whereClause .= " AND v.empresa_id = :empresa_id";
                $params[':empresa_id'] = $empresaId;
            }
            
            // Faturamento por empresa
            $query = "SELECT e.nome as empresa, 
                             COUNT(v.id) as total_veiculos, 
                             SUM(v.valor_total) as faturamento_total,
                             AVG(v.valor_total) as ticket_medio
                      FROM veiculos v
                      JOIN empresas e ON v.empresa_id = e.id
                      $whereClause
                      GROUP BY e.id
                      ORDER BY faturamento_total DESC";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['por_empresa'] = $stmt->fetchAll();
            
            // Faturamento por dia
            $query = "SELECT DATE(v.saida) as data, 
                             COUNT(v.id) as total_veiculos, 
                             SUM(v.valor_total) as faturamento_total
                      FROM veiculos v
                      $whereClause
                      GROUP BY DATE(v.saida)
                      ORDER BY data";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['por_dia'] = $stmt->fetchAll();
            
            // Faturamento por forma de pagamento
            $query = "SELECT v.forma_pagamento, 
                             COUNT(v.id) as total_veiculos, 
                             SUM(v.valor_total) as faturamento_total
                      FROM veiculos v
                      $whereClause
                      GROUP BY v.forma_pagamento
                      ORDER BY faturamento_total DESC";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['por_pagamento'] = $stmt->fetchAll();
            
            // Total geral
            $query = "SELECT COUNT(v.id) as total_veiculos, 
                             SUM(v.valor_total) as faturamento_total,
                             AVG(v.valor_total) as ticket_medio
                      FROM veiculos v
                      $whereClause";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['total'] = $stmt->fetch();
            
            break;
            
        case 'veiculos':
            $tituloRelatorio = 'Relatório de Veículos';
            
            $whereClause = "WHERE DATE(v.entrada) BETWEEN :data_inicio AND :data_fim";
            $params = [
                ':data_inicio' => $dataInicio,
                ':data_fim' => $dataFim
            ];
            
            if (!empty($empresaId)) {
                $whereClause .= " AND v.empresa_id = :empresa_id";
                $params[':empresa_id'] = $empresaId;
            }
            
            // Veículos por empresa
            $query = "SELECT e.nome as empresa, 
                             COUNT(v.id) as total_veiculos,
                             SUM(CASE WHEN v.saida IS NOT NULL THEN 1 ELSE 0 END) as veiculos_saida,
                             SUM(CASE WHEN v.saida IS NULL THEN 1 ELSE 0 END) as veiculos_estacionados
                      FROM veiculos v
                      JOIN empresas e ON v.empresa_id = e.id
                      $whereClause
                      GROUP BY e.id
                      ORDER BY total_veiculos DESC";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['por_empresa'] = $stmt->fetchAll();
            
            // Veículos por dia
            $query = "SELECT DATE(v.entrada) as data, 
                             COUNT(v.id) as total_veiculos
                      FROM veiculos v
                      $whereClause
                      GROUP BY DATE(v.entrada)
                      ORDER BY data";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['por_dia'] = $stmt->fetchAll();
            
            // Tempo médio de permanência
            $query = "SELECT e.nome as empresa,
                             AVG(TIMESTAMPDIFF(MINUTE, v.entrada, v.saida)) as tempo_medio_minutos
                      FROM veiculos v
                      JOIN empresas e ON v.empresa_id = e.id
                      $whereClause AND v.saida IS NOT NULL
                      GROUP BY e.id
                      ORDER BY tempo_medio_minutos DESC";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['tempo_medio'] = $stmt->fetchAll();
            
            // Total geral
            $query = "SELECT COUNT(v.id) as total_veiculos,
                             SUM(CASE WHEN v.saida IS NOT NULL THEN 1 ELSE 0 END) as veiculos_saida,
                             SUM(CASE WHEN v.saida IS NULL THEN 1 ELSE 0 END) as veiculos_estacionados,
                             AVG(CASE WHEN v.saida IS NOT NULL THEN TIMESTAMPDIFF(MINUTE, v.entrada, v.saida) ELSE NULL END) as tempo_medio_minutos
                      FROM veiculos v
                      $whereClause";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['total'] = $stmt->fetch();
            
            break;
            
        case 'mensalistas':
            $tituloRelatorio = 'Relatório de Mensalistas';
            
            $whereClause = "WHERE 1=1";
            $params = [];
            
            if (!empty($empresaId)) {
                $whereClause .= " AND m.empresa_id = :empresa_id";
                $params[':empresa_id'] = $empresaId;
            }
            
            // Mensalistas por empresa
            $query = "SELECT e.nome as empresa, 
                             COUNT(m.id) as total_mensalistas,
                             SUM(CASE WHEN m.ativo = 1 THEN 1 ELSE 0 END) as mensalistas_ativos,
                             SUM(CASE WHEN m.ativo = 0 THEN 1 ELSE 0 END) as mensalistas_inativos
                      FROM mensalistas m
                      JOIN empresas e ON m.empresa_id = e.id
                      $whereClause
                      GROUP BY e.id
                      ORDER BY total_mensalistas DESC";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['por_empresa'] = $stmt->fetchAll();
            
            // Mensalistas por plano
            $query = "SELECT m.plano, 
                             COUNT(m.id) as total_mensalistas
                      FROM mensalistas m
                      $whereClause
                      GROUP BY m.plano
                      ORDER BY total_mensalistas DESC";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['por_plano'] = $stmt->fetchAll();
            
            // Total geral
            $query = "SELECT COUNT(m.id) as total_mensalistas,
                             SUM(CASE WHEN m.ativo = 1 THEN 1 ELSE 0 END) as mensalistas_ativos,
                             SUM(CASE WHEN m.ativo = 0 THEN 1 ELSE 0 END) as mensalistas_inativos
                      FROM mensalistas m
                      $whereClause";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['total'] = $stmt->fetch();
            
            break;
            
        case 'usuarios':
            $tituloRelatorio = 'Relatório de Usuários';
            
            $whereClause = "WHERE 1=1";
            $params = [];
            
            if (!empty($empresaId)) {
                $whereClause .= " AND u.empresa_id = :empresa_id";
                $params[':empresa_id'] = $empresaId;
            }
            
            // Usuários por empresa
            $query = "SELECT e.nome as empresa, 
                             COUNT(u.id) as total_usuarios,
                             SUM(CASE WHEN u.nivel = 'admin' THEN 1 ELSE 0 END) as total_admins,
                             SUM(CASE WHEN u.nivel = 'operador' THEN 1 ELSE 0 END) as total_operadores,
                             SUM(CASE WHEN u.ativo = 1 THEN 1 ELSE 0 END) as usuarios_ativos,
                             SUM(CASE WHEN u.ativo = 0 THEN 1 ELSE 0 END) as usuarios_inativos
                      FROM usuarios u
                      JOIN empresas e ON u.empresa_id = e.id
                      $whereClause
                      GROUP BY e.id
                      ORDER BY total_usuarios DESC";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['por_empresa'] = $stmt->fetchAll();
            
            // Usuários por nível
            $query = "SELECT u.nivel, 
                             COUNT(u.id) as total_usuarios
                      FROM usuarios u
                      $whereClause
                      GROUP BY u.nivel
                      ORDER BY total_usuarios DESC";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['por_nivel'] = $stmt->fetchAll();
            
            // Total geral
            $query = "SELECT COUNT(u.id) as total_usuarios,
                             SUM(CASE WHEN u.nivel = 'admin' THEN 1 ELSE 0 END) as total_admins,
                             SUM(CASE WHEN u.nivel = 'operador' THEN 1 ELSE 0 END) as total_operadores,
                             SUM(CASE WHEN u.ativo = 1 THEN 1 ELSE 0 END) as usuarios_ativos,
                             SUM(CASE WHEN u.ativo = 0 THEN 1 ELSE 0 END) as usuarios_inativos
                      FROM usuarios u
                      $whereClause";
            
            $stmt = $conn->prepare($query);
            
            foreach ($params as $param => $value) {
                $stmt->bindValue($param, $value);
            }
            
            $stmt->execute();
            $dadosRelatorio['total'] = $stmt->fetch();
            
            break;
            
        default: // Relatório geral
            $tituloRelatorio = 'Relatório Geral do Sistema';
            
            // Total de empresas
            $query = "SELECT COUNT(*) as total, 
                             SUM(CASE WHEN ativo = 1 THEN 1 ELSE 0 END) as ativas,
                             SUM(CASE WHEN ativo = 0 THEN 1 ELSE 0 END) as inativas
                      FROM empresas";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $dadosRelatorio['empresas'] = $stmt->fetch();
            
            // Total de usuários
            $query = "SELECT COUNT(*) as total, 
                             SUM(CASE WHEN nivel = 'admin' THEN 1 ELSE 0 END) as admins,
                             SUM(CASE WHEN nivel = 'operador' THEN 1 ELSE 0 END) as operadores,
                             SUM(CASE WHEN ativo = 1 THEN 1 ELSE 0 END) as ativos,
                             SUM(CASE WHEN ativo = 0 THEN 1 ELSE 0 END) as inativos
                      FROM usuarios";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $dadosRelatorio['usuarios'] = $stmt->fetch();
            
            // Total de veículos
            $query = "SELECT COUNT(*) as total, 
                             SUM(CASE WHEN saida IS NOT NULL THEN 1 ELSE 0 END) as saida,
                             SUM(CASE WHEN saida IS NULL THEN 1 ELSE 0 END) as estacionados
                      FROM veiculos";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $dadosRelatorio['veiculos'] = $stmt->fetch();
            
            // Total de mensalistas
            $query = "SELECT COUNT(*) as total, 
                             SUM(CASE WHEN ativo = 1 THEN 1 ELSE 0 END) as ativos,
                             SUM(CASE WHEN ativo = 0 THEN 1 ELSE 0 END) as inativos
                      FROM mensalistas";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $dadosRelatorio['mensalistas'] = $stmt->fetch();
            
            // Faturamento total
            $query = "SELECT SUM(valor_total) as total FROM veiculos WHERE saida IS NOT NULL";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $dadosRelatorio['faturamento'] = $stmt->fetch();
            
            // Estatísticas por empresa
            $query = "SELECT e.id, e.nome, 
                             (SELECT COUNT(*) FROM usuarios u WHERE u.empresa_id = e.id) as total_usuarios,
                             (SELECT COUNT(*) FROM veiculos v WHERE v.empresa_id = e.id) as total_veiculos,
                             (SELECT COUNT(*) FROM mensalistas m WHERE m.empresa_id = e.id) as total_mensalistas,
                             (SELECT SUM(valor_total) FROM veiculos v WHERE v.empresa_id = e.id AND v.saida IS NOT NULL) as faturamento
                      FROM empresas e
                      ORDER BY e.nome";
            $stmt = $conn->prepare($query);
            $stmt->execute();
            $dadosRelatorio['por_empresa'] = $stmt->fetchAll();
            
            break;
    }
} catch (PDOException $e) {
    logError('Erro ao gerar relatório', $e);
}

// Função para formatar data
function formatarData($data, $incluirHora = false) {
    if (!$data) {
        return '-';
    }
    
    $date = new DateTime($data);
    
    if ($incluirHora) {
        return $date->format('d/m/Y H:i:s');
    }
    
    return $date->format('d/m/Y');
}

// Função para formatar moeda
function formatarMoeda($valor) {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

// Função para formatar tempo em minutos
function formatarTempo($minutos) {
    if (!$minutos) {
        return '-';
    }
    
    $horas = floor($minutos / 60);
    $min = $minutos % 60;
    
    return $horas . 'h ' . $min . 'min';
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - Superadmin</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        
        .superadmin-navbar {
            background-color: #212529;
            padding: 15px 10px;
        }
        
        .superadmin-sidebar {
            min-width: 250px;
            max-width: 250px;
            background: #343a40;
            color: #fff;
            transition: all 0.3s;
            height: 100vh;
            position: fixed;
            z-index: 999;
        }
        
        .superadmin-sidebar .sidebar-header {
            padding: 20px;
            background: #212529;
        }
        
        .superadmin-sidebar ul.components {
            padding: 20px 0;
            border-bottom: 1px solid #4b545c;
        }
        
        .superadmin-sidebar ul p {
            color: #fff;
            padding: 10px;
        }
        
        .superadmin-sidebar ul li a {
            padding: 10px;
            font-size: 1.1em;
            display: block;
            color: #fff;
            text-decoration: none;
        }
        
        .superadmin-sidebar ul li a:hover {
            color: #fff;
            background: #495057;
        }
        
        .superadmin-sidebar ul li.active > a {
            color: #fff;
            background: #dc3545;
        }
        
        .superadmin-content {
            width: 100%;
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s;
            margin-left: 250px;
        }
        
        .superadmin-content.active {
            margin-left: 0;
        }
        
        .superadmin-badge {
            background-color: #dc3545;
            color: #fff;
            padding: 2px 5px;
            border-radius: 4px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-left: 5px;
        }
        
        .report-card {
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .report-card .card-header {
            border-bottom: 1px solid rgba(0, 0, 0, 0.125);
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .report-card .card-body {
            padding: 20px;
        }
        
        .report-stats {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .stat-box {
            flex: 1;
            min-width: 200px;
            padding: 15px;
            border-radius: 8px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        
        .stat-box h3 {
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .stat-box p {
            margin-bottom: 0;
            color: #6c757d;
        }
        
        .bg-info-light {
            background-color: #cff4fc;
            color: #055160;
        }
        
        .bg-success-light {
            background-color: #d1e7dd;
            color: #0f5132;
        }
        
        .bg-warning-light {
            background-color: #fff3cd;
            color: #664d03;
        }
        
        .bg-danger-light {
            background-color: #f8d7da;
            color: #842029;
        }
        
        @media (max-width: 768px) {
            .superadmin-sidebar {
                margin-left: -250px;
            }
            .superadmin-sidebar.active {
                margin-left: 0;
            }
            .superadmin-content {
                margin-left: 0;
            }
            .superadmin-content.active {
                margin-left: 250px;
            }
        }
        
        @media print {
            .superadmin-sidebar, .superadmin-navbar, .report-filter, .no-print {
                display: none !important;
            }
            
            .superadmin-content {
                margin-left: 0 !important;
                padding: 0 !important;
            }
            
            .report-card {
                box-shadow: none !important;
                border: 1px solid #ddd !important;
                margin-bottom: 20px !important;
                break-inside: avoid !important;
            }
            
            body {
                background-color: #fff !important;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" class="superadmin-sidebar">
            <div class="sidebar-header">
                <h3>SUPERADMIN <span class="superadmin-badge">v1.0</span></h3>
            </div>
            
            <ul class="list-unstyled components">
                <li>
                    <a href="index.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
                </li>
                <li>
                    <a href="empresas.php"><i class="fas fa-building me-2"></i> Empresas</a>
                </li>
                <li>
                    <a href="usuarios.php"><i class="fas fa-users me-2"></i> Usuários</a>
                </li>
                <li class="active">
                    <a href="relatorios.php"><i class="fas fa-chart-bar me-2"></i> Relatórios</a>
                </li>
                <li>
                    <a href="configuracoes.php"><i class="fas fa-cogs me-2"></i> Configurações</a>
                </li>
                <li>
                    <a href="logs.php"><i class="fas fa-history me-2"></i> Logs do Sistema</a>
                </li>
                <li>
                    <a href="backup.php"><i class="fas fa-database me-2"></i> Backup</a>
                </li>
                <li>
                    <a href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a>
                </li>
            </ul>
        </nav>
        
        <!-- Page Content -->
        <div id="content" class="superadmin-content">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-dark superadmin-navbar">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <div class="ms-auto d-flex align-items-center">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle text-light" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-shield me-1"></i> Superadmin
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="perfil.php"><i class="fas fa-user-cog me-2"></i> Perfil</a></li>
                                <li><a class="dropdown-item" href="alterar_senha.php"><i class="fas fa-key me-2"></i> Alterar Senha</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1><?php echo $tituloRelatorio; ?></h1>
                <div>
                    <button class="btn btn-primary" onclick="window.print()">
                        <i class="fas fa-print me-2"></i> Imprimir
                    </button>
                </div>
            </div>
            
            <!-- Filtros de Relatório -->
            <div class="card mb-4 report-filter">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Filtros</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="relatorios.php" class="row g-3">
                        <div class="col-md-3">
                            <label for="tipo" class="form-label">Tipo de Relatório</label>
                            <select name="tipo" id="tipo" class="form-control">
                                <option value="geral" <?php echo $tipoRelatorio === 'geral' ? 'selected' : ''; ?>>Relatório Geral</option>
                                <option value="faturamento" <?php echo $tipoRelatorio === 'faturamento' ? 'selected' : ''; ?>>Faturamento</option>
                                <option value="veiculos" <?php echo $tipoRelatorio === 'veiculos' ? 'selected' : ''; ?>>Veículos</option>
                                <option value="mensalistas" <?php echo $tipoRelatorio === 'mensalistas' ? 'selected' : ''; ?>>Mensalistas</option>
                                <option value="usuarios" <?php echo $tipoRelatorio === 'usuarios' ? 'selected' : ''; ?>>Usuários</option>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label for="empresa_id" class="form-label">Empresa</label>
                            <select name="empresa_id" id="empresa_id" class="form-control">
                                <option value="">Todas as Empresas</option>
                                <?php foreach ($empresas as $emp): ?>
                                    <option value="<?php echo $emp['id']; ?>" <?php echo $empresaId == $emp['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($emp['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-2">
                            <label for="data_inicio" class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" id="data_inicio" class="form-control" value="<?php echo $dataInicio; ?>">
                        </div>
                        
                        <div class="col-md-2">
                            <label for="data_fim" class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" id="data_fim" class="form-control" value="<?php echo $dataFim; ?>">
                        </div>
                        
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Gerar Relatório</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Conteúdo do Relatório -->
            <div class="report-content">
                <?php if ($tipoRelatorio === 'geral'): ?>
                    <!-- Relatório Geral -->
                    <div class="report-stats">
                        <div class="stat-box bg-info-light">
                            <h3><?php echo $dadosRelatorio['empresas']['total'] ?? 0; ?></h3>
                            <p>Empresas</p>
                            <small>
                                <?php echo $dadosRelatorio['empresas']['ativas'] ?? 0; ?> ativas / 
                                <?php echo $dadosRelatorio['empresas']['inativas'] ?? 0; ?> inativas
                            </small>
                        </div>
                        
                        <div class="stat-box bg-success-light">
                            <h3><?php echo $dadosRelatorio['usuarios']['total'] ?? 0; ?></h3>
                            <p>Usuários</p>
                            <small>
                                <?php echo $dadosRelatorio['usuarios']['admins'] ?? 0; ?> admins / 
                                <?php echo $dadosRelatorio['usuarios']['operadores'] ?? 0; ?> operadores
                            </small>
                        </div>
                        
                        <div class="stat-box bg-warning-light">
                            <h3><?php echo $dadosRelatorio['veiculos']['total'] ?? 0; ?></h3>
                            <p>Veículos</p>
                            <small>
                                <?php echo $dadosRelatorio['veiculos']['saida'] ?? 0; ?> saídas / 
                                <?php echo $dadosRelatorio['veiculos']['estacionados'] ?? 0; ?> estacionados
                            </small>
                        </div>
                        
                        <div class="stat-box bg-danger-light">
                            <h3><?php echo formatarMoeda($dadosRelatorio['faturamento']['total'] ?? 0); ?></h3>
                            <p>Faturamento Total</p>
                        </div>
                    </div>
                    
                    <div class="card report-card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Estatísticas por Empresa</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Empresa</th>
                                            <th>Usuários</th>
                                            <th>Veículos</th>
                                            <th>Mensalistas</th>
                                            <th>Faturamento</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (isset($dadosRelatorio['por_empresa']) && count($dadosRelatorio['por_empresa']) > 0): ?>
                                            <?php foreach ($dadosRelatorio['por_empresa'] as $empresa): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($empresa['nome']); ?></td>
                                                    <td><?php echo $empresa['total_usuarios'] ?? 0; ?></td>
                                                    <td><?php echo $empresa['total_veiculos'] ?? 0; ?></td>
                                                    <td><?php echo $empresa['total_mensalistas'] ?? 0; ?></td>
                                                    <td><?php echo formatarMoeda($empresa['faturamento'] ?? 0); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="5" class="text-center">Nenhum dado disponível.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif ($tipoRelatorio === 'faturamento'): ?>
                    <!-- Relatório de Faturamento -->
                    <div class="report-stats">
                        <div class="stat-box bg-info-light">
                            <h3><?php echo $dadosRelatorio['total']['total_veiculos'] ?? 0; ?></h3>
                            <p>Veículos</p>
                        </div>
                        
                        <div class="stat-box bg-success-light">
                            <h3><?php echo formatarMoeda($dadosRelatorio['total']['faturamento_total'] ?? 0); ?></h3>
                            <p>Faturamento Total</p>
                        </div>
                        
                        <div class="stat-box bg-warning-light">
                            <h3><?php echo formatarMoeda($dadosRelatorio['total']['ticket_medio'] ?? 0); ?></h3>
                            <p>Ticket Médio</p>
                        </div>
                    </div>
                    
                    <div class="card report-card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Faturamento por Empresa</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Empresa</th>
                                            <th>Veículos</th>
                                            <th>Faturamento</th>
                                            <th>Ticket Médio</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (isset($dadosRelatorio['por_empresa']) && count($dadosRelatorio['por_empresa']) > 0): ?>
                                            <?php foreach ($dadosRelatorio['por_empresa'] as $empresa): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($empresa['empresa']); ?></td>
                                                    <td><?php echo $empresa['total_veiculos'] ?? 0; ?></td>
                                                    <td><?php echo formatarMoeda($empresa['faturamento_total'] ?? 0); ?></td>
                                                    <td><?php echo formatarMoeda($empresa['ticket_medio'] ?? 0); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="4" class="text-center">Nenhum dado disponível.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card report-card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Faturamento por Forma de Pagamento</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Forma de Pagamento</th>
                                            <th>Veículos</th>
                                            <th>Faturamento</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (isset($dadosRelatorio['por_pagamento']) && count($dadosRelatorio['por_pagamento']) > 0): ?>
                                            <?php foreach ($dadosRelatorio['por_pagamento'] as $pagamento): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($pagamento['forma_pagamento'] ?: 'Não informado'); ?></td>
                                                    <td><?php echo $pagamento['total_veiculos'] ?? 0; ?></td>
                                                    <td><?php echo formatarMoeda($pagamento['faturamento_total'] ?? 0); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="3" class="text-center">Nenhum dado disponível.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card report-card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Faturamento por Dia</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Data</th>
                                            <th>Veículos</th>
                                            <th>Faturamento</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (isset($dadosRelatorio['por_dia']) && count($dadosRelatorio['por_dia']) > 0): ?>
                                            <?php foreach ($dadosRelatorio['por_dia'] as $dia): ?>
                                                <tr>
                                                    <td><?php echo formatarData($dia['data']); ?></td>
                                                    <td><?php echo $dia['total_veiculos'] ?? 0; ?></td>
                                                    <td><?php echo formatarMoeda($dia['faturamento_total'] ?? 0); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="3" class="text-center">Nenhum dado disponível.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif ($tipoRelatorio === 'veiculos'): ?>
                    <!-- Relatório de Veículos -->
                    <div class="report-stats">
                        <div class="stat-box bg-info-light">
                            <h3><?php echo $dadosRelatorio['total']['total_veiculos'] ?? 0; ?></h3>
                            <p>Total de Veículos</p>
                        </div>
                        
                        <div class="stat-box bg-success-light">
                            <h3><?php echo $dadosRelatorio['total']['veiculos_saida'] ?? 0; ?></h3>
                            <p>Veículos com Saída</p>
                        </div>
                        
                        <div class="stat-box bg-warning-light">
                            <h3><?php echo $dadosRelatorio['total']['veiculos_estacionados'] ?? 0; ?></h3>
                            <p>Veículos Estacionados</p>
                        </div>
                        
                        <div class="stat-box bg-danger-light">
                            <h3><?php echo formatarTempo($dadosRelatorio['total']['tempo_medio_minutos'] ?? 0); ?></h3>
                            <p>Tempo Médio</p>
                        </div>
                    </div>
                    
                    <div class="card report-card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Veículos por Empresa</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Empresa</th>
                                            <th>Total</th>
                                            <th>Com Saída</th>
                                            <th>Estacionados</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (isset($dadosRelatorio['por_empresa']) && count($dadosRelatorio['por_empresa']) > 0): ?>
                                            <?php foreach ($dadosRelatorio['por_empresa'] as $empresa): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($empresa['empresa']); ?></td>
                                                    <td><?php echo $empresa['total_veiculos'] ?? 0; ?></td>
                                                    <td><?php echo $empresa['veiculos_saida'] ?? 0; ?></td>
                                                    <td><?php echo $empresa['veiculos_estacionados'] ?? 0; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="4" class="text-center">Nenhum dado disponível.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card report-card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Tempo Médio de Permanência por Empresa</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Empresa</th>
                                            <th>Tempo Médio</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (isset($dadosRelatorio['tempo_medio']) && count($dadosRelatorio['tempo_medio']) > 0): ?>
                                            <?php foreach ($dadosRelatorio['tempo_medio'] as $tempo): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($tempo['empresa']); ?></td>
                                                    <td><?php echo formatarTempo($tempo['tempo_medio_minutos'] ?? 0); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="2" class="text-center">Nenhum dado disponível.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card report-card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Veículos por Dia</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Data</th>
                                            <th>Total de Veículos</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (isset($dadosRelatorio['por_dia']) && count($dadosRelatorio['por_dia']) > 0): ?>
                                            <?php foreach ($dadosRelatorio['por_dia'] as $dia): ?>
                                                <tr>
                                                    <td><?php echo formatarData($dia['data']); ?></td>
                                                    <td><?php echo $dia['total_veiculos'] ?? 0; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="2" class="text-center">Nenhum dado disponível.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif ($tipoRelatorio === 'mensalistas'): ?>
                    <!-- Relatório de Mensalistas -->
                    <div class="report-stats">
                        <div class="stat-box bg-info-light">
                            <h3><?php echo $dadosRelatorio['total']['total_mensalistas'] ?? 0; ?></h3>
                            <p>Total de Mensalistas</p>
                        </div>
                        
                        <div class="stat-box bg-success-light">
                            <h3><?php echo $dadosRelatorio['total']['mensalistas_ativos'] ?? 0; ?></h3>
                            <p>Mensalistas Ativos</p>
                        </div>
                        
                        <div class="stat-box bg-danger-light">
                            <h3><?php echo $dadosRelatorio['total']['mensalistas_inativos'] ?? 0; ?></h3>
                            <p>Mensalistas Inativos</p>
                        </div>
                    </div>
                    
                    <div class="card report-card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Mensalistas por Empresa</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Empresa</th>
                                            <th>Total</th>
                                            <th>Ativos</th>
                                            <th>Inativos</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (isset($dadosRelatorio['por_empresa']) && count($dadosRelatorio['por_empresa']) > 0): ?>
                                            <?php foreach ($dadosRelatorio['por_empresa'] as $empresa): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($empresa['empresa']); ?></td>
                                                    <td><?php echo $empresa['total_mensalistas'] ?? 0; ?></td>
                                                    <td><?php echo $empresa['mensalistas_ativos'] ?? 0; ?></td>
                                                    <td><?php echo $empresa['mensalistas_inativos'] ?? 0; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="4" class="text-center">Nenhum dado disponível.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card report-card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Mensalistas por Plano</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Plano</th>
                                            <th>Total de Mensalistas</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (isset($dadosRelatorio['por_plano']) && count($dadosRelatorio['por_plano']) > 0): ?>
                                            <?php foreach ($dadosRelatorio['por_plano'] as $plano): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($plano['plano'] ?: 'Não informado'); ?></td>
                                                    <td><?php echo $plano['total_mensalistas'] ?? 0; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="2" class="text-center">Nenhum dado disponível.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                <?php elseif ($tipoRelatorio === 'usuarios'): ?>
                    <!-- Relatório de Usuários -->
                    <div class="report-stats">
                        <div class="stat-box bg-info-light">
                            <h3><?php echo $dadosRelatorio['total']['total_usuarios'] ?? 0; ?></h3>
                            <p>Total de Usuários</p>
                        </div>
                        
                        <div class="stat-box bg-success-light">
                            <h3><?php echo $dadosRelatorio['total']['total_admins'] ?? 0; ?></h3>
                            <p>Administradores</p>
                        </div>
                        
                        <div class="stat-box bg-warning-light">
                            <h3><?php echo $dadosRelatorio['total']['total_operadores'] ?? 0; ?></h3>
                            <p>Operadores</p>
                        </div>
                        
                        <div class="stat-box bg-danger-light">
                            <h3><?php echo $dadosRelatorio['total']['usuarios_ativos'] ?? 0; ?></h3>
                            <p>Usuários Ativos</p>
                        </div>
                    </div>
                    
                    <div class="card report-card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Usuários por Empresa</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Empresa</th>
                                            <th>Total</th>
                                            <th>Admins</th>
                                            <th>Operadores</th>
                                            <th>Ativos</th>
                                            <th>Inativos</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (isset($dadosRelatorio['por_empresa']) && count($dadosRelatorio['por_empresa']) > 0): ?>
                                            <?php foreach ($dadosRelatorio['por_empresa'] as $empresa): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($empresa['empresa']); ?></td>
                                                    <td><?php echo $empresa['total_usuarios'] ?? 0; ?></td>
                                                    <td><?php echo $empresa['total_admins'] ?? 0; ?></td>
                                                    <td><?php echo $empresa['total_operadores'] ?? 0; ?></td>
                                                    <td><?php echo $empresa['usuarios_ativos'] ?? 0; ?></td>
                                                    <td><?php echo $empresa['usuarios_inativos'] ?? 0; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="6" class="text-center">Nenhum dado disponível.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card report-card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Usuários por Nível</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Nível</th>
                                            <th>Total de Usuários</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (isset($dadosRelatorio['por_nivel']) && count($dadosRelatorio['por_nivel']) > 0): ?>
                                            <?php foreach ($dadosRelatorio['por_nivel'] as $nivel): ?>
                                                <tr>
                                                    <td>
                                                        <?php if ($nivel['nivel'] === 'admin'): ?>
                                                            <span class="badge bg-danger">Administrador</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-primary">Operador</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo $nivel['total_usuarios'] ?? 0; ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="2" class="text-center">Nenhum dado disponível.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <div class="mt-4 text-center text-muted small no-print">
                    <p>Relatório gerado em <?php echo date('d/m/Y H:i:s'); ?> pelo Superadmin</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle sidebar
            document.getElementById('sidebarCollapse').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('active');
                document.getElementById('content').classList.toggle('active');
            });
            
            // Tipo de relatório condicional
            const tipoSelect = document.getElementById('tipo');
            const dataInicioInput = document.getElementById('data_inicio');
            const dataFimInput = document.getElementById('data_fim');
            
            tipoSelect.addEventListener('change', function() {
                const tipo = this.value;
                
                if (tipo === 'geral' || tipo === 'mensalistas' || tipo === 'usuarios') {
                    dataInicioInput.disabled = true;
                    dataFimInput.disabled = true;
                } else {
                    dataInicioInput.disabled = false;
                    dataFimInput.disabled = false;
                }
            });
            
            // Inicializar estado
            if (tipoSelect.value === 'geral' || tipoSelect.value === 'mensalistas' || tipoSelect.value === 'usuarios') {
                dataInicioInput.disabled = true;
                dataFimInput.disabled = true;
            }
        });
    </script>
</body>
</html>
