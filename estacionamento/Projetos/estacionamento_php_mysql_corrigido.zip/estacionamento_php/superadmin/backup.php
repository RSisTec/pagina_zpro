<?php
/**
 * Página de backup do sistema para o superadmin
 */
session_start();

// Incluir arquivo de configuração
require_once 'config.php';

// Verificar se está logado
requireSuperadminLogin();

// Incluir funções de banco de dados
require_once '../config/database.php';

// Inicializar variáveis
$mensagem = '';
$tipoMensagem = '';
$acao = $_GET['acao'] ?? '';
$backups = [];

// Diretório de backups
$backupDir = '../backups';

// Criar diretório de backups se não existir
if (!file_exists($backupDir)) {
    mkdir($backupDir, 0755, true);
}

// Processar ação de backup manual
if ($acao === 'backup_manual') {
    try {
        // Gerar nome do arquivo de backup
        $dataHora = date('Y-m-d_H-i-s');
        $nomeArquivo = "backup_$dataHora.sql";
        $caminhoArquivo = "$backupDir/$nomeArquivo";
        
        // Obter configurações de banco de dados
        require_once '../config/database.php';
        $dbConfig = getDatabaseConfig();
        
        // Comando mysqldump
        $comando = "mysqldump --host={$dbConfig['host']} --user={$dbConfig['username']} --password={$dbConfig['password']} {$dbConfig['database']} > $caminhoArquivo";
        
        // Executar comando
        exec($comando, $output, $returnVar);
        
        if ($returnVar === 0) {
            // Compactar arquivo
            $zipNome = "$backupDir/backup_$dataHora.zip";
            $zip = new ZipArchive();
            
            if ($zip->open($zipNome, ZipArchive::CREATE) === TRUE) {
                $zip->addFile($caminhoArquivo, $nomeArquivo);
                $zip->close();
                
                // Remover arquivo SQL original
                unlink($caminhoArquivo);
                
                $mensagem = 'Backup realizado com sucesso!';
                $tipoMensagem = 'success';
                
                // Registrar ação no log
                logSuperadminAction('Backup manual', "Backup manual realizado: $zipNome");
            } else {
                $mensagem = 'Erro ao compactar arquivo de backup.';
                $tipoMensagem = 'danger';
            }
        } else {
            $mensagem = 'Erro ao executar backup. Verifique as permissões do sistema.';
            $tipoMensagem = 'danger';
        }
    } catch (Exception $e) {
        $mensagem = 'Erro ao realizar backup: ' . $e->getMessage();
        $tipoMensagem = 'danger';
        logError('Erro ao realizar backup', $e);
    }
}

// Processar ação de restauração
if ($acao === 'restaurar' && isset($_GET['arquivo'])) {
    try {
        $arquivo = $_GET['arquivo'];
        $caminhoArquivo = "$backupDir/$arquivo";
        
        // Verificar se o arquivo existe e é um zip
        if (file_exists($caminhoArquivo) && pathinfo($caminhoArquivo, PATHINFO_EXTENSION) === 'zip') {
            // Extrair arquivo
            $zip = new ZipArchive();
            $tempDir = "$backupDir/temp_" . time();
            
            if (!file_exists($tempDir)) {
                mkdir($tempDir, 0755, true);
            }
            
            if ($zip->open($caminhoArquivo) === TRUE) {
                $zip->extractTo($tempDir);
                $zip->close();
                
                // Encontrar arquivo SQL
                $sqlFiles = glob("$tempDir/*.sql");
                
                if (count($sqlFiles) > 0) {
                    $sqlFile = $sqlFiles[0];
                    
                    // Obter configurações de banco de dados
                    require_once '../config/database.php';
                    $dbConfig = getDatabaseConfig();
                    
                    // Comando mysql para restaurar
                    $comando = "mysql --host={$dbConfig['host']} --user={$dbConfig['username']} --password={$dbConfig['password']} {$dbConfig['database']} < $sqlFile";
                    
                    // Executar comando
                    exec($comando, $output, $returnVar);
                    
                    // Limpar arquivos temporários
                    array_map('unlink', glob("$tempDir/*.*"));
                    rmdir($tempDir);
                    
                    if ($returnVar === 0) {
                        $mensagem = 'Backup restaurado com sucesso!';
                        $tipoMensagem = 'success';
                        
                        // Registrar ação no log
                        logSuperadminAction('Restauração de backup', "Backup restaurado: $arquivo");
                    } else {
                        $mensagem = 'Erro ao restaurar backup. Verifique as permissões do sistema.';
                        $tipoMensagem = 'danger';
                    }
                } else {
                    $mensagem = 'Nenhum arquivo SQL encontrado no backup.';
                    $tipoMensagem = 'danger';
                }
            } else {
                $mensagem = 'Erro ao extrair arquivo de backup.';
                $tipoMensagem = 'danger';
            }
        } else {
            $mensagem = 'Arquivo de backup inválido ou não encontrado.';
            $tipoMensagem = 'danger';
        }
    } catch (Exception $e) {
        $mensagem = 'Erro ao restaurar backup: ' . $e->getMessage();
        $tipoMensagem = 'danger';
        logError('Erro ao restaurar backup', $e);
    }
}

// Processar ação de exclusão
if ($acao === 'excluir' && isset($_GET['arquivo'])) {
    try {
        $arquivo = $_GET['arquivo'];
        $caminhoArquivo = "$backupDir/$arquivo";
        
        // Verificar se o arquivo existe
        if (file_exists($caminhoArquivo)) {
            // Excluir arquivo
            if (unlink($caminhoArquivo)) {
                $mensagem = 'Backup excluído com sucesso!';
                $tipoMensagem = 'success';
                
                // Registrar ação no log
                logSuperadminAction('Exclusão de backup', "Backup excluído: $arquivo");
            } else {
                $mensagem = 'Erro ao excluir backup. Verifique as permissões do sistema.';
                $tipoMensagem = 'danger';
            }
        } else {
            $mensagem = 'Arquivo de backup não encontrado.';
            $tipoMensagem = 'danger';
        }
    } catch (Exception $e) {
        $mensagem = 'Erro ao excluir backup: ' . $e->getMessage();
        $tipoMensagem = 'danger';
        logError('Erro ao excluir backup', $e);
    }
}

// Processar ação de download
if ($acao === 'download' && isset($_GET['arquivo'])) {
    try {
        $arquivo = $_GET['arquivo'];
        $caminhoArquivo = "$backupDir/$arquivo";
        
        // Verificar se o arquivo existe
        if (file_exists($caminhoArquivo)) {
            // Forçar download
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($caminhoArquivo) . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($caminhoArquivo));
            readfile($caminhoArquivo);
            exit;
        } else {
            $mensagem = 'Arquivo de backup não encontrado.';
            $tipoMensagem = 'danger';
        }
    } catch (Exception $e) {
        $mensagem = 'Erro ao baixar backup: ' . $e->getMessage();
        $tipoMensagem = 'danger';
        logError('Erro ao baixar backup', $e);
    }
}

// Obter lista de backups
$backupFiles = glob("$backupDir/*.zip");

foreach ($backupFiles as $file) {
    $fileName = basename($file);
    $fileSize = filesize($file);
    $fileDate = filemtime($file);
    
    // Extrair data do nome do arquivo
    preg_match('/backup_(\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2})\.zip/', $fileName, $matches);
    $dataFormatada = isset($matches[1]) ? str_replace('_', ' ', $matches[1]) : date('Y-m-d H:i:s', $fileDate);
    
    $backups[] = [
        'nome' => $fileName,
        'tamanho' => $fileSize,
        'data' => $fileDate,
        'data_formatada' => $dataFormatada
    ];
}

// Ordenar backups por data (mais recente primeiro)
usort($backups, function($a, $b) {
    return $b['data'] - $a['data'];
});

// Função para formatar tamanho de arquivo
function formatarTamanho($bytes) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    
    $bytes /= pow(1024, $pow);
    
    return round($bytes, 2) . ' ' . $units[$pow];
}

// Função para formatar data
function formatarData($timestamp) {
    return date('d/m/Y H:i:s', $timestamp);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backup do Sistema - Superadmin</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        
        .superadmin-navbar {
            background-color: #212529;
            padding: 15px 10px;
        }
        
        .superadmin-sidebar {
            min-width: 250px;
            max-width: 250px;
            background: #343a40;
            color: #fff;
            transition: all 0.3s;
            height: 100vh;
            position: fixed;
            z-index: 999;
        }
        
        .superadmin-sidebar .sidebar-header {
            padding: 20px;
            background: #212529;
        }
        
        .superadmin-sidebar ul.components {
            padding: 20px 0;
            border-bottom: 1px solid #4b545c;
        }
        
        .superadmin-sidebar ul p {
            color: #fff;
            padding: 10px;
        }
        
        .superadmin-sidebar ul li a {
            padding: 10px;
            font-size: 1.1em;
            display: block;
            color: #fff;
            text-decoration: none;
        }
        
        .superadmin-sidebar ul li a:hover {
            color: #fff;
            background: #495057;
        }
        
        .superadmin-sidebar ul li.active > a {
            color: #fff;
            background: #dc3545;
        }
        
        .superadmin-content {
            width: 100%;
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s;
            margin-left: 250px;
        }
        
        .superadmin-content.active {
            margin-left: 0;
        }
        
        .superadmin-badge {
            background-color: #dc3545;
            color: #fff;
            padding: 2px 5px;
            border-radius: 4px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-left: 5px;
        }
        
        .backup-card {
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .backup-card .card-header {
            border-bottom: 1px solid rgba(0, 0, 0, 0.125);
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .backup-card .card-body {
            padding: 20px;
        }
        
        .backup-table {
            font-size: 0.9rem;
        }
        
        .backup-table th {
            background-color: #f8f9fa;
        }
        
        .backup-info {
            background-color: #e9ecef;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .backup-info h5 {
            margin-bottom: 10px;
            color: #495057;
        }
        
        .backup-info p {
            margin-bottom: 5px;
            color: #6c757d;
        }
        
        .backup-info strong {
            color: #212529;
        }
        
        @media (max-width: 768px) {
            .superadmin-sidebar {
                margin-left: -250px;
            }
            .superadmin-sidebar.active {
                margin-left: 0;
            }
            .superadmin-content {
                margin-left: 0;
            }
            .superadmin-content.active {
                margin-left: 250px;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" class="superadmin-sidebar">
            <div class="sidebar-header">
                <h3>SUPERADMIN <span class="superadmin-badge">v1.0</span></h3>
            </div>
            
            <ul class="list-unstyled components">
                <li>
                    <a href="index.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
                </li>
                <li>
                    <a href="empresas.php"><i class="fas fa-building me-2"></i> Empresas</a>
                </li>
                <li>
                    <a href="usuarios.php"><i class="fas fa-users me-2"></i> Usuários</a>
                </li>
                <li>
                    <a href="relatorios.php"><i class="fas fa-chart-bar me-2"></i> Relatórios</a>
                </li>
                <li>
                    <a href="configuracoes.php"><i class="fas fa-cogs me-2"></i> Configurações</a>
                </li>
                <li>
                    <a href="logs.php"><i class="fas fa-history me-2"></i> Logs do Sistema</a>
                </li>
                <li class="active">
                    <a href="backup.php"><i class="fas fa-database me-2"></i> Backup</a>
                </li>
                <li>
                    <a href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a>
                </li>
            </ul>
        </nav>
        
        <!-- Page Content -->
        <div id="content" class="superadmin-content">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-dark superadmin-navbar">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <div class="ms-auto d-flex align-items-center">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle text-light" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-shield me-1"></i> Superadmin
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="perfil.php"><i class="fas fa-user-cog me-2"></i> Perfil</a></li>
                                <li><a class="dropdown-item" href="alterar_senha.php"><i class="fas fa-key me-2"></i> Alterar Senha</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            
            <h1 class="mb-4">Backup do Sistema</h1>
            
            <?php if (!empty($mensagem)): ?>
                <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
                    <?php echo $mensagem; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                </div>
            <?php endif; ?>
            
            <!-- Informações de Backup -->
            <div class="backup-info">
                <div class="row">
                    <div class="col-md-6">
                        <h5><i class="fas fa-info-circle me-2"></i> Informações de Backup</h5>
                        <p><strong>Total de backups:</strong> <?php echo count($backups); ?></p>
                        <p><strong>Último backup:</strong> <?php echo count($backups) > 0 ? formatarData($backups[0]['data']) : 'Nenhum backup realizado'; ?></p>
                        <p><strong>Diretório de backups:</strong> <?php echo $backupDir; ?></p>
                    </div>
                    <div class="col-md-6 d-flex align-items-center justify-content-end">
                        <a href="backup.php?acao=backup_manual" class="btn btn-primary">
                            <i class="fas fa-database me-2"></i> Realizar Backup Manual
                        </a>
                    </div>
                </div>
            </div>
            
            <!-- Lista de Backups -->
            <div class="card backup-card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Backups Disponíveis</h5>
                </div>
                <div class="card-body">
                    <?php if (count($backups) > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover backup-table">
                                <thead>
                                    <tr>
                                        <th>Data/Hora</th>
                                        <th>Arquivo</th>
                                        <th>Tamanho</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($backups as $backup): ?>
                                        <tr>
                                            <td><?php echo formatarData($backup['data']); ?></td>
                                            <td><?php echo htmlspecialchars($backup['nome']); ?></td>
                                            <td><?php echo formatarTamanho($backup['tamanho']); ?></td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <a href="backup.php?acao=download&arquivo=<?php echo urlencode($backup['nome']); ?>" class="btn btn-sm btn-primary" title="Download">
                                                        <i class="fas fa-download"></i>
                                                    </a>
                                                    <a href="backup.php?acao=restaurar&arquivo=<?php echo urlencode($backup['nome']); ?>" class="btn btn-sm btn-warning" title="Restaurar" onclick="return confirm('Tem certeza que deseja restaurar este backup? Todos os dados atuais serão substituídos.')">
                                                        <i class="fas fa-undo-alt"></i>
                                                    </a>
                                                    <a href="backup.php?acao=excluir&arquivo=<?php echo urlencode($backup['nome']); ?>" class="btn btn-sm btn-danger" title="Excluir" onclick="return confirm('Tem certeza que deseja excluir este backup? Esta ação não pode ser desfeita.')">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i> Nenhum backup encontrado. Realize um backup manual para proteger seus dados.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Instruções de Backup -->
            <div class="card backup-card">
                <div class="card-header">
                    <h5 class="card-title mb-0">Instruções de Backup</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <h5><i class="fas fa-lightbulb me-2"></i> Recomendações de Backup</h5>
                        <ul>
                            <li>Realize backups regulares do sistema para evitar perda de dados.</li>
                            <li>Mantenha cópias dos backups em locais diferentes para maior segurança.</li>
                            <li>Teste periodicamente a restauração de backups para garantir sua integridade.</li>
                            <li>Antes de restaurar um backup, certifique-se de que não há usuários utilizando o sistema.</li>
                            <li>Configure backups automáticos nas configurações do sistema para maior segurança.</li>
                        </ul>
                    </div>
                    
                    <div class="alert alert-warning">
                        <h5><i class="fas fa-exclamation-triangle me-2"></i> Atenção</h5>
                        <p>A restauração de um backup substituirá <strong>todos os dados atuais</strong> pelos dados contidos no backup. Esta ação não pode ser desfeita.</p>
                        <p>Certifique-se de que o backup que você está restaurando é válido e contém todos os dados necessários.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle sidebar
            document.getElementById('sidebarCollapse').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('active');
                document.getElementById('content').classList.toggle('active');
            });
        });
    </script>
</body>
</html>
