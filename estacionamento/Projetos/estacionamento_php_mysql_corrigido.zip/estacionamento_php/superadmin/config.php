<?php
/**
 * Arquivo de configuração do superadmin
 */

// Definir constantes
define('SUPERADMIN_USERNAME', 'superadmin');
define('SUPERADMIN_PASSWORD_HASH', password_hash('superadmin123', PASSWORD_DEFAULT)); // Senha: superadmin123

/**
 * Verifica se o superadmin está logado
 * Redireciona para a página de login se não estiver
 */
function requireSuperadminLogin() {
    if (!isset($_SESSION['superadmin_logged_in']) || $_SESSION['superadmin_logged_in'] !== true) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Gera um token CSRF para o superadmin
 */
function generateSuperadminCsrfToken() {
    if (!isset($_SESSION['superadmin_csrf_token'])) {
        $_SESSION['superadmin_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['superadmin_csrf_token'];
}

/**
 * Verifica se o token CSRF do superadmin é válido
 */
function verifySuperadminCsrfToken($token) {
    return isset($_SESSION['superadmin_csrf_token']) && hash_equals($_SESSION['superadmin_csrf_token'], $token);
}

/**
 * Registra uma ação do superadmin no log
 */
function logSuperadminAction($acao, $detalhes = '') {
    try {
        require_once '../config/database.php';
        $conn = getConnection();
        
        $query = "INSERT INTO logs (tipo, acao, detalhes, ip, data) VALUES (:tipo, :acao, :detalhes, :ip, NOW())";
        $stmt = $conn->prepare($query);
        
        $tipo = 'superadmin';
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        
        $stmt->bindParam(':tipo', $tipo);
        $stmt->bindParam(':acao', $acao);
        $stmt->bindParam(':detalhes', $detalhes);
        $stmt->bindParam(':ip', $ip);
        
        $stmt->execute();
    } catch (PDOException $e) {
        // Silenciar erros de log para evitar interrupções
    }
}

/**
 * Registra um erro no log
 */
function logError($acao, $e) {
    try {
        require_once '../config/database.php';
        $conn = getConnection();
        
        $query = "INSERT INTO logs (tipo, acao, detalhes, ip, data) VALUES (:tipo, :acao, :detalhes, :ip, NOW())";
        $stmt = $conn->prepare($query);
        
        $tipo = 'erro';
        $detalhes = $e->getMessage() . ' em ' . $e->getFile() . ' na linha ' . $e->getLine();
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        
        $stmt->bindParam(':tipo', $tipo);
        $stmt->bindParam(':acao', $acao);
        $stmt->bindParam(':detalhes', $detalhes);
        $stmt->bindParam(':ip', $ip);
        
        $stmt->execute();
    } catch (PDOException $e) {
        // Silenciar erros de log para evitar interrupções
    }
}
