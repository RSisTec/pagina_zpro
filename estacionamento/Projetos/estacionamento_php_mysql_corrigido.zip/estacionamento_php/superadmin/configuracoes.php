<?php
/**
 * Página de configurações globais do superadmin
 */
session_start();

// Incluir arquivo de configuração
require_once 'config.php';

// Verificar se está logado
requireSuperadminLogin();

// Incluir funções de banco de dados
require_once '../config/database.php';

// Inicializar variáveis
$mensagem = '';
$tipoMensagem = '';

// Obter configurações atuais
try {
    $conn = getConnection();
    
    $query = "SELECT * FROM configuracoes_sistema";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    
    $configuracoes = [];
    
    while ($row = $stmt->fetch()) {
        $configuracoes[$row['chave']] = $row['valor'];
    }
} catch (PDOException $e) {
    $configuracoes = [];
    logError('Erro ao obter configurações do sistema', $e);
}

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifySuperadminCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $nomeEmpresa = $_POST['nome_empresa'] ?? '';
            $emailSistema = $_POST['email_sistema'] ?? '';
            $tempoSessao = $_POST['tempo_sessao'] ?? 60;
            $tentativasLogin = $_POST['tentativas_login'] ?? 5;
            $tempoBloqueioConta = $_POST['tempo_bloqueio_conta'] ?? 30;
            $permitirMultiSessao = isset($_POST['permitir_multi_sessao']) ? 1 : 0;
            $logAcessos = isset($_POST['log_acessos']) ? 1 : 0;
            $logOperacoes = isset($_POST['log_operacoes']) ? 1 : 0;
            $backupAutomatico = isset($_POST['backup_automatico']) ? 1 : 0;
            $intervaloBackup = $_POST['intervalo_backup'] ?? 7;
            
            // Atualizar configurações
            $configsParaAtualizar = [
                'nome_empresa' => $nomeEmpresa,
                'email_sistema' => $emailSistema,
                'tempo_sessao' => $tempoSessao,
                'tentativas_login' => $tentativasLogin,
                'tempo_bloqueio_conta' => $tempoBloqueioConta,
                'permitir_multi_sessao' => $permitirMultiSessao,
                'log_acessos' => $logAcessos,
                'log_operacoes' => $logOperacoes,
                'backup_automatico' => $backupAutomatico,
                'intervalo_backup' => $intervaloBackup
            ];
            
            foreach ($configsParaAtualizar as $chave => $valor) {
                // Verificar se a configuração já existe
                $queryVerificar = "SELECT COUNT(*) as total FROM configuracoes_sistema WHERE chave = :chave";
                $stmtVerificar = $conn->prepare($queryVerificar);
                $stmtVerificar->bindParam(':chave', $chave);
                $stmtVerificar->execute();
                
                $existe = $stmtVerificar->fetch()['total'] > 0;
                
                if ($existe) {
                    // Atualizar configuração existente
                    $query = "UPDATE configuracoes_sistema SET valor = :valor WHERE chave = :chave";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':valor', $valor);
                    $stmt->bindParam(':chave', $chave);
                    $stmt->execute();
                } else {
                    // Inserir nova configuração
                    $query = "INSERT INTO configuracoes_sistema (chave, valor) VALUES (:chave, :valor)";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':chave', $chave);
                    $stmt->bindParam(':valor', $valor);
                    $stmt->execute();
                }
                
                // Atualizar array de configurações
                $configuracoes[$chave] = $valor;
            }
            
            $mensagem = 'Configurações atualizadas com sucesso!';
            $tipoMensagem = 'success';
            
            // Registrar ação no log
            logSuperadminAction('Atualização de configurações', "Configurações globais do sistema atualizadas");
        } catch (PDOException $e) {
            $mensagem = 'Erro ao salvar configurações. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
            logError('Erro ao salvar configurações', $e);
        }
    }
}

// Valores padrão para configurações não existentes
$configuracoes = array_merge([
    'nome_empresa' => 'Sistema de Estacionamento',
    'email_sistema' => 'admin@sistema.com',
    'tempo_sessao' => 60,
    'tentativas_login' => 5,
    'tempo_bloqueio_conta' => 30,
    'permitir_multi_sessao' => 0,
    'log_acessos' => 1,
    'log_operacoes' => 1,
    'backup_automatico' => 0,
    'intervalo_backup' => 7
], $configuracoes);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações - Superadmin</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        
        .superadmin-navbar {
            background-color: #212529;
            padding: 15px 10px;
        }
        
        .superadmin-sidebar {
            min-width: 250px;
            max-width: 250px;
            background: #343a40;
            color: #fff;
            transition: all 0.3s;
            height: 100vh;
            position: fixed;
            z-index: 999;
        }
        
        .superadmin-sidebar .sidebar-header {
            padding: 20px;
            background: #212529;
        }
        
        .superadmin-sidebar ul.components {
            padding: 20px 0;
            border-bottom: 1px solid #4b545c;
        }
        
        .superadmin-sidebar ul p {
            color: #fff;
            padding: 10px;
        }
        
        .superadmin-sidebar ul li a {
            padding: 10px;
            font-size: 1.1em;
            display: block;
            color: #fff;
            text-decoration: none;
        }
        
        .superadmin-sidebar ul li a:hover {
            color: #fff;
            background: #495057;
        }
        
        .superadmin-sidebar ul li.active > a {
            color: #fff;
            background: #dc3545;
        }
        
        .superadmin-content {
            width: 100%;
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s;
            margin-left: 250px;
        }
        
        .superadmin-content.active {
            margin-left: 0;
        }
        
        .superadmin-badge {
            background-color: #dc3545;
            color: #fff;
            padding: 2px 5px;
            border-radius: 4px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-left: 5px;
        }
        
        .config-card {
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .config-card .card-header {
            border-bottom: 1px solid rgba(0, 0, 0, 0.125);
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .config-card .card-body {
            padding: 20px;
        }
        
        @media (max-width: 768px) {
            .superadmin-sidebar {
                margin-left: -250px;
            }
            .superadmin-sidebar.active {
                margin-left: 0;
            }
            .superadmin-content {
                margin-left: 0;
            }
            .superadmin-content.active {
                margin-left: 250px;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" class="superadmin-sidebar">
            <div class="sidebar-header">
                <h3>SUPERADMIN <span class="superadmin-badge">v1.0</span></h3>
            </div>
            
            <ul class="list-unstyled components">
                <li>
                    <a href="index.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
                </li>
                <li>
                    <a href="empresas.php"><i class="fas fa-building me-2"></i> Empresas</a>
                </li>
                <li>
                    <a href="usuarios.php"><i class="fas fa-users me-2"></i> Usuários</a>
                </li>
                <li>
                    <a href="relatorios.php"><i class="fas fa-chart-bar me-2"></i> Relatórios</a>
                </li>
                <li class="active">
                    <a href="configuracoes.php"><i class="fas fa-cogs me-2"></i> Configurações</a>
                </li>
                <li>
                    <a href="logs.php"><i class="fas fa-history me-2"></i> Logs do Sistema</a>
                </li>
                <li>
                    <a href="backup.php"><i class="fas fa-database me-2"></i> Backup</a>
                </li>
                <li>
                    <a href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a>
                </li>
            </ul>
        </nav>
        
        <!-- Page Content -->
        <div id="content" class="superadmin-content">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-dark superadmin-navbar">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <div class="ms-auto d-flex align-items-center">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle text-light" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-shield me-1"></i> Superadmin
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="perfil.php"><i class="fas fa-user-cog me-2"></i> Perfil</a></li>
                                <li><a class="dropdown-item" href="alterar_senha.php"><i class="fas fa-key me-2"></i> Alterar Senha</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            
            <h1 class="mb-4">Configurações do Sistema</h1>
            
            <?php if (!empty($mensagem)): ?>
                <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
                    <?php echo $mensagem; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="configuracoes.php">
                <input type="hidden" name="csrf_token" value="<?php echo generateSuperadminCsrfToken(); ?>">
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="card config-card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Configurações Gerais</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label for="nome_empresa" class="form-label">Nome da Empresa/Sistema</label>
                                    <input type="text" class="form-control" id="nome_empresa" name="nome_empresa" value="<?php echo htmlspecialchars($configuracoes['nome_empresa']); ?>">
                                    <div class="form-text">Nome que aparecerá nos relatórios e e-mails do sistema.</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email_sistema" class="form-label">E-mail do Sistema</label>
                                    <input type="email" class="form-control" id="email_sistema" name="email_sistema" value="<?php echo htmlspecialchars($configuracoes['email_sistema']); ?>">
                                    <div class="form-text">E-mail utilizado para envio de notificações.</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card config-card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Configurações de Segurança</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3">
                                    <label for="tempo_sessao" class="form-label">Tempo de Sessão (minutos)</label>
                                    <input type="number" class="form-control" id="tempo_sessao" name="tempo_sessao" value="<?php echo htmlspecialchars($configuracoes['tempo_sessao']); ?>" min="5" max="1440">
                                    <div class="form-text">Tempo de inatividade até o logout automático.</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="tentativas_login" class="form-label">Tentativas de Login</label>
                                    <input type="number" class="form-control" id="tentativas_login" name="tentativas_login" value="<?php echo htmlspecialchars($configuracoes['tentativas_login']); ?>" min="1" max="10">
                                    <div class="form-text">Número de tentativas de login antes do bloqueio temporário.</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="tempo_bloqueio_conta" class="form-label">Tempo de Bloqueio (minutos)</label>
                                    <input type="number" class="form-control" id="tempo_bloqueio_conta" name="tempo_bloqueio_conta" value="<?php echo htmlspecialchars($configuracoes['tempo_bloqueio_conta']); ?>" min="5" max="1440">
                                    <div class="form-text">Tempo de bloqueio após exceder tentativas de login.</div>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="permitir_multi_sessao" name="permitir_multi_sessao" <?php echo $configuracoes['permitir_multi_sessao'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="permitir_multi_sessao">Permitir múltiplas sessões simultâneas</label>
                                    <div class="form-text">Se desativado, o login em um dispositivo encerrará a sessão em outros dispositivos.</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card config-card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Configurações de Logs</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="log_acessos" name="log_acessos" <?php echo $configuracoes['log_acessos'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="log_acessos">Registrar logs de acesso</label>
                                    <div class="form-text">Registra login, logout e tentativas de acesso.</div>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="log_operacoes" name="log_operacoes" <?php echo $configuracoes['log_operacoes'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="log_operacoes">Registrar logs de operações</label>
                                    <div class="form-text">Registra operações como criação, edição e exclusão de registros.</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card config-card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Configurações de Backup</h5>
                            </div>
                            <div class="card-body">
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="backup_automatico" name="backup_automatico" <?php echo $configuracoes['backup_automatico'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="backup_automatico">Realizar backup automático</label>
                                    <div class="form-text">Realiza backup automático do banco de dados periodicamente.</div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="intervalo_backup" class="form-label">Intervalo de Backup (dias)</label>
                                    <input type="number" class="form-control" id="intervalo_backup" name="intervalo_backup" value="<?php echo htmlspecialchars($configuracoes['intervalo_backup']); ?>" min="1" max="30">
                                    <div class="form-text">Intervalo em dias entre backups automáticos.</div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card config-card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Ações</h5>
                            </div>
                            <div class="card-body">
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Salvar Configurações</button>
                                    <a href="backup.php?acao=backup_manual" class="btn btn-secondary">Realizar Backup Manual</a>
                                    <a href="logs.php?acao=limpar" class="btn btn-warning" onclick="return confirm('Tem certeza que deseja limpar os logs antigos? Esta ação não pode ser desfeita.')">Limpar Logs Antigos</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle sidebar
            document.getElementById('sidebarCollapse').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('active');
                document.getElementById('content').classList.toggle('active');
            });
        });
    </script>
</body>
</html>
