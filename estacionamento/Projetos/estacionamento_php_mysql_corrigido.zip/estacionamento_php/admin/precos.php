<?php
/**
 * Página de gestão de preços
 */
$tituloPagina = 'Preços - Sistema de Estacionamento';
require_once '../includes/header.php';
require_once '../config/database.php';

// Verificar permissão
requirePermission('admin');

// Processar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? '';
$mensagem = '';
$tipoMensagem = '';

// Obter empresa atual
$empresaId = getCurrentEmpresaId();

// Inicializar variáveis para o formulário
$preco = [
    'id' => '',
    'nome' => '',
    'descricao' => '',
    'valor_primeira_hora' => '',
    'valor_hora_adicional' => '',
    'valor_diaria' => '',
    'valor_mensalidade' => '',
    'ativo' => 0
];

// Processar exclusão
if ($acao === 'excluir' && !empty($id)) {
    try {
        $conn = getConnection();
        
        // Verificar se é a tabela ativa
        $queryVerificar = "SELECT ativo FROM precos 
                          WHERE id = :id 
                          AND empresa_id = :empresa_id";
        $stmtVerificar = $conn->prepare($queryVerificar);
        $stmtVerificar->bindParam(':id', $id);
        $stmtVerificar->bindParam(':empresa_id', $empresaId);
        $stmtVerificar->execute();
        
        $result = $stmtVerificar->fetch();
        
        if ($result && $result['ativo']) {
            $mensagem = 'Não é possível excluir a tabela de preços ativa.';
            $tipoMensagem = 'danger';
        } else {
            // Excluir tabela de preços
            $query = "DELETE FROM precos 
                      WHERE id = :id 
                      AND empresa_id = :empresa_id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':empresa_id', $empresaId);
            $stmt->execute();
            
            $mensagem = 'Tabela de preços excluída com sucesso!';
            $tipoMensagem = 'success';
        }
    } catch (PDOException $e) {
        logError('Erro ao excluir tabela de preços', $e);
        $mensagem = 'Erro ao excluir tabela de preços. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    }
}

// Processar ativação
if ($acao === 'ativar' && !empty($id)) {
    try {
        $conn = getConnection();
        
        // Desativar todas as tabelas de preços
        $queryDesativar = "UPDATE precos 
                          SET ativo = 0 
                          WHERE empresa_id = :empresa_id";
        $stmtDesativar = $conn->prepare($queryDesativar);
        $stmtDesativar->bindParam(':empresa_id', $empresaId);
        $stmtDesativar->execute();
        
        // Ativar a tabela selecionada
        $queryAtivar = "UPDATE precos 
                       SET ativo = 1 
                       WHERE id = :id 
                       AND empresa_id = :empresa_id";
        $stmtAtivar = $conn->prepare($queryAtivar);
        $stmtAtivar->bindParam(':id', $id);
        $stmtAtivar->bindParam(':empresa_id', $empresaId);
        $stmtAtivar->execute();
        
        $mensagem = 'Tabela de preços ativada com sucesso!';
        $tipoMensagem = 'success';
    } catch (PDOException $e) {
        logError('Erro ao ativar tabela de preços', $e);
        $mensagem = 'Erro ao ativar tabela de preços. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    }
}

// Carregar dados para edição
if ($acao === 'editar' && !empty($id)) {
    try {
        $conn = getConnection();
        
        $query = "SELECT * FROM precos 
                  WHERE id = :id 
                  AND empresa_id = :empresa_id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':empresa_id', $empresaId);
        $stmt->execute();
        
        $result = $stmt->fetch();
        
        if ($result) {
            $preco = $result;
        } else {
            $mensagem = 'Tabela de preços não encontrada.';
            $tipoMensagem = 'danger';
        }
    } catch (PDOException $e) {
        logError('Erro ao carregar tabela de preços para edição', $e);
        $mensagem = 'Erro ao carregar dados da tabela de preços. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    }
}

// Processar formulário
if (isPostRequest()) {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $precoId = $_POST['id'] ?? '';
            $nome = $_POST['nome'] ?? '';
            $descricao = $_POST['descricao'] ?? '';
            $valorPrimeiraHora = $_POST['valor_primeira_hora'] ?? '';
            $valorHoraAdicional = $_POST['valor_hora_adicional'] ?? '';
            $valorDiaria = $_POST['valor_diaria'] ?? '';
            $valorMensalidade = $_POST['valor_mensalidade'] ?? '';
            $ativo = isset($_POST['ativo']) ? 1 : 0;
            
            // Validar dados
            if (empty($nome) || $valorPrimeiraHora === '' || $valorHoraAdicional === '' || $valorDiaria === '') {
                $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
                $tipoMensagem = 'danger';
                
                // Manter dados do formulário
                $preco = [
                    'id' => $precoId,
                    'nome' => $nome,
                    'descricao' => $descricao,
                    'valor_primeira_hora' => $valorPrimeiraHora,
                    'valor_hora_adicional' => $valorHoraAdicional,
                    'valor_diaria' => $valorDiaria,
                    'valor_mensalidade' => $valorMensalidade,
                    'ativo' => $ativo
                ];
            } else {
                // Se esta tabela será ativa, desativar todas as outras
                if ($ativo) {
                    $queryDesativar = "UPDATE precos 
                                      SET ativo = 0 
                                      WHERE empresa_id = :empresa_id";
                    $stmtDesativar = $conn->prepare($queryDesativar);
                    $stmtDesativar->bindParam(':empresa_id', $empresaId);
                    $stmtDesativar->execute();
                }
                
                if (empty($precoId)) {
                    // Inserir nova tabela de preços
                    $query = "INSERT INTO precos (nome, descricao, valor_primeira_hora, valor_hora_adicional, valor_diaria, valor_mensalidade, ativo, empresa_id) 
                              VALUES (:nome, :descricao, :valor_primeira_hora, :valor_hora_adicional, :valor_diaria, :valor_mensalidade, :ativo, :empresa_id)";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':nome', $nome);
                    $stmt->bindParam(':descricao', $descricao);
                    $stmt->bindParam(':valor_primeira_hora', $valorPrimeiraHora);
                    $stmt->bindParam(':valor_hora_adicional', $valorHoraAdicional);
                    $stmt->bindParam(':valor_diaria', $valorDiaria);
                    $stmt->bindParam(':valor_mensalidade', $valorMensalidade);
                    $stmt->bindParam(':ativo', $ativo);
                    $stmt->bindParam(':empresa_id', $empresaId);
                    $stmt->execute();
                    
                    $mensagem = 'Tabela de preços cadastrada com sucesso!';
                    $tipoMensagem = 'success';
                } else {
                    // Atualizar tabela de preços existente
                    $query = "UPDATE precos 
                              SET nome = :nome, 
                                  descricao = :descricao, 
                                  valor_primeira_hora = :valor_primeira_hora, 
                                  valor_hora_adicional = :valor_hora_adicional, 
                                  valor_diaria = :valor_diaria, 
                                  valor_mensalidade = :valor_mensalidade, 
                                  ativo = :ativo 
                              WHERE id = :id 
                              AND empresa_id = :empresa_id";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':nome', $nome);
                    $stmt->bindParam(':descricao', $descricao);
                    $stmt->bindParam(':valor_primeira_hora', $valorPrimeiraHora);
                    $stmt->bindParam(':valor_hora_adicional', $valorHoraAdicional);
                    $stmt->bindParam(':valor_diaria', $valorDiaria);
                    $stmt->bindParam(':valor_mensalidade', $valorMensalidade);
                    $stmt->bindParam(':ativo', $ativo);
                    $stmt->bindParam(':id', $precoId);
                    $stmt->bindParam(':empresa_id', $empresaId);
                    $stmt->execute();
                    
                    $mensagem = 'Tabela de preços atualizada com sucesso!';
                    $tipoMensagem = 'success';
                }
                
                // Limpar formulário após sucesso
                $preco = [
                    'id' => '',
                    'nome' => '',
                    'descricao' => '',
                    'valor_primeira_hora' => '',
                    'valor_hora_adicional' => '',
                    'valor_diaria' => '',
                    'valor_mensalidade' => '',
                    'ativo' => 0
                ];
            }
        } catch (PDOException $e) {
            logError('Erro ao salvar tabela de preços', $e);
            $mensagem = 'Erro ao salvar tabela de preços. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
        }
    }
}

// Obter lista de tabelas de preços
try {
    $conn = getConnection();
    
    $query = "SELECT * FROM precos 
              WHERE empresa_id = :empresa_id 
              ORDER BY ativo DESC, nome";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':empresa_id', $empresaId);
    $stmt->execute();
    $precos = $stmt->fetchAll();
} catch (PDOException $e) {
    logError('Erro ao obter lista de tabelas de preços', $e);
    $precos = [];
}
?>

<h1 class="mb-4">Gestão de Preços</h1>

<?php if (!empty($mensagem)): ?>
    <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
        <?php echo $mensagem; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title"><?php echo empty($preco['id']) ? 'Nova Tabela de Preços' : 'Editar Tabela de Preços'; ?></h5>
            </div>
            <div class="card-body">
                <form method="POST" action="precos.php">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    <input type="hidden" name="id" value="<?php echo sanitizeOutput($preco['id']); ?>">
                    
                    <div class="form-group mb-3">
                        <label for="nome">Nome*</label>
                        <input type="text" id="nome" name="nome" class="form-control" value="<?php echo sanitizeOutput($preco['nome']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="descricao">Descrição</label>
                        <textarea id="descricao" name="descricao" class="form-control" rows="3"><?php echo sanitizeOutput($preco['descricao']); ?></textarea>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="valor_primeira_hora">Valor da Primeira Hora*</label>
                        <input type="number" id="valor_primeira_hora" name="valor_primeira_hora" class="form-control" step="0.01" min="0" value="<?php echo sanitizeOutput($preco['valor_primeira_hora']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="valor_hora_adicional">Valor da Hora Adicional*</label>
                        <input type="number" id="valor_hora_adicional" name="valor_hora_adicional" class="form-control" step="0.01" min="0" value="<?php echo sanitizeOutput($preco['valor_hora_adicional']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="valor_diaria">Valor da Diária*</label>
                        <input type="number" id="valor_diaria" name="valor_diaria" class="form-control" step="0.01" min="0" value="<?php echo sanitizeOutput($preco['valor_diaria']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="valor_mensalidade">Valor da Mensalidade</label>
                        <input type="number" id="valor_mensalidade" name="valor_mensalidade" class="form-control" step="0.01" min="0" value="<?php echo sanitizeOutput($preco['valor_mensalidade']); ?>">
                    </div>
                    
                    <div class="form-check mb-3">
                        <input type="checkbox" id="ativo" name="ativo" class="form-check-input" <?php echo $preco['ativo'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="ativo">Ativar esta tabela de preços</label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    <?php if (!empty($preco['id'])): ?>
                        <a href="precos.php" class="btn btn-secondary">Cancelar</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Lista de Tabelas de Preços</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Primeira Hora</th>
                                <th>Hora Adicional</th>
                                <th>Diária</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($precos) > 0): ?>
                                <?php foreach ($precos as $p): ?>
                                    <tr>
                                        <td><?php echo sanitizeOutput($p['nome']); ?></td>
                                        <td><?php echo formatarMoeda($p['valor_primeira_hora']); ?></td>
                                        <td><?php echo formatarMoeda($p['valor_hora_adicional']); ?></td>
                                        <td><?php echo formatarMoeda($p['valor_diaria']); ?></td>
                                        <td>
                                            <?php if ($p['ativo']): ?>
                                                <span class="badge bg-success">Ativa</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Inativa</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="precos.php?acao=editar&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if (!$p['ativo']): ?>
                                                <a href="precos.php?acao=ativar&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-success" onclick="return confirm('Tem certeza que deseja ativar esta tabela de preços?')">
                                                    <i class="fas fa-check"></i>
                                                </a>
                                                <a href="precos.php?acao=excluir&id=<?php echo $p['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir esta tabela de preços?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center">Nenhuma tabela de preços cadastrada.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
