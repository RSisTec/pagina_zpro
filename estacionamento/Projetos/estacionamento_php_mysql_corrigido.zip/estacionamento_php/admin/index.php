<?php
/**
 * Dashboard administrativo
 */
$tituloPagina = 'Dashboard - Sistema de Estacionamento';
require_once '../includes/header.php';
require_once '../config/database.php';

// Obter estatísticas
try {
    $conn = getConnection();
    $empresaId = getCurrentEmpresaId();
    
    // Total de veículos no estacionamento
    $queryVeiculos = "SELECT COUNT(*) as total FROM veiculos 
                      WHERE empresa_id = :empresa_id AND saida IS NULL";
    $stmtVeiculos = $conn->prepare($queryVeiculos);
    $stmtVeiculos->bindParam(':empresa_id', $empresaId);
    $stmtVeiculos->execute();
    $totalVeiculos = $stmtVeiculos->fetch()['total'];
    
    // Total de mensalistas
    $queryMensalistas = "SELECT COUNT(*) as total FROM mensalistas 
                         WHERE empresa_id = :empresa_id AND ativo = 1";
    $stmtMensalistas = $conn->prepare($queryMensalistas);
    $stmtMensalistas->bindParam(':empresa_id', $empresaId);
    $stmtMensalistas->execute();
    $totalMensalistas = $stmtMensalistas->fetch()['total'];
    
    // Total de isentos
    $queryIsentos = "SELECT COUNT(*) as total FROM isentos 
                     WHERE empresa_id = :empresa_id AND ativo = 1";
    $stmtIsentos = $conn->prepare($queryIsentos);
    $stmtIsentos->bindParam(':empresa_id', $empresaId);
    $stmtIsentos->execute();
    $totalIsentos = $stmtIsentos->fetch()['total'];
    
    // Faturamento do dia
    $dataHoje = date('Y-m-d');
    $queryFaturamento = "SELECT SUM(valor_total) as total FROM veiculos 
                         WHERE empresa_id = :empresa_id 
                         AND DATE(saida) = :data_hoje 
                         AND valor_total > 0";
    $stmtFaturamento = $conn->prepare($queryFaturamento);
    $stmtFaturamento->bindParam(':empresa_id', $empresaId);
    $stmtFaturamento->bindParam(':data_hoje', $dataHoje);
    $stmtFaturamento->execute();
    $faturamentoDia = $stmtFaturamento->fetch()['total'] ?? 0;
    
    // Últimas entradas/saídas
    $queryUltimosVeiculos = "SELECT id, placa, modelo, cor, entrada, saida, valor_total 
                             FROM veiculos 
                             WHERE empresa_id = :empresa_id 
                             ORDER BY entrada DESC 
                             LIMIT 10";
    $stmtUltimosVeiculos = $conn->prepare($queryUltimosVeiculos);
    $stmtUltimosVeiculos->bindParam(':empresa_id', $empresaId);
    $stmtUltimosVeiculos->execute();
    $ultimosVeiculos = $stmtUltimosVeiculos->fetchAll();
    
} catch (PDOException $e) {
    logError('Erro ao obter estatísticas do dashboard', $e);
    $totalVeiculos = 0;
    $totalMensalistas = 0;
    $totalIsentos = 0;
    $faturamentoDia = 0;
    $ultimosVeiculos = [];
}
?>

<h1 class="mb-4">Dashboard</h1>

<div class="row">
    <div class="col-md-3">
        <div class="card card-stats">
            <div class="card-body">
                <div class="row">
                    <div class="col-5">
                        <div class="icon-big text-center">
                            <i class="fas fa-car text-primary"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="numbers">
                            <p class="card-category">Veículos</p>
                            <h4 class="card-title"><?php echo $totalVeiculos; ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <hr>
                <div class="stats">
                    <i class="fas fa-info-circle"></i> Veículos no estacionamento
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card card-stats">
            <div class="card-body">
                <div class="row">
                    <div class="col-5">
                        <div class="icon-big text-center">
                            <i class="fas fa-users text-success"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="numbers">
                            <p class="card-category">Mensalistas</p>
                            <h4 class="card-title"><?php echo $totalMensalistas; ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <hr>
                <div class="stats">
                    <i class="fas fa-info-circle"></i> Mensalistas ativos
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card card-stats">
            <div class="card-body">
                <div class="row">
                    <div class="col-5">
                        <div class="icon-big text-center">
                            <i class="fas fa-id-card text-warning"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="numbers">
                            <p class="card-category">Isentos</p>
                            <h4 class="card-title"><?php echo $totalIsentos; ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <hr>
                <div class="stats">
                    <i class="fas fa-info-circle"></i> Isentos ativos
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card card-stats">
            <div class="card-body">
                <div class="row">
                    <div class="col-5">
                        <div class="icon-big text-center">
                            <i class="fas fa-dollar-sign text-danger"></i>
                        </div>
                    </div>
                    <div class="col-7">
                        <div class="numbers">
                            <p class="card-category">Faturamento</p>
                            <h4 class="card-title"><?php echo formatarMoeda($faturamentoDia); ?></h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <hr>
                <div class="stats">
                    <i class="fas fa-calendar-alt"></i> Hoje
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row mt-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Últimos Veículos</h4>
                <p class="card-category">Entradas e saídas recentes</p>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Placa</th>
                                <th>Modelo</th>
                                <th>Cor</th>
                                <th>Entrada</th>
                                <th>Saída</th>
                                <th>Valor</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ultimosVeiculos as $veiculo): ?>
                                <tr>
                                    <td><?php echo sanitizeOutput($veiculo['placa']); ?></td>
                                    <td><?php echo sanitizeOutput($veiculo['modelo']); ?></td>
                                    <td><?php echo sanitizeOutput($veiculo['cor']); ?></td>
                                    <td><?php echo formatarData($veiculo['entrada'], true); ?></td>
                                    <td><?php echo $veiculo['saida'] ? formatarData($veiculo['saida'], true) : '-'; ?></td>
                                    <td><?php echo $veiculo['valor_total'] ? formatarMoeda($veiculo['valor_total']) : '-'; ?></td>
                                    <td>
                                        <?php if ($veiculo['saida']): ?>
                                            <span class="badge bg-success">Finalizado</span>
                                        <?php else: ?>
                                            <span class="badge bg-primary">No pátio</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            
                            <?php if (empty($ultimosVeiculos)): ?>
                                <tr>
                                    <td colspan="7" class="text-center">Nenhum veículo registrado recentemente.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <hr>
                <div class="stats">
                    <i class="fas fa-history"></i> Atualizado em <?php echo date('d/m/Y H:i:s'); ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
