<?php
/**
 * Página de gestão de isentos
 */
$tituloPagina = 'Isentos - Sistema de Estacionamento';
require_once '../includes/header.php';
require_once '../config/database.php';

// Verificar permissão
requirePermission('operador');

// Processar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? '';
$mensagem = '';
$tipoMensagem = '';

// Obter empresa atual
$empresaId = getCurrentEmpresaId();

// Inicializar variáveis para o formulário
$isento = [
    'id' => '',
    'nome' => '',
    'documento' => '',
    'motivo' => '',
    'observacoes' => '',
    'ativo' => 1
];

// Processar exclusão
if ($acao === 'excluir' && !empty($id)) {
    try {
        $conn = getConnection();
        
        // Verificar se existem veículos associados
        $queryVerificar = "SELECT COUNT(*) as total FROM veiculos 
                          WHERE isento_id = :id 
                          AND empresa_id = :empresa_id 
                          AND saida IS NULL";
        $stmtVerificar = $conn->prepare($queryVerificar);
        $stmtVerificar->bindParam(':id', $id);
        $stmtVerificar->bindParam(':empresa_id', $empresaId);
        $stmtVerificar->execute();
        
        if ($stmtVerificar->fetch()['total'] > 0) {
            $mensagem = 'Não é possível excluir este isento pois existem veículos associados.';
            $tipoMensagem = 'danger';
        } else {
            // Excluir isento
            $query = "DELETE FROM isentos 
                      WHERE id = :id 
                      AND empresa_id = :empresa_id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':empresa_id', $empresaId);
            $stmt->execute();
            
            $mensagem = 'Isento excluído com sucesso!';
            $tipoMensagem = 'success';
        }
    } catch (PDOException $e) {
        logError('Erro ao excluir isento', $e);
        $mensagem = 'Erro ao excluir isento. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    }
}

// Carregar dados para edição
if ($acao === 'editar' && !empty($id)) {
    try {
        $conn = getConnection();
        
        $query = "SELECT * FROM isentos 
                  WHERE id = :id 
                  AND empresa_id = :empresa_id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':empresa_id', $empresaId);
        $stmt->execute();
        
        $result = $stmt->fetch();
        
        if ($result) {
            $isento = $result;
        } else {
            $mensagem = 'Isento não encontrado.';
            $tipoMensagem = 'danger';
        }
    } catch (PDOException $e) {
        logError('Erro ao carregar isento para edição', $e);
        $mensagem = 'Erro ao carregar dados do isento. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    }
}

// Processar formulário
if (isPostRequest()) {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $isentoId = $_POST['id'] ?? '';
            $nome = $_POST['nome'] ?? '';
            $documento = $_POST['documento'] ?? '';
            $motivo = $_POST['motivo'] ?? '';
            $observacoes = $_POST['observacoes'] ?? '';
            $ativo = isset($_POST['ativo']) ? 1 : 0;
            
            // Validar dados
            if (empty($nome) || empty($documento) || empty($motivo)) {
                $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
                $tipoMensagem = 'danger';
                
                // Manter dados do formulário
                $isento = [
                    'id' => $isentoId,
                    'nome' => $nome,
                    'documento' => $documento,
                    'motivo' => $motivo,
                    'observacoes' => $observacoes,
                    'ativo' => $ativo
                ];
            } else {
                if (empty($isentoId)) {
                    // Inserir novo isento
                    $query = "INSERT INTO isentos (nome, documento, motivo, observacoes, ativo, empresa_id) 
                              VALUES (:nome, :documento, :motivo, :observacoes, :ativo, :empresa_id)";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':nome', $nome);
                    $stmt->bindParam(':documento', $documento);
                    $stmt->bindParam(':motivo', $motivo);
                    $stmt->bindParam(':observacoes', $observacoes);
                    $stmt->bindParam(':ativo', $ativo);
                    $stmt->bindParam(':empresa_id', $empresaId);
                    $stmt->execute();
                    
                    $mensagem = 'Isento cadastrado com sucesso!';
                    $tipoMensagem = 'success';
                } else {
                    // Atualizar isento existente
                    $query = "UPDATE isentos 
                              SET nome = :nome, 
                                  documento = :documento, 
                                  motivo = :motivo, 
                                  observacoes = :observacoes, 
                                  ativo = :ativo 
                              WHERE id = :id 
                              AND empresa_id = :empresa_id";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':nome', $nome);
                    $stmt->bindParam(':documento', $documento);
                    $stmt->bindParam(':motivo', $motivo);
                    $stmt->bindParam(':observacoes', $observacoes);
                    $stmt->bindParam(':ativo', $ativo);
                    $stmt->bindParam(':id', $isentoId);
                    $stmt->bindParam(':empresa_id', $empresaId);
                    $stmt->execute();
                    
                    $mensagem = 'Isento atualizado com sucesso!';
                    $tipoMensagem = 'success';
                }
                
                // Limpar formulário após sucesso
                $isento = [
                    'id' => '',
                    'nome' => '',
                    'documento' => '',
                    'motivo' => '',
                    'observacoes' => '',
                    'ativo' => 1
                ];
            }
        } catch (PDOException $e) {
            logError('Erro ao salvar isento', $e);
            $mensagem = 'Erro ao salvar isento. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
        }
    }
}

// Obter lista de isentos
try {
    $conn = getConnection();
    
    $query = "SELECT * FROM isentos 
              WHERE empresa_id = :empresa_id 
              ORDER BY nome";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':empresa_id', $empresaId);
    $stmt->execute();
    $isentos = $stmt->fetchAll();
} catch (PDOException $e) {
    logError('Erro ao obter lista de isentos', $e);
    $isentos = [];
}
?>

<h1 class="mb-4">Gestão de Isentos</h1>

<?php if (!empty($mensagem)): ?>
    <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
        <?php echo $mensagem; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title"><?php echo empty($isento['id']) ? 'Novo Isento' : 'Editar Isento'; ?></h5>
            </div>
            <div class="card-body">
                <form method="POST" action="isentos.php">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    <input type="hidden" name="id" value="<?php echo sanitizeOutput($isento['id']); ?>">
                    
                    <div class="form-group mb-3">
                        <label for="nome">Nome*</label>
                        <input type="text" id="nome" name="nome" class="form-control" value="<?php echo sanitizeOutput($isento['nome']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="documento">Documento*</label>
                        <input type="text" id="documento" name="documento" class="form-control" value="<?php echo sanitizeOutput($isento['documento']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="motivo">Motivo da Isenção*</label>
                        <input type="text" id="motivo" name="motivo" class="form-control" value="<?php echo sanitizeOutput($isento['motivo']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="observacoes">Observações</label>
                        <textarea id="observacoes" name="observacoes" class="form-control" rows="3"><?php echo sanitizeOutput($isento['observacoes']); ?></textarea>
                    </div>
                    
                    <div class="form-check mb-3">
                        <input type="checkbox" id="ativo" name="ativo" class="form-check-input" <?php echo $isento['ativo'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="ativo">Ativo</label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    <?php if (!empty($isento['id'])): ?>
                        <a href="isentos.php" class="btn btn-secondary">Cancelar</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Lista de Isentos</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Documento</th>
                                <th>Motivo</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($isentos) > 0): ?>
                                <?php foreach ($isentos as $i): ?>
                                    <tr>
                                        <td><?php echo sanitizeOutput($i['nome']); ?></td>
                                        <td><?php echo sanitizeOutput($i['documento']); ?></td>
                                        <td><?php echo sanitizeOutput($i['motivo']); ?></td>
                                        <td>
                                            <?php if ($i['ativo']): ?>
                                                <span class="badge bg-success">Ativo</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Inativo</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="isentos.php?acao=editar&id=<?php echo $i['id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="isentos.php?acao=excluir&id=<?php echo $i['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir este isento?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center">Nenhum isento cadastrado.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
