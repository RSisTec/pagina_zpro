<?php
/**
 * Funções de autenticação
 * 
 * Este arquivo contém funções para autenticação de usuários
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

/**
 * Autentica um usuário
 * 
 * @param string $login Login do usuário
 * @param string $senha Senha do usuário
 * @return array|false Dados do usuário ou falso se a autenticação falhar
 */
function autenticarUsuario($login, $senha) {
    try {
        $conn = getConnection();
        
        $query = "SELECT id, nome, email, login, senha, nivel, empresa_id, ativo 
                  FROM usuarios 
                  WHERE login = :login AND ativo = 1";
        
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':login', $login);
        $stmt->execute();
        
        $usuario = $stmt->fetch();
        
        if (!$usuario) {
            return false;
        }
        
        // Verificar se a senha está correta
        if (!password_verify($senha, $usuario['senha'])) {
            return false;
        }
        
        // Verificar se a empresa está ativa
        $queryEmpresa = "SELECT id, nome, ativo FROM empresas WHERE id = :empresa_id";
        $stmtEmpresa = $conn->prepare($queryEmpresa);
        $stmtEmpresa->bindParam(':empresa_id', $usuario['empresa_id']);
        $stmtEmpresa->execute();
        
        $empresa = $stmtEmpresa->fetch();
        
        if (!$empresa || !$empresa['ativo']) {
            return false;
        }
        
        // Remover a senha do array de retorno
        unset($usuario['senha']);
        
        // Adicionar informações da empresa
        $usuario['empresa_nome'] = $empresa['nome'];
        
        return $usuario;
    } catch (PDOException $e) {
        logError('Erro ao autenticar usuário', $e);
        return false;
    }
}

/**
 * Autentica um superadmin
 * 
 * @param string $login Login do superadmin
 * @param string $senha Senha do superadmin
 * @return array|false Dados do superadmin ou falso se a autenticação falhar
 */
function autenticarSuperAdmin($login, $senha) {
    try {
        $conn = getConnection();
        
        $query = "SELECT id, nome, email, login, senha, ativo 
                  FROM superadmins 
                  WHERE login = :login AND ativo = 1";
        
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':login', $login);
        $stmt->execute();
        
        $superadmin = $stmt->fetch();
        
        if (!$superadmin) {
            return false;
        }
        
        // Verificar se a senha está correta
        if (!password_verify($senha, $superadmin['senha'])) {
            return false;
        }
        
        // Remover a senha do array de retorno
        unset($superadmin['senha']);
        
        return $superadmin;
    } catch (PDOException $e) {
        logError('Erro ao autenticar superadmin', $e);
        return false;
    }
}

/**
 * Cria uma sessão para o usuário
 * 
 * @param array $usuario Dados do usuário
 */
function criarSessaoUsuario($usuario) {
    $_SESSION['user_id'] = $usuario['id'];
    $_SESSION['user_nome'] = $usuario['nome'];
    $_SESSION['user_email'] = $usuario['email'];
    $_SESSION['user_login'] = $usuario['login'];
    $_SESSION['user_nivel'] = $usuario['nivel'];
    $_SESSION['empresa_id'] = $usuario['empresa_id'];
    $_SESSION['empresa_nome'] = $usuario['empresa_nome'];
    $_SESSION['user_type'] = 'usuario';
    $_SESSION['last_activity'] = time();
}

/**
 * Cria uma sessão para o superadmin
 * 
 * @param array $superadmin Dados do superadmin
 */
function criarSessaoSuperAdmin($superadmin) {
    $_SESSION['user_id'] = $superadmin['id'];
    $_SESSION['user_nome'] = $superadmin['nome'];
    $_SESSION['user_email'] = $superadmin['email'];
    $_SESSION['user_login'] = $superadmin['login'];
    $_SESSION['user_type'] = 'superadmin';
    $_SESSION['last_activity'] = time();
}

/**
 * Encerra a sessão do usuário
 */
function encerrarSessao() {
    // Limpar todas as variáveis de sessão
    $_SESSION = [];
    
    // Destruir o cookie da sessão
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
    
    // Destruir a sessão
    session_destroy();
}

/**
 * Verifica se a sessão expirou
 * 
 * @param int $timeout Tempo limite em segundos (padrão: 30 minutos)
 * @return bool Verdadeiro se a sessão expirou
 */
function verificarSessaoExpirada($timeout = 1800) {
    if (!isset($_SESSION['last_activity'])) {
        return true;
    }
    
    if (time() - $_SESSION['last_activity'] > $timeout) {
        encerrarSessao();
        return true;
    }
    
    // Atualizar o timestamp da última atividade
    $_SESSION['last_activity'] = time();
    
    return false;
}

/**
 * Altera a senha de um usuário
 * 
 * @param int $userId ID do usuário
 * @param string $senhaAtual Senha atual
 * @param string $novaSenha Nova senha
 * @return bool Verdadeiro se a senha foi alterada com sucesso
 */
function alterarSenhaUsuario($userId, $senhaAtual, $novaSenha) {
    try {
        $conn = getConnection();
        
        // Verificar se a senha atual está correta
        $query = "SELECT senha FROM usuarios WHERE id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $userId);
        $stmt->execute();
        
        $usuario = $stmt->fetch();
        
        if (!$usuario || !password_verify($senhaAtual, $usuario['senha'])) {
            return false;
        }
        
        // Atualizar a senha
        $senhaCriptografada = password_hash($novaSenha, PASSWORD_DEFAULT);
        
        $query = "UPDATE usuarios SET senha = :senha WHERE id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':senha', $senhaCriptografada);
        $stmt->bindParam(':id', $userId);
        
        return $stmt->execute();
    } catch (PDOException $e) {
        logError('Erro ao alterar senha do usuário', $e);
        return false;
    }
}

/**
 * Altera a senha de um superadmin
 * 
 * @param int $superadminId ID do superadmin
 * @param string $senhaAtual Senha atual
 * @param string $novaSenha Nova senha
 * @return bool Verdadeiro se a senha foi alterada com sucesso
 */
function alterarSenhaSuperAdmin($superadminId, $senhaAtual, $novaSenha) {
    try {
        $conn = getConnection();
        
        // Verificar se a senha atual está correta
        $query = "SELECT senha FROM superadmins WHERE id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $superadminId);
        $stmt->execute();
        
        $superadmin = $stmt->fetch();
        
        if (!$superadmin || !password_verify($senhaAtual, $superadmin['senha'])) {
            return false;
        }
        
        // Atualizar a senha
        $senhaCriptografada = password_hash($novaSenha, PASSWORD_DEFAULT);
        
        $query = "UPDATE superadmins SET senha = :senha WHERE id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':senha', $senhaCriptografada);
        $stmt->bindParam(':id', $superadminId);
        
        return $stmt->execute();
    } catch (PDOException $e) {
        logError('Erro ao alterar senha do superadmin', $e);
        return false;
    }
}
