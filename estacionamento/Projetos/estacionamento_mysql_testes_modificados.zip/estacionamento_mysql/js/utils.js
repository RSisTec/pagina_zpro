// Arquivo de utilitários para o sistema de estacionamento

const Utils = {
    /**
     * Mostra uma notificação na tela
     * 
     * @param {string} mensagem Mensagem a ser exibida
     * @param {string} tipo Tipo de notificação (success, error, warning, info)
     * @param {number} duracao Duração em milissegundos
     */
    mostrarNotificacao: function(mensagem, tipo = 'info', duracao = 5000) {
        const notificacoes = document.getElementById('notificacoes');
        
        if (!notificacoes) {
            console.error('Elemento de notificações não encontrado');
            return;
        }
        
        const notificacao = document.createElement('div');
        notificacao.className = `notificacao ${tipo}`;
        notificacao.innerHTML = `
            <div class="notificacao-conteudo">
                <i class="fas ${this.getIconeNotificacao(tipo)}"></i>
                <span>${mensagem}</span>
            </div>
            <button class="btn-fechar"><i class="fas fa-times"></i></button>
        `;
        
        // Adicionar notificação ao container
        notificacoes.appendChild(notificacao);
        
        // Configurar botão de fechar
        const btnFechar = notificacao.querySelector('.btn-fechar');
        if (btnFechar) {
            btnFechar.addEventListener('click', function() {
                notificacao.remove();
            });
        }
        
        // Remover notificação após a duração especificada
        setTimeout(function() {
            if (notificacao.parentNode) {
                notificacao.remove();
            }
        }, duracao);
    },
    
    /**
     * Retorna o ícone para o tipo de notificação
     * 
     * @param {string} tipo Tipo de notificação
     * @returns {string} Classe do ícone
     */
    getIconeNotificacao: function(tipo) {
        switch (tipo) {
            case 'success':
                return 'fa-check-circle';
            case 'error':
                return 'fa-exclamation-circle';
            case 'warning':
                return 'fa-exclamation-triangle';
            case 'info':
            default:
                return 'fa-info-circle';
        }
    },
    
    /**
     * Mostra um elemento de carregamento na tela
     * 
     * @param {string} mensagem Mensagem a ser exibida
     */
    mostrarCarregamento: function(mensagem = 'Carregando...') {
        // Verificar se já existe um carregamento
        let carregamento = document.getElementById('carregamento');
        
        if (carregamento) {
            // Atualizar mensagem
            const mensagemElement = carregamento.querySelector('.carregamento-mensagem');
            if (mensagemElement) {
                mensagemElement.textContent = mensagem;
            }
            return;
        }
        
        // Criar elemento de carregamento
        carregamento = document.createElement('div');
        carregamento.id = 'carregamento';
        carregamento.className = 'carregamento';
        carregamento.innerHTML = `
            <div class="carregamento-conteudo">
                <div class="carregamento-spinner"></div>
                <div class="carregamento-mensagem">${mensagem}</div>
            </div>
        `;
        
        // Adicionar ao body
        document.body.appendChild(carregamento);
    },
    
    /**
     * Esconde o elemento de carregamento
     */
    esconderCarregamento: function() {
        const carregamento = document.getElementById('carregamento');
        
        if (carregamento) {
            carregamento.remove();
        }
    },
    
    /**
     * Formata um valor monetário
     * 
     * @param {number} valor Valor a ser formatado
     * @returns {string} Valor formatado
     */
    formatarMoeda: function(valor) {
        return valor.toLocaleString('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        });
    },
    
    /**
     * Formata uma data
     * 
     * @param {string|Date} data Data a ser formatada
     * @param {boolean} incluirHora Se deve incluir a hora
     * @returns {string} Data formatada
     */
    formatarData: function(data, incluirHora = false) {
        if (!data) return '';
        
        const dataObj = new Date(data);
        
        if (isNaN(dataObj.getTime())) {
            return '';
        }
        
        const options = {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        };
        
        if (incluirHora) {
            options.hour = '2-digit';
            options.minute = '2-digit';
            options.second = '2-digit';
        }
        
        return dataObj.toLocaleString('pt-BR', options);
    },
    
    /**
     * Gera um ID único
     * 
     * @returns {string} ID único
     */
    gerarId: function() {
        return 'id_' + Math.random().toString(36).substr(2, 9);
    }
};
