<?php
/**
 * Arquivo de configuração da conexão com o banco de dados MySQL
 * 
 * Este arquivo contém as configurações necessárias para conectar ao banco de dados MySQL
 */

return [
    'host' => 'localhost',
    'port' => '3306',
    'database' => 'estacionamento_db',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8mb4'
];
