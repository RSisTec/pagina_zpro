<?php
/**
 * Arquivo de adaptação para compatibilidade entre PostgreSQL e MySQL
 * 
 * Este arquivo contém funções e constantes para facilitar a migração
 * e manter compatibilidade entre os bancos de dados
 */

// Constantes para identificar o tipo de banco de dados
define('DB_TYPE_POSTGRES', 'postgres');
define('DB_TYPE_MYSQL', 'mysql');

// Tipo de banco de dados atual
define('CURRENT_DB_TYPE', DB_TYPE_MYSQL);

/**
 * Adapta uma consulta SQL para o banco de dados atual
 * 
 * @param string $sql Consulta SQL
 * @return string Consulta SQL adaptada
 */
function adaptSql($sql) {
    if (CURRENT_DB_TYPE === DB_TYPE_MYSQL) {
        // Substituir funções específicas do PostgreSQL por equivalentes MySQL
        $sql = str_replace('NOW()', 'NOW()', $sql); // Exemplo: mesma função em ambos
        $sql = str_replace('CURRENT_TIMESTAMP', 'CURRENT_TIMESTAMP', $sql); // Exemplo: mesma função em ambos
        
        // Substituir tipos de dados
        $sql = str_replace('::timestamp', '', $sql);
        $sql = str_replace('::date', '', $sql);
        $sql = str_replace('::integer', '', $sql);
        
        // Substituir funções de data
        $sql = str_replace('DATE_PART(', 'EXTRACT(', $sql);
        
        // Substituir funções de string
        $sql = str_replace('ILIKE', 'LIKE', $sql);
    }
    
    return $sql;
}

/**
 * Gera um UUID compatível com o banco de dados atual
 * 
 * @return string UUID
 */
function generateUuid() {
    if (CURRENT_DB_TYPE === DB_TYPE_MYSQL) {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    } else {
        // Para PostgreSQL, usar a função uuid_generate_v4()
        return 'uuid_generate_v4()';
    }
}

/**
 * Adapta uma consulta de paginação para o banco de dados atual
 * 
 * @param string $sql Consulta SQL base
 * @param int $page Número da página
 * @param int $limit Limite de registros por página
 * @return string Consulta SQL com paginação
 */
function paginateQuery($sql, $page, $limit) {
    $offset = ($page - 1) * $limit;
    
    if (CURRENT_DB_TYPE === DB_TYPE_MYSQL) {
        return $sql . " LIMIT $limit OFFSET $offset";
    } else {
        return $sql . " LIMIT $limit OFFSET $offset";
    }
}

/**
 * Adapta uma consulta de busca case-insensitive para o banco de dados atual
 * 
 * @param string $field Campo a ser pesquisado
 * @param string $value Valor a ser pesquisado
 * @return string Condição SQL
 */
function searchLikeQuery($field, $value) {
    if (CURRENT_DB_TYPE === DB_TYPE_MYSQL) {
        return "$field LIKE '%$value%'";
    } else {
        return "$field ILIKE '%$value%'";
    }
}
