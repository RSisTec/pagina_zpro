<?php
/**
 * Página de gestão de usuários
 */
$tituloPagina = 'Usuários - Sistema de Estacionamento';
require_once '../includes/header.php';
require_once '../config/database.php';

// Verificar permissão
requirePermission('admin');

// Processar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? '';
$mensagem = '';
$tipoMensagem = '';

// Obter empresa atual
$empresaId = getCurrentEmpresaId();

// Inicializar variáveis para o formulário
$usuario = [
    'id' => '',
    'nome' => '',
    'email' => '',
    'login' => '',
    'senha' => '',
    'nivel' => 'operador',
    'ativo' => 1
];

// Processar exclusão
if ($acao === 'excluir' && !empty($id)) {
    try {
        $conn = getConnection();
        
        // Verificar se é o próprio usuário
        if ($id == getCurrentUserId()) {
            $mensagem = 'Não é possível excluir seu próprio usuário.';
            $tipoMensagem = 'danger';
        } else {
            // Excluir usuário
            $query = "DELETE FROM usuarios 
                      WHERE id = :id 
                      AND empresa_id = :empresa_id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':empresa_id', $empresaId);
            $stmt->execute();
            
            $mensagem = 'Usuário excluído com sucesso!';
            $tipoMensagem = 'success';
        }
    } catch (PDOException $e) {
        logError('Erro ao excluir usuário', $e);
        $mensagem = 'Erro ao excluir usuário. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    }
}

// Carregar dados para edição
if ($acao === 'editar' && !empty($id)) {
    try {
        $conn = getConnection();
        
        $query = "SELECT id, nome, email, login, nivel, ativo FROM usuarios 
                  WHERE id = :id 
                  AND empresa_id = :empresa_id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':empresa_id', $empresaId);
        $stmt->execute();
        
        $result = $stmt->fetch();
        
        if ($result) {
            $usuario = $result;
            $usuario['senha'] = ''; // Não exibir senha
        } else {
            $mensagem = 'Usuário não encontrado.';
            $tipoMensagem = 'danger';
        }
    } catch (PDOException $e) {
        logError('Erro ao carregar usuário para edição', $e);
        $mensagem = 'Erro ao carregar dados do usuário. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    }
}

// Processar formulário
if (isPostRequest()) {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $usuarioId = $_POST['id'] ?? '';
            $nome = $_POST['nome'] ?? '';
            $email = $_POST['email'] ?? '';
            $login = $_POST['login'] ?? '';
            $senha = $_POST['senha'] ?? '';
            $nivel = $_POST['nivel'] ?? '';
            $ativo = isset($_POST['ativo']) ? 1 : 0;
            
            // Validar dados
            if (empty($nome) || empty($login) || empty($nivel)) {
                $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
                $tipoMensagem = 'danger';
                
                // Manter dados do formulário
                $usuario = [
                    'id' => $usuarioId,
                    'nome' => $nome,
                    'email' => $email,
                    'login' => $login,
                    'senha' => '',
                    'nivel' => $nivel,
                    'ativo' => $ativo
                ];
            } else {
                // Verificar se o login já existe
                $queryVerificar = "SELECT id FROM usuarios 
                                  WHERE login = :login 
                                  AND id != :id 
                                  AND empresa_id = :empresa_id";
                $stmtVerificar = $conn->prepare($queryVerificar);
                $stmtVerificar->bindParam(':login', $login);
                $stmtVerificar->bindParam(':id', $usuarioId);
                $stmtVerificar->bindParam(':empresa_id', $empresaId);
                $stmtVerificar->execute();
                
                if ($stmtVerificar->rowCount() > 0) {
                    $mensagem = 'Este login já está em uso. Por favor, escolha outro.';
                    $tipoMensagem = 'danger';
                    
                    // Manter dados do formulário
                    $usuario = [
                        'id' => $usuarioId,
                        'nome' => $nome,
                        'email' => $email,
                        'login' => $login,
                        'senha' => '',
                        'nivel' => $nivel,
                        'ativo' => $ativo
                    ];
                } else {
                    if (empty($usuarioId)) {
                        // Inserir novo usuário
                        if (empty($senha)) {
                            $mensagem = 'Por favor, informe uma senha para o novo usuário.';
                            $tipoMensagem = 'danger';
                            
                            // Manter dados do formulário
                            $usuario = [
                                'id' => $usuarioId,
                                'nome' => $nome,
                                'email' => $email,
                                'login' => $login,
                                'senha' => '',
                                'nivel' => $nivel,
                                'ativo' => $ativo
                            ];
                        } else {
                            // Criptografar senha
                            $senhaCriptografada = password_hash($senha, PASSWORD_DEFAULT);
                            
                            $query = "INSERT INTO usuarios (nome, email, login, senha, nivel, ativo, empresa_id) 
                                      VALUES (:nome, :email, :login, :senha, :nivel, :ativo, :empresa_id)";
                            $stmt = $conn->prepare($query);
                            $stmt->bindParam(':nome', $nome);
                            $stmt->bindParam(':email', $email);
                            $stmt->bindParam(':login', $login);
                            $stmt->bindParam(':senha', $senhaCriptografada);
                            $stmt->bindParam(':nivel', $nivel);
                            $stmt->bindParam(':ativo', $ativo);
                            $stmt->bindParam(':empresa_id', $empresaId);
                            $stmt->execute();
                            
                            $mensagem = 'Usuário cadastrado com sucesso!';
                            $tipoMensagem = 'success';
                            
                            // Limpar formulário após sucesso
                            $usuario = [
                                'id' => '',
                                'nome' => '',
                                'email' => '',
                                'login' => '',
                                'senha' => '',
                                'nivel' => 'operador',
                                'ativo' => 1
                            ];
                        }
                    } else {
                        // Atualizar usuário existente
                        if (!empty($senha)) {
                            // Criptografar nova senha
                            $senhaCriptografada = password_hash($senha, PASSWORD_DEFAULT);
                            
                            $query = "UPDATE usuarios 
                                      SET nome = :nome, 
                                          email = :email, 
                                          login = :login, 
                                          senha = :senha, 
                                          nivel = :nivel, 
                                          ativo = :ativo 
                                      WHERE id = :id 
                                      AND empresa_id = :empresa_id";
                            $stmt = $conn->prepare($query);
                            $stmt->bindParam(':senha', $senhaCriptografada);
                        } else {
                            // Manter senha atual
                            $query = "UPDATE usuarios 
                                      SET nome = :nome, 
                                          email = :email, 
                                          login = :login, 
                                          nivel = :nivel, 
                                          ativo = :ativo 
                                      WHERE id = :id 
                                      AND empresa_id = :empresa_id";
                            $stmt = $conn->prepare($query);
                        }
                        
                        $stmt->bindParam(':nome', $nome);
                        $stmt->bindParam(':email', $email);
                        $stmt->bindParam(':login', $login);
                        $stmt->bindParam(':nivel', $nivel);
                        $stmt->bindParam(':ativo', $ativo);
                        $stmt->bindParam(':id', $usuarioId);
                        $stmt->bindParam(':empresa_id', $empresaId);
                        $stmt->execute();
                        
                        $mensagem = 'Usuário atualizado com sucesso!';
                        $tipoMensagem = 'success';
                        
                        // Limpar formulário após sucesso
                        $usuario = [
                            'id' => '',
                            'nome' => '',
                            'email' => '',
                            'login' => '',
                            'senha' => '',
                            'nivel' => 'operador',
                            'ativo' => 1
                        ];
                    }
                }
            }
        } catch (PDOException $e) {
            logError('Erro ao salvar usuário', $e);
            $mensagem = 'Erro ao salvar usuário. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
        }
    }
}

// Obter lista de usuários
try {
    $conn = getConnection();
    
    $query = "SELECT id, nome, email, login, nivel, ativo FROM usuarios 
              WHERE empresa_id = :empresa_id 
              ORDER BY nome";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':empresa_id', $empresaId);
    $stmt->execute();
    $usuarios = $stmt->fetchAll();
} catch (PDOException $e) {
    logError('Erro ao obter lista de usuários', $e);
    $usuarios = [];
}
?>

<h1 class="mb-4">Gestão de Usuários</h1>

<?php if (!empty($mensagem)): ?>
    <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
        <?php echo $mensagem; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title"><?php echo empty($usuario['id']) ? 'Novo Usuário' : 'Editar Usuário'; ?></h5>
            </div>
            <div class="card-body">
                <form method="POST" action="usuarios.php">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    <input type="hidden" name="id" value="<?php echo sanitizeOutput($usuario['id']); ?>">
                    
                    <div class="form-group mb-3">
                        <label for="nome">Nome*</label>
                        <input type="text" id="nome" name="nome" class="form-control" value="<?php echo sanitizeOutput($usuario['nome']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="email">E-mail</label>
                        <input type="email" id="email" name="email" class="form-control" value="<?php echo sanitizeOutput($usuario['email']); ?>">
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="login">Login*</label>
                        <input type="text" id="login" name="login" class="form-control" value="<?php echo sanitizeOutput($usuario['login']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="senha"><?php echo empty($usuario['id']) ? 'Senha*' : 'Nova Senha (deixe em branco para manter a atual)'; ?></label>
                        <input type="password" id="senha" name="senha" class="form-control" <?php echo empty($usuario['id']) ? 'required' : ''; ?>>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="nivel">Nível de Acesso*</label>
                        <select id="nivel" name="nivel" class="form-control" required>
                            <option value="operador" <?php echo $usuario['nivel'] === 'operador' ? 'selected' : ''; ?>>Operador</option>
                            <option value="admin" <?php echo $usuario['nivel'] === 'admin' ? 'selected' : ''; ?>>Administrador</option>
                        </select>
                    </div>
                    
                    <div class="form-check mb-3">
                        <input type="checkbox" id="ativo" name="ativo" class="form-check-input" <?php echo $usuario['ativo'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="ativo">Ativo</label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    <?php if (!empty($usuario['id'])): ?>
                        <a href="usuarios.php" class="btn btn-secondary">Cancelar</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Lista de Usuários</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Login</th>
                                <th>E-mail</th>
                                <th>Nível</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($usuarios) > 0): ?>
                                <?php foreach ($usuarios as $u): ?>
                                    <tr>
                                        <td><?php echo sanitizeOutput($u['nome']); ?></td>
                                        <td><?php echo sanitizeOutput($u['login']); ?></td>
                                        <td><?php echo sanitizeOutput($u['email']); ?></td>
                                        <td>
                                            <?php if ($u['nivel'] === 'admin'): ?>
                                                <span class="badge bg-danger">Administrador</span>
                                            <?php else: ?>
                                                <span class="badge bg-primary">Operador</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($u['ativo']): ?>
                                                <span class="badge bg-success">Ativo</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Inativo</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="usuarios.php?acao=editar&id=<?php echo $u['id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <?php if ($u['id'] != getCurrentUserId()): ?>
                                                <a href="usuarios.php?acao=excluir&id=<?php echo $u['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir este usuário?')">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" class="text-center">Nenhum usuário cadastrado.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
