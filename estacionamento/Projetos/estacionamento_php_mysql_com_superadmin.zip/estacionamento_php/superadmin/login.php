<?php
/**
 * Página de login do superadmin
 */
session_start();

// Incluir arquivo de configuração
require_once 'config.php';

// Inicializar variáveis
$mensagem = '';
$tipoMensagem = '';

// Verificar se já está logado
if (isSuperadminLoggedIn()) {
    header('Location: index.php');
    exit;
}

// Processar login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifySuperadminCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        // Obter dados do formulário
        $username = $_POST['username'] ?? '';
        $password = $_POST['password'] ?? '';
        
        // Validar credenciais
        if ($username === SUPERADMIN_USER && password_verify($password, SUPERADMIN_PASSWORD_HASH)) {
            // Login bem-sucedido
            $_SESSION[SUPERADMIN_SESSION_KEY] = true;
            
            // Registrar ação no log
            logSuperadminAction('Login', 'Login bem-sucedido');
            
            // Redirecionar para o dashboard
            header('Location: index.php');
            exit;
        } else {
            // Login falhou
            $mensagem = 'Credenciais inválidas. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
            
            // Registrar tentativa de login falha
            logSuperadminAction('Login falhou', "Tentativa com usuário: $username");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Superadmin - Sistema de Estacionamento</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #212529;
            color: #fff;
        }
        
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .login-card {
            width: 400px;
            padding: 30px;
            background-color: #343a40;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-header h1 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #fff;
        }
        
        .login-form .form-group {
            margin-bottom: 20px;
        }
        
        .login-form .form-control {
            background-color: #495057;
            border: none;
            color: #fff;
        }
        
        .login-form .form-control:focus {
            background-color: #495057;
            color: #fff;
            box-shadow: 0 0 0 0.2rem rgba(255, 255, 255, 0.25);
        }
        
        .login-form .btn-primary {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        
        .login-form .btn-primary:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
        
        .login-footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #adb5bd;
        }
        
        .superadmin-badge {
            background-color: #dc3545;
            color: #fff;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 20px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-card">
            <div class="login-header">
                <span class="superadmin-badge">Área Restrita</span>
                <h1>SUPERADMIN</h1>
                <p>Sistema de Estacionamento</p>
            </div>
            
            <?php if (!empty($mensagem)): ?>
                <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
                    <?php echo $mensagem; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                </div>
            <?php endif; ?>
            
            <form class="login-form" method="POST" action="login.php">
                <input type="hidden" name="csrf_token" value="<?php echo generateSuperadminCsrfToken(); ?>">
                
                <div class="form-group">
                    <label for="username">Usuário</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                        <input type="text" id="username" name="username" class="form-control" placeholder="Digite seu usuário" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password">Senha</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                        <input type="password" id="password" name="password" class="form-control" placeholder="Digite sua senha" required>
                    </div>
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Entrar</button>
                </div>
            </form>
            
            <div class="login-footer">
                <p>Acesso exclusivo para administradores do sistema</p>
                <a href="../index.php" class="text-light">Voltar para o site</a>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
