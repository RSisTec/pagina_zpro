<?php
/**
 * Página de logs do sistema para o superadmin
 */
session_start();

// Incluir arquivo de configuração
require_once 'config.php';

// Verificar se está logado
requireSuperadminLogin();

// Incluir funções de banco de dados
require_once '../config/database.php';

// Inicializar variáveis
$mensagem = '';
$tipoMensagem = '';
$tipoLog = $_GET['tipo'] ?? 'acesso';
$dataInicio = $_GET['data_inicio'] ?? date('Y-m-d', strtotime('-7 days'));
$dataFim = $_GET['data_fim'] ?? date('Y-m-d');
$empresaId = $_GET['empresa_id'] ?? '';
$usuarioId = $_GET['usuario_id'] ?? '';
$acao = $_GET['acao'] ?? '';

// Processar ação de limpar logs
if ($acao === 'limpar') {
    try {
        $conn = getConnection();
        
        // Limpar logs mais antigos que 30 dias
        $dataLimite = date('Y-m-d', strtotime('-30 days'));
        
        $query = "DELETE FROM logs WHERE data < :data_limite";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':data_limite', $dataLimite);
        $stmt->execute();
        
        $mensagem = 'Logs antigos foram limpos com sucesso!';
        $tipoMensagem = 'success';
        
        // Registrar ação no log
        logSuperadminAction('Limpeza de logs', "Logs anteriores a $dataLimite foram removidos");
    } catch (PDOException $e) {
        $mensagem = 'Erro ao limpar logs. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
        logError('Erro ao limpar logs', $e);
    }
}

// Obter lista de empresas
try {
    $conn = getConnection();
    
    $query = "SELECT id, nome FROM empresas ORDER BY nome";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $empresas = $stmt->fetchAll();
} catch (PDOException $e) {
    $empresas = [];
    logError('Erro ao obter lista de empresas para logs', $e);
}

// Obter lista de usuários
try {
    $conn = getConnection();
    
    $whereClause = "";
    $params = [];
    
    if (!empty($empresaId)) {
        $whereClause = "WHERE empresa_id = :empresa_id";
        $params[':empresa_id'] = $empresaId;
    }
    
    $query = "SELECT id, nome, login FROM usuarios $whereClause ORDER BY nome";
    $stmt = $conn->prepare($query);
    
    foreach ($params as $param => $value) {
        $stmt->bindValue($param, $value);
    }
    
    $stmt->execute();
    $usuarios = $stmt->fetchAll();
} catch (PDOException $e) {
    $usuarios = [];
    logError('Erro ao obter lista de usuários para logs', $e);
}

// Obter logs
try {
    $conn = getConnection();
    
    $whereClause = "WHERE 1=1";
    $params = [];
    
    // Filtro por tipo de log
    if ($tipoLog === 'acesso') {
        $whereClause .= " AND tipo = 'acesso'";
    } elseif ($tipoLog === 'operacao') {
        $whereClause .= " AND tipo = 'operacao'";
    } elseif ($tipoLog === 'erro') {
        $whereClause .= " AND tipo = 'erro'";
    } elseif ($tipoLog === 'superadmin') {
        $whereClause .= " AND tipo = 'superadmin'";
    }
    
    // Filtro por data
    if (!empty($dataInicio)) {
        $whereClause .= " AND DATE(data) >= :data_inicio";
        $params[':data_inicio'] = $dataInicio;
    }
    
    if (!empty($dataFim)) {
        $whereClause .= " AND DATE(data) <= :data_fim";
        $params[':data_fim'] = $dataFim;
    }
    
    // Filtro por empresa
    if (!empty($empresaId)) {
        $whereClause .= " AND empresa_id = :empresa_id";
        $params[':empresa_id'] = $empresaId;
    }
    
    // Filtro por usuário
    if (!empty($usuarioId)) {
        $whereClause .= " AND usuario_id = :usuario_id";
        $params[':usuario_id'] = $usuarioId;
    }
    
    // Consulta principal
    $query = "SELECT l.*, 
                     e.nome as empresa_nome, 
                     u.nome as usuario_nome, 
                     u.login as usuario_login
              FROM logs l
              LEFT JOIN empresas e ON l.empresa_id = e.id
              LEFT JOIN usuarios u ON l.usuario_id = u.id
              $whereClause
              ORDER BY l.data DESC
              LIMIT 1000";
    
    $stmt = $conn->prepare($query);
    
    foreach ($params as $param => $value) {
        $stmt->bindValue($param, $value);
    }
    
    $stmt->execute();
    $logs = $stmt->fetchAll();
    
    // Total de logs
    $queryTotal = "SELECT COUNT(*) as total FROM logs $whereClause";
    $stmtTotal = $conn->prepare($queryTotal);
    
    foreach ($params as $param => $value) {
        $stmtTotal->bindValue($param, $value);
    }
    
    $stmtTotal->execute();
    $totalLogs = $stmtTotal->fetch()['total'];
    
    // Verificar se há mais logs do que o limite
    $temMaisLogs = $totalLogs > 1000;
} catch (PDOException $e) {
    $logs = [];
    $totalLogs = 0;
    $temMaisLogs = false;
    logError('Erro ao obter logs', $e);
}

// Função para formatar data
function formatarData($data, $incluirHora = true) {
    if (!$data) {
        return '-';
    }
    
    $date = new DateTime($data);
    
    if ($incluirHora) {
        return $date->format('d/m/Y H:i:s');
    }
    
    return $date->format('d/m/Y');
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs do Sistema - Superadmin</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        
        .superadmin-navbar {
            background-color: #212529;
            padding: 15px 10px;
        }
        
        .superadmin-sidebar {
            min-width: 250px;
            max-width: 250px;
            background: #343a40;
            color: #fff;
            transition: all 0.3s;
            height: 100vh;
            position: fixed;
            z-index: 999;
        }
        
        .superadmin-sidebar .sidebar-header {
            padding: 20px;
            background: #212529;
        }
        
        .superadmin-sidebar ul.components {
            padding: 20px 0;
            border-bottom: 1px solid #4b545c;
        }
        
        .superadmin-sidebar ul p {
            color: #fff;
            padding: 10px;
        }
        
        .superadmin-sidebar ul li a {
            padding: 10px;
            font-size: 1.1em;
            display: block;
            color: #fff;
            text-decoration: none;
        }
        
        .superadmin-sidebar ul li a:hover {
            color: #fff;
            background: #495057;
        }
        
        .superadmin-sidebar ul li.active > a {
            color: #fff;
            background: #dc3545;
        }
        
        .superadmin-content {
            width: 100%;
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s;
            margin-left: 250px;
        }
        
        .superadmin-content.active {
            margin-left: 0;
        }
        
        .superadmin-badge {
            background-color: #dc3545;
            color: #fff;
            padding: 2px 5px;
            border-radius: 4px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-left: 5px;
        }
        
        .log-card {
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .log-card .card-header {
            border-bottom: 1px solid rgba(0, 0, 0, 0.125);
            background-color: #f8f9fa;
            font-weight: bold;
        }
        
        .log-card .card-body {
            padding: 20px;
        }
        
        .log-table {
            font-size: 0.9rem;
        }
        
        .log-table th {
            background-color: #f8f9fa;
        }
        
        .log-badge-acesso {
            background-color: #0dcaf0;
        }
        
        .log-badge-operacao {
            background-color: #198754;
        }
        
        .log-badge-erro {
            background-color: #dc3545;
        }
        
        .log-badge-superadmin {
            background-color: #6f42c1;
        }
        
        @media (max-width: 768px) {
            .superadmin-sidebar {
                margin-left: -250px;
            }
            .superadmin-sidebar.active {
                margin-left: 0;
            }
            .superadmin-content {
                margin-left: 0;
            }
            .superadmin-content.active {
                margin-left: 250px;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" class="superadmin-sidebar">
            <div class="sidebar-header">
                <h3>SUPERADMIN <span class="superadmin-badge">v1.0</span></h3>
            </div>
            
            <ul class="list-unstyled components">
                <li>
                    <a href="index.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
                </li>
                <li>
                    <a href="empresas.php"><i class="fas fa-building me-2"></i> Empresas</a>
                </li>
                <li>
                    <a href="usuarios.php"><i class="fas fa-users me-2"></i> Usuários</a>
                </li>
                <li>
                    <a href="relatorios.php"><i class="fas fa-chart-bar me-2"></i> Relatórios</a>
                </li>
                <li>
                    <a href="configuracoes.php"><i class="fas fa-cogs me-2"></i> Configurações</a>
                </li>
                <li class="active">
                    <a href="logs.php"><i class="fas fa-history me-2"></i> Logs do Sistema</a>
                </li>
                <li>
                    <a href="backup.php"><i class="fas fa-database me-2"></i> Backup</a>
                </li>
                <li>
                    <a href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a>
                </li>
            </ul>
        </nav>
        
        <!-- Page Content -->
        <div id="content" class="superadmin-content">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-dark superadmin-navbar">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <div class="ms-auto d-flex align-items-center">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle text-light" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-shield me-1"></i> Superadmin
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="perfil.php"><i class="fas fa-user-cog me-2"></i> Perfil</a></li>
                                <li><a class="dropdown-item" href="alterar_senha.php"><i class="fas fa-key me-2"></i> Alterar Senha</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            
            <h1 class="mb-4">Logs do Sistema</h1>
            
            <?php if (!empty($mensagem)): ?>
                <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
                    <?php echo $mensagem; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                </div>
            <?php endif; ?>
            
            <!-- Filtros -->
            <div class="card log-card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">Filtros</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="logs.php" class="row g-3">
                        <div class="col-md-2">
                            <label for="tipo" class="form-label">Tipo de Log</label>
                            <select name="tipo" id="tipo" class="form-control">
                                <option value="todos" <?php echo $tipoLog === 'todos' ? 'selected' : ''; ?>>Todos</option>
                                <option value="acesso" <?php echo $tipoLog === 'acesso' ? 'selected' : ''; ?>>Acesso</option>
                                <option value="operacao" <?php echo $tipoLog === 'operacao' ? 'selected' : ''; ?>>Operação</option>
                                <option value="erro" <?php echo $tipoLog === 'erro' ? 'selected' : ''; ?>>Erro</option>
                                <option value="superadmin" <?php echo $tipoLog === 'superadmin' ? 'selected' : ''; ?>>Superadmin</option>
                            </select>
                        </div>
                        
                        <div class="col-md-2">
                            <label for="data_inicio" class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" id="data_inicio" class="form-control" value="<?php echo $dataInicio; ?>">
                        </div>
                        
                        <div class="col-md-2">
                            <label for="data_fim" class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" id="data_fim" class="form-control" value="<?php echo $dataFim; ?>">
                        </div>
                        
                        <div class="col-md-2">
                            <label for="empresa_id" class="form-label">Empresa</label>
                            <select name="empresa_id" id="empresa_id" class="form-control">
                                <option value="">Todas</option>
                                <?php foreach ($empresas as $empresa): ?>
                                    <option value="<?php echo $empresa['id']; ?>" <?php echo $empresaId == $empresa['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($empresa['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-2">
                            <label for="usuario_id" class="form-label">Usuário</label>
                            <select name="usuario_id" id="usuario_id" class="form-control">
                                <option value="">Todos</option>
                                <?php foreach ($usuarios as $usuario): ?>
                                    <option value="<?php echo $usuario['id']; ?>" <?php echo $usuarioId == $usuario['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($usuario['nome'] . ' (' . $usuario['login'] . ')'); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Filtrar</button>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Logs -->
            <div class="card log-card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Registros de Log</h5>
                    <div>
                        <a href="logs.php?acao=limpar" class="btn btn-sm btn-warning" onclick="return confirm('Tem certeza que deseja limpar os logs antigos (mais de 30 dias)? Esta ação não pode ser desfeita.')">
                            <i class="fas fa-trash me-1"></i> Limpar Logs Antigos
                        </a>
                        <a href="logs.php?acao=exportar&tipo=<?php echo $tipoLog; ?>&data_inicio=<?php echo $dataInicio; ?>&data_fim=<?php echo $dataFim; ?>&empresa_id=<?php echo $empresaId; ?>&usuario_id=<?php echo $usuarioId; ?>" class="btn btn-sm btn-success">
                            <i class="fas fa-file-excel me-1"></i> Exportar
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <?php if ($totalLogs > 0): ?>
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i> Exibindo <?php echo count($logs); ?> de <?php echo $totalLogs; ?> registros encontrados.
                            <?php if ($temMaisLogs): ?>
                                <strong>Nota:</strong> Apenas os 1000 registros mais recentes são exibidos. Use filtros para refinar sua busca.
                            <?php endif; ?>
                        </div>
                        
                        <div class="table-responsive">
                            <table class="table table-striped table-hover log-table">
                                <thead>
                                    <tr>
                                        <th>Data/Hora</th>
                                        <th>Tipo</th>
                                        <th>Empresa</th>
                                        <th>Usuário</th>
                                        <th>Ação</th>
                                        <th>Detalhes</th>
                                        <th>IP</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($logs as $log): ?>
                                        <tr>
                                            <td><?php echo formatarData($log['data']); ?></td>
                                            <td>
                                                <?php if ($log['tipo'] === 'acesso'): ?>
                                                    <span class="badge log-badge-acesso">Acesso</span>
                                                <?php elseif ($log['tipo'] === 'operacao'): ?>
                                                    <span class="badge log-badge-operacao">Operação</span>
                                                <?php elseif ($log['tipo'] === 'erro'): ?>
                                                    <span class="badge log-badge-erro">Erro</span>
                                                <?php elseif ($log['tipo'] === 'superadmin'): ?>
                                                    <span class="badge log-badge-superadmin">Superadmin</span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary"><?php echo htmlspecialchars($log['tipo']); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($log['empresa_nome'] ?? 'Sistema'); ?></td>
                                            <td><?php echo htmlspecialchars($log['usuario_nome'] ?? ($log['tipo'] === 'superadmin' ? 'Superadmin' : 'Sistema')); ?></td>
                                            <td><?php echo htmlspecialchars($log['acao']); ?></td>
                                            <td>
                                                <?php if (strlen($log['detalhes']) > 50): ?>
                                                    <span data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo htmlspecialchars($log['detalhes']); ?>">
                                                        <?php echo htmlspecialchars(substr($log['detalhes'], 0, 50) . '...'); ?>
                                                    </span>
                                                <?php else: ?>
                                                    <?php echo htmlspecialchars($log['detalhes']); ?>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo htmlspecialchars($log['ip']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle me-2"></i> Nenhum registro de log encontrado com os filtros selecionados.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle sidebar
            document.getElementById('sidebarCollapse').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('active');
                document.getElementById('content').classList.toggle('active');
            });
            
            // Inicializar tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
            
            // Atualizar lista de usuários quando empresa mudar
            document.getElementById('empresa_id').addEventListener('change', function() {
                document.getElementById('usuario_id').value = '';
                document.forms[0].submit();
            });
        });
    </script>
</body>
</html>
