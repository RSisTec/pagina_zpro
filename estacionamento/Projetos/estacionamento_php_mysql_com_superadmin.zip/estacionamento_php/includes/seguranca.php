<?php
/**
 * Arquivo de segurança para proteção contra ataques comuns
 * 
 * Este arquivo contém funções para proteção contra ataques comuns como XSS, CSRF, SQL Injection, etc.
 */

/**
 * Verifica se a requisição é HTTPS
 * 
 * @return bool Verdadeiro se a requisição for HTTPS
 */
function isHTTPS() {
    return (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') || 
           (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
}

/**
 * Define cabeçalhos de segurança
 */
function definirCabecalhosSeguranca() {
    // Proteção contra clickjacking
    header('X-Frame-Options: SAMEORIGIN');
    
    // Proteção contra MIME sniffing
    header('X-Content-Type-Options: nosniff');
    
    // Proteção contra XSS
    header('X-XSS-Protection: 1; mode=block');
    
    // Política de segurança de conteúdo (CSP)
    header("Content-Security-Policy: default-src 'self'; script-src 'self' https://code.jquery.com https://cdn.jsdelivr.net 'unsafe-inline'; style-src 'self' https://cdn.jsdelivr.net https://cdnjs.cloudflare.com 'unsafe-inline'; font-src 'self' https://cdnjs.cloudflare.com; img-src 'self' data:;");
    
    // Referrer Policy
    header('Referrer-Policy: strict-origin-when-cross-origin');
    
    // Desabilitar cache para páginas sensíveis
    if (strpos($_SERVER['REQUEST_URI'], 'login.php') !== false || 
        strpos($_SERVER['REQUEST_URI'], 'admin/') !== false) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('Pragma: no-cache');
        header('Expires: 0');
    }
}

/**
 * Verifica se a requisição é de origem confiável
 * 
 * @return bool Verdadeiro se a requisição for de origem confiável
 */
function verificarOrigemConfiavel() {
    if (!isset($_SERVER['HTTP_REFERER'])) {
        return false;
    }
    
    $referer = parse_url($_SERVER['HTTP_REFERER']);
    $host = $_SERVER['HTTP_HOST'];
    
    return isset($referer['host']) && $referer['host'] === $host;
}

/**
 * Proteção contra ataques de força bruta
 * 
 * @param string $ip Endereço IP
 * @param string $acao Ação sendo realizada (ex: 'login')
 * @param int $maxTentativas Número máximo de tentativas
 * @param int $tempoEspera Tempo de espera em segundos
 * @return bool Verdadeiro se o IP não estiver bloqueado
 */
function protecaoForcaBruta($ip, $acao, $maxTentativas = 5, $tempoEspera = 300) {
    $arquivoLog = __DIR__ . '/../logs/tentativas_' . $acao . '.log';
    $diretorioLog = dirname($arquivoLog);
    
    // Criar diretório de logs se não existir
    if (!file_exists($diretorioLog)) {
        mkdir($diretorioLog, 0755, true);
    }
    
    // Inicializar array de tentativas
    $tentativas = [];
    
    // Carregar tentativas anteriores
    if (file_exists($arquivoLog)) {
        $conteudo = file_get_contents($arquivoLog);
        $linhas = explode("\n", $conteudo);
        
        foreach ($linhas as $linha) {
            if (empty($linha)) {
                continue;
            }
            
            list($ipLog, $timestampLog) = explode('|', $linha);
            
            if ($ipLog === $ip && (time() - $timestampLog) < $tempoEspera) {
                $tentativas[] = $timestampLog;
            }
        }
    }
    
    // Verificar se excedeu o número máximo de tentativas
    if (count($tentativas) >= $maxTentativas) {
        return false;
    }
    
    // Registrar nova tentativa
    $novaLinha = $ip . '|' . time() . "\n";
    file_put_contents($arquivoLog, $novaLinha, FILE_APPEND);
    
    return true;
}

/**
 * Limpa tentativas de força bruta para um IP
 * 
 * @param string $ip Endereço IP
 * @param string $acao Ação sendo realizada (ex: 'login')
 */
function limparTentativasForcaBruta($ip, $acao) {
    $arquivoLog = __DIR__ . '/../logs/tentativas_' . $acao . '.log';
    
    if (file_exists($arquivoLog)) {
        $conteudo = file_get_contents($arquivoLog);
        $linhas = explode("\n", $conteudo);
        $novoConteudo = '';
        
        foreach ($linhas as $linha) {
            if (empty($linha)) {
                continue;
            }
            
            list($ipLog, $timestampLog) = explode('|', $linha);
            
            if ($ipLog !== $ip) {
                $novoConteudo .= $linha . "\n";
            }
        }
        
        file_put_contents($arquivoLog, $novoConteudo);
    }
}

/**
 * Proteção contra ataques de SQL Injection
 * 
 * @param string $valor Valor a ser verificado
 * @return bool Verdadeiro se o valor não contiver padrões de SQL Injection
 */
function verificarSQLInjection($valor) {
    $padroesSQL = [
        '/\bUNION\b/i',
        '/\bSELECT\b/i',
        '/\bINSERT\b/i',
        '/\bUPDATE\b/i',
        '/\bDELETE\b/i',
        '/\bDROP\b/i',
        '/\bALTER\b/i',
        '/\bEXEC\b/i',
        '/\bCREATE\b/i',
        '/\bSHOW\b/i',
        '/\bDESCRIBE\b/i',
        '/--/',
        '/;/',
        '/\/\*.*\*\//'
    ];
    
    foreach ($padroesSQL as $padrao) {
        if (preg_match($padrao, $valor)) {
            return false;
        }
    }
    
    return true;
}

/**
 * Proteção contra ataques de XSS
 * 
 * @param string $valor Valor a ser verificado
 * @return bool Verdadeiro se o valor não contiver padrões de XSS
 */
function verificarXSS($valor) {
    $padroesXSS = [
        '/<script\b[^>]*>(.*?)<\/script>/i',
        '/javascript:/i',
        '/onclick/i',
        '/onload/i',
        '/onmouseover/i',
        '/onerror/i',
        '/onsubmit/i',
        '/onchange/i',
        '/onkeyup/i',
        '/onkeydown/i',
        '/onkeypress/i',
        '/onblur/i',
        '/onfocus/i',
        '/alert\s*\(/i',
        '/eval\s*\(/i',
        '/document\.cookie/i',
        '/document\.location/i',
        '/document\.write/i',
        '/<iframe/i',
        '/<embed/i',
        '/<object/i',
        '/<base/i'
    ];
    
    foreach ($padroesXSS as $padrao) {
        if (preg_match($padrao, $valor)) {
            return false;
        }
    }
    
    return true;
}

/**
 * Verifica se um valor é seguro (sem SQL Injection e XSS)
 * 
 * @param string $valor Valor a ser verificado
 * @return bool Verdadeiro se o valor for seguro
 */
function valorSeguro($valor) {
    return verificarSQLInjection($valor) && verificarXSS($valor);
}

/**
 * Registra tentativa de ataque
 * 
 * @param string $tipo Tipo de ataque
 * @param string $valor Valor suspeito
 * @param string $ip Endereço IP
 */
function registrarTentativaAtaque($tipo, $valor, $ip) {
    $arquivoLog = __DIR__ . '/../logs/ataques.log';
    $diretorioLog = dirname($arquivoLog);
    
    // Criar diretório de logs se não existir
    if (!file_exists($diretorioLog)) {
        mkdir($diretorioLog, 0755, true);
    }
    
    $data = date('Y-m-d H:i:s');
    $uri = $_SERVER['REQUEST_URI'] ?? 'Unknown';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    
    $mensagemLog = "[$data] [$ip] [$uri] [$tipo] [$valor] [$userAgent]\n";
    
    file_put_contents($arquivoLog, $mensagemLog, FILE_APPEND);
}

/**
 * Verifica todos os parâmetros GET e POST para ataques
 */
function verificarParametros() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    
    // Verificar parâmetros GET
    foreach ($_GET as $chave => $valor) {
        if (is_string($valor)) {
            if (!verificarSQLInjection($valor)) {
                registrarTentativaAtaque('SQL Injection (GET)', $valor, $ip);
                die('Acesso negado.');
            }
            
            if (!verificarXSS($valor)) {
                registrarTentativaAtaque('XSS (GET)', $valor, $ip);
                die('Acesso negado.');
            }
        }
    }
    
    // Verificar parâmetros POST
    foreach ($_POST as $chave => $valor) {
        if (is_string($valor) && $chave !== 'csrf_token') {
            if (!verificarSQLInjection($valor)) {
                registrarTentativaAtaque('SQL Injection (POST)', $valor, $ip);
                die('Acesso negado.');
            }
            
            if (!verificarXSS($valor)) {
                registrarTentativaAtaque('XSS (POST)', $valor, $ip);
                die('Acesso negado.');
            }
        }
    }
}

// Aplicar cabeçalhos de segurança
definirCabecalhosSeguranca();

// Verificar parâmetros para ataques
verificarParametros();
