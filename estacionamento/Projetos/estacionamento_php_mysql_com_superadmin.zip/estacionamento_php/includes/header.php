<?php
/**
 * Cabeçalho comum para todas as páginas administrativas
 */
require_once __DIR__ . '/../includes/session.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

// Verificar se o usuário está autenticado
requireLogin();

// Verificar se a sessão expirou
if (verificarSessaoExpirada()) {
    header('Location: ../login.php');
    exit;
}

// Obter informações do usuário atual
$nomeUsuario = getCurrentUserName();
$nivelUsuario = getCurrentUserLevel();
$empresaNome = $_SESSION['empresa_nome'] ?? 'Empresa';

// Determinar a página atual
$paginaAtual = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tituloPagina ?? 'Sistema de Estacionamento'; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/components.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3><?php echo sanitizeOutput($empresaNome); ?></h3>
            </div>

            <ul class="list-unstyled components">
                <li class="<?php echo $paginaAtual === 'index.php' ? 'active' : ''; ?>">
                    <a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                </li>
                <li class="<?php echo $paginaAtual === 'veiculos.php' ? 'active' : ''; ?>">
                    <a href="veiculos.php"><i class="fas fa-car"></i> Veículos</a>
                </li>
                <li class="<?php echo $paginaAtual === 'mensalistas.php' ? 'active' : ''; ?>">
                    <a href="mensalistas.php"><i class="fas fa-users"></i> Mensalistas</a>
                </li>
                <li class="<?php echo $paginaAtual === 'isentos.php' ? 'active' : ''; ?>">
                    <a href="isentos.php"><i class="fas fa-id-card"></i> Isentos</a>
                </li>
                <li class="<?php echo $paginaAtual === 'servicos.php' ? 'active' : ''; ?>">
                    <a href="servicos.php"><i class="fas fa-tools"></i> Serviços</a>
                </li>
                <li class="<?php echo $paginaAtual === 'precos.php' ? 'active' : ''; ?>">
                    <a href="precos.php"><i class="fas fa-dollar-sign"></i> Preços</a>
                </li>
                <li class="<?php echo $paginaAtual === 'relatorios.php' ? 'active' : ''; ?>">
                    <a href="relatorios.php"><i class="fas fa-chart-bar"></i> Relatórios</a>
                </li>
                <?php if ($nivelUsuario === 'admin'): ?>
                <li class="<?php echo $paginaAtual === 'usuarios.php' ? 'active' : ''; ?>">
                    <a href="usuarios.php"><i class="fas fa-user-cog"></i> Usuários</a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>

        <!-- Conteúdo da Página -->
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <div class="ml-auto">
                        <div class="dropdown">
                            <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-user"></i> <?php echo sanitizeOutput($nomeUsuario); ?>
                            </button>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item" href="perfil.php"><i class="fas fa-user-edit"></i> Meu Perfil</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
            
            <div class="container-fluid">
                <?php echo exibirMensagemFlash(); ?>
