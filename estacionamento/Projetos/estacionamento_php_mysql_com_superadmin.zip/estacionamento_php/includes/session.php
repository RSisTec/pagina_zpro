<?php
/**
 * Gerenciamento de sessão
 * 
 * Este arquivo contém funções para gerenciamento de sessão do usuário
 */

// Iniciar sessão se ainda não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    // Configurações de segurança para a sessão
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    
    if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        ini_set('session.cookie_secure', 1);
    }
    
    session_start();
}

/**
 * Verifica se o usuário está autenticado
 * 
 * @return bool Verdadeiro se o usuário estiver autenticado
 */
function isAuthenticated() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Verifica se o usuário é superadmin
 * 
 * @return bool Verdadeiro se o usuário for superadmin
 */
function isSuperAdmin() {
    return isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'superadmin';
}

/**
 * Verifica se o usuário é admin
 * 
 * @return bool Verdadeiro se o usuário for admin
 */
function isAdmin() {
    return isset($_SESSION['user_nivel']) && $_SESSION['user_nivel'] === 'admin';
}

/**
 * Verifica se o usuário tem permissão para acessar a página
 * 
 * @param string $requiredLevel Nível mínimo requerido (admin, operador, visualizador)
 * @return bool Verdadeiro se o usuário tiver permissão
 */
function hasPermission($requiredLevel) {
    if (!isAuthenticated()) {
        return false;
    }
    
    if (isSuperAdmin()) {
        return true;
    }
    
    $nivelUsuario = $_SESSION['user_nivel'] ?? '';
    
    switch ($requiredLevel) {
        case 'admin':
            return $nivelUsuario === 'admin';
        case 'operador':
            return $nivelUsuario === 'admin' || $nivelUsuario === 'operador';
        case 'visualizador':
            return $nivelUsuario === 'admin' || $nivelUsuario === 'operador' || $nivelUsuario === 'visualizador';
        default:
            return false;
    }
}

/**
 * Redireciona para a página de login se o usuário não estiver autenticado
 */
function requireLogin() {
    if (!isAuthenticated()) {
        header('Location: /login.php');
        exit;
    }
}

/**
 * Redireciona para a página de acesso negado se o usuário não tiver permissão
 * 
 * @param string $requiredLevel Nível mínimo requerido (admin, operador, visualizador)
 */
function requirePermission($requiredLevel) {
    if (!hasPermission($requiredLevel)) {
        if (!isAuthenticated()) {
            header('Location: /login.php');
        } else {
            header('Location: /acesso-negado.php');
        }
        exit;
    }
}

/**
 * Redireciona para a página de login de superadmin se o usuário não for superadmin
 */
function requireSuperAdmin() {
    if (!isSuperAdmin()) {
        header('Location: /superadmin/login.php');
        exit;
    }
}

/**
 * Obtém o ID do usuário atual
 * 
 * @return string|null ID do usuário ou null se não estiver autenticado
 */
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? null;
}

/**
 * Obtém o ID da empresa do usuário atual
 * 
 * @return string|null ID da empresa ou null se não estiver autenticado ou for superadmin
 */
function getCurrentEmpresaId() {
    return $_SESSION['empresa_id'] ?? null;
}

/**
 * Obtém o nome do usuário atual
 * 
 * @return string|null Nome do usuário ou null se não estiver autenticado
 */
function getCurrentUserName() {
    return $_SESSION['user_nome'] ?? null;
}

/**
 * Obtém o nível do usuário atual
 * 
 * @return string|null Nível do usuário ou null se não estiver autenticado
 */
function getCurrentUserLevel() {
    return $_SESSION['user_nivel'] ?? null;
}

/**
 * Obtém o tipo do usuário atual (usuario ou superadmin)
 * 
 * @return string|null Tipo do usuário ou null se não estiver autenticado
 */
function getCurrentUserType() {
    return $_SESSION['user_type'] ?? null;
}
