<?php
/**
 * Arquivo de inicialização do sistema
 * 
 * Este arquivo deve ser incluído em todas as páginas do sistema
 * para garantir a configuração correta e segurança
 */

// Iniciar sessão
session_start();

// Definir timezone
date_default_timezone_set('America/Sao_Paulo');

// Incluir arquivos essenciais
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/validacao.php';
require_once __DIR__ . '/includes/seguranca.php';

// Criar diretório de logs se não existir
$logDir = __DIR__ . '/logs';
if (!file_exists($logDir)) {
    mkdir($logDir, 0755, true);
}

// Configurar tratamento de erros
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', $logDir . '/php_errors.log');

// Verificar tempo limite da sessão
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 1800)) {
    // Sessão expirada após 30 minutos de inatividade
    session_unset();
    session_destroy();
}

// Atualizar timestamp da última atividade
$_SESSION['last_activity'] = time();

// Regenerar ID da sessão periodicamente para evitar fixação de sessão
if (!isset($_SESSION['created'])) {
    $_SESSION['created'] = time();
} else if (time() - $_SESSION['created'] > 1800) {
    // Regenerar ID da sessão a cada 30 minutos
    session_regenerate_id(true);
    $_SESSION['created'] = time();
}
