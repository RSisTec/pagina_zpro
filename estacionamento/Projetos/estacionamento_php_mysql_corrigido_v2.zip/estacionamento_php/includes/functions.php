<?php
/**
 * Funções utilitárias para o sistema
 * 
 * Este arquivo contém funções utilitárias usadas em todo o sistema
 */

/**
 * Sanitiza uma string para evitar XSS
 * 
 * @param string $str String a ser sanitizada
 * @return string String sanitizada
 */
function sanitizeOutput($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}

/**
 * Gera um token CSRF
 * 
 * @return string Token CSRF
 */
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verifica se o token CSRF é válido
 * 
 * @param string $token Token a ser verificado
 * @return bool Verdadeiro se o token for válido
 */
function verifyCsrfToken($token) {
    if (!isset($_SESSION['csrf_token']) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Formata um valor monetário
 * 
 * @param float $valor Valor a ser formatado
 * @return string Valor formatado
 */
function formatarMoeda($valor) {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

/**
 * Formata uma data
 * 
 * @param string $data Data a ser formatada (formato Y-m-d ou Y-m-d H:i:s)
 * @param bool $incluirHora Se deve incluir a hora
 * @return string Data formatada
 */
function formatarData($data, $incluirHora = false) {
    if (empty($data)) {
        return '';
    }
    
    $timestamp = strtotime($data);
    
    if ($timestamp === false) {
        return '';
    }
    
    if ($incluirHora) {
        return date('d/m/Y H:i:s', $timestamp);
    } else {
        return date('d/m/Y', $timestamp);
    }
}

/**
 * Converte uma data do formato brasileiro para o formato do banco de dados
 * 
 * @param string $data Data no formato dd/mm/yyyy
 * @return string Data no formato yyyy-mm-dd
 */
function converterDataParaBanco($data) {
    if (empty($data)) {
        return null;
    }
    
    $partes = explode('/', $data);
    
    if (count($partes) !== 3) {
        return null;
    }
    
    return $partes[2] . '-' . $partes[1] . '-' . $partes[0];
}

/**
 * Gera um alerta HTML
 * 
 * @param string $mensagem Mensagem do alerta
 * @param string $tipo Tipo do alerta (success, danger, warning, info)
 * @return string HTML do alerta
 */
function gerarAlerta($mensagem, $tipo = 'info') {
    return '<div class="alert alert-' . $tipo . ' alert-dismissible fade show" role="alert">
                ' . $mensagem . '
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
            </div>';
}

/**
 * Redireciona para uma URL com uma mensagem flash
 * 
 * @param string $url URL para redirecionamento
 * @param string $mensagem Mensagem a ser exibida
 * @param string $tipo Tipo da mensagem (success, danger, warning, info)
 */
function redirecionarComMensagem($url, $mensagem, $tipo = 'success') {
    $_SESSION['flash_message'] = $mensagem;
    $_SESSION['flash_type'] = $tipo;
    
    header('Location: ' . $url);
    exit;
}

/**
 * Exibe uma mensagem flash, se existir
 * 
 * @return string HTML da mensagem ou string vazia
 */
function exibirMensagemFlash() {
    if (isset($_SESSION['flash_message']) && !empty($_SESSION['flash_message'])) {
        $mensagem = $_SESSION['flash_message'];
        $tipo = $_SESSION['flash_type'] ?? 'info';
        
        // Limpar a mensagem flash
        unset($_SESSION['flash_message']);
        unset($_SESSION['flash_type']);
        
        return gerarAlerta($mensagem, $tipo);
    }
    
    return '';
}

/**
 * Gera um ID único
 * 
 * @return string ID único
 */
function gerarId() {
    return uniqid('', true);
}

/**
 * Verifica se uma requisição é POST
 * 
 * @return bool Verdadeiro se for uma requisição POST
 */
function isPostRequest() {
    return $_SERVER['REQUEST_METHOD'] === 'POST';
}

/**
 * Obtém um valor de um array de forma segura
 * 
 * @param array $array Array a ser verificado
 * @param string $key Chave a ser buscada
 * @param mixed $default Valor padrão caso a chave não exista
 * @return mixed Valor encontrado ou valor padrão
 */
function getValue($array, $key, $default = null) {
    return isset($array[$key]) ? $array[$key] : $default;
}

/**
 * Verifica se uma string está vazia
 * 
 * @param string $str String a ser verificada
 * @return bool Verdadeiro se a string estiver vazia
 */
function isEmpty($str) {
    return $str === null || trim($str) === '';
}

/**
 * Registra um erro no log
 * 
 * @param string $mensagem Mensagem de erro
 * @param Exception $exception Exceção (opcional)
 */
function logError($mensagem, $exception = null) {
    $logDir = __DIR__ . '/../logs';
    
    // Criar diretório de logs se não existir
    if (!file_exists($logDir)) {
        mkdir($logDir, 0755, true);
    }
    
    $logFile = $logDir . '/error.log';
    
    $data = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $uri = $_SERVER['REQUEST_URI'] ?? 'Unknown';
    
    $mensagemLog = "[$data] [$ip] [$uri] $mensagem";
    
    if ($exception !== null) {
        $mensagemLog .= "\nException: " . $exception->getMessage();
        $mensagemLog .= "\nStack trace: " . $exception->getTraceAsString();
    }
    
    $mensagemLog .= "\n\n";
    
    file_put_contents($logFile, $mensagemLog, FILE_APPEND);
}
