<?php
/**
 * Página de gestão de serviços
 */
$tituloPagina = 'Serviços - Sistema de Estacionamento';
require_once '../includes/header.php';
require_once '../config/database.php';

// Verificar permissão
requirePermission('operador');

// Processar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? '';
$mensagem = '';
$tipoMensagem = '';

// Obter empresa atual
$empresaId = getCurrentEmpresaId();

// Inicializar variáveis para o formulário
$servico = [
    'id' => '',
    'nome' => '',
    'descricao' => '',
    'valor' => '',
    'ativo' => 1
];

// Processar exclusão
if ($acao === 'excluir' && !empty($id)) {
    try {
        $conn = getConnection();
        
        // Verificar se o serviço está sendo usado
        $queryVerificar = "SELECT COUNT(*) as total FROM veiculos_servicos 
                          WHERE servico_id = :id 
                          AND empresa_id = :empresa_id";
        $stmtVerificar = $conn->prepare($queryVerificar);
        $stmtVerificar->bindParam(':id', $id);
        $stmtVerificar->bindParam(':empresa_id', $empresaId);
        $stmtVerificar->execute();
        
        if ($stmtVerificar->fetch()['total'] > 0) {
            $mensagem = 'Não é possível excluir este serviço pois ele está sendo usado.';
            $tipoMensagem = 'danger';
        } else {
            // Excluir serviço
            $query = "DELETE FROM servicos 
                      WHERE id = :id 
                      AND empresa_id = :empresa_id";
            $stmt = $conn->prepare($query);
            $stmt->bindParam(':id', $id);
            $stmt->bindParam(':empresa_id', $empresaId);
            $stmt->execute();
            
            $mensagem = 'Serviço excluído com sucesso!';
            $tipoMensagem = 'success';
        }
    } catch (PDOException $e) {
        logError('Erro ao excluir serviço', $e);
        $mensagem = 'Erro ao excluir serviço. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    }
}

// Carregar dados para edição
if ($acao === 'editar' && !empty($id)) {
    try {
        $conn = getConnection();
        
        $query = "SELECT * FROM servicos 
                  WHERE id = :id 
                  AND empresa_id = :empresa_id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':empresa_id', $empresaId);
        $stmt->execute();
        
        $result = $stmt->fetch();
        
        if ($result) {
            $servico = $result;
        } else {
            $mensagem = 'Serviço não encontrado.';
            $tipoMensagem = 'danger';
        }
    } catch (PDOException $e) {
        logError('Erro ao carregar serviço para edição', $e);
        $mensagem = 'Erro ao carregar dados do serviço. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    }
}

// Processar formulário
if (isPostRequest()) {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $servicoId = $_POST['id'] ?? '';
            $nome = $_POST['nome'] ?? '';
            $descricao = $_POST['descricao'] ?? '';
            $valor = $_POST['valor'] ?? '';
            $ativo = isset($_POST['ativo']) ? 1 : 0;
            
            // Validar dados
            if (empty($nome) || $valor === '') {
                $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
                $tipoMensagem = 'danger';
                
                // Manter dados do formulário
                $servico = [
                    'id' => $servicoId,
                    'nome' => $nome,
                    'descricao' => $descricao,
                    'valor' => $valor,
                    'ativo' => $ativo
                ];
            } else {
                if (empty($servicoId)) {
                    // Inserir novo serviço
                    $query = "INSERT INTO servicos (nome, descricao, valor, ativo, empresa_id) 
                              VALUES (:nome, :descricao, :valor, :ativo, :empresa_id)";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':nome', $nome);
                    $stmt->bindParam(':descricao', $descricao);
                    $stmt->bindParam(':valor', $valor);
                    $stmt->bindParam(':ativo', $ativo);
                    $stmt->bindParam(':empresa_id', $empresaId);
                    $stmt->execute();
                    
                    $mensagem = 'Serviço cadastrado com sucesso!';
                    $tipoMensagem = 'success';
                } else {
                    // Atualizar serviço existente
                    $query = "UPDATE servicos 
                              SET nome = :nome, 
                                  descricao = :descricao, 
                                  valor = :valor, 
                                  ativo = :ativo 
                              WHERE id = :id 
                              AND empresa_id = :empresa_id";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':nome', $nome);
                    $stmt->bindParam(':descricao', $descricao);
                    $stmt->bindParam(':valor', $valor);
                    $stmt->bindParam(':ativo', $ativo);
                    $stmt->bindParam(':id', $servicoId);
                    $stmt->bindParam(':empresa_id', $empresaId);
                    $stmt->execute();
                    
                    $mensagem = 'Serviço atualizado com sucesso!';
                    $tipoMensagem = 'success';
                }
                
                // Limpar formulário após sucesso
                $servico = [
                    'id' => '',
                    'nome' => '',
                    'descricao' => '',
                    'valor' => '',
                    'ativo' => 1
                ];
            }
        } catch (PDOException $e) {
            logError('Erro ao salvar serviço', $e);
            $mensagem = 'Erro ao salvar serviço. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
        }
    }
}

// Obter lista de serviços
try {
    $conn = getConnection();
    
    $query = "SELECT * FROM servicos 
              WHERE empresa_id = :empresa_id 
              ORDER BY nome";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':empresa_id', $empresaId);
    $stmt->execute();
    $servicos = $stmt->fetchAll();
} catch (PDOException $e) {
    logError('Erro ao obter lista de serviços', $e);
    $servicos = [];
}
?>

<h1 class="mb-4">Gestão de Serviços</h1>

<?php if (!empty($mensagem)): ?>
    <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
        <?php echo $mensagem; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title"><?php echo empty($servico['id']) ? 'Novo Serviço' : 'Editar Serviço'; ?></h5>
            </div>
            <div class="card-body">
                <form method="POST" action="servicos.php">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    <input type="hidden" name="id" value="<?php echo sanitizeOutput($servico['id']); ?>">
                    
                    <div class="form-group mb-3">
                        <label for="nome">Nome*</label>
                        <input type="text" id="nome" name="nome" class="form-control" value="<?php echo sanitizeOutput($servico['nome']); ?>" required>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="descricao">Descrição</label>
                        <textarea id="descricao" name="descricao" class="form-control" rows="3"><?php echo sanitizeOutput($servico['descricao']); ?></textarea>
                    </div>
                    
                    <div class="form-group mb-3">
                        <label for="valor">Valor*</label>
                        <input type="number" id="valor" name="valor" class="form-control" step="0.01" min="0" value="<?php echo sanitizeOutput($servico['valor']); ?>" required>
                    </div>
                    
                    <div class="form-check mb-3">
                        <input type="checkbox" id="ativo" name="ativo" class="form-check-input" <?php echo $servico['ativo'] ? 'checked' : ''; ?>>
                        <label class="form-check-label" for="ativo">Ativo</label>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">Salvar</button>
                    <?php if (!empty($servico['id'])): ?>
                        <a href="servicos.php" class="btn btn-secondary">Cancelar</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title">Lista de Serviços</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Descrição</th>
                                <th>Valor</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($servicos) > 0): ?>
                                <?php foreach ($servicos as $s): ?>
                                    <tr>
                                        <td><?php echo sanitizeOutput($s['nome']); ?></td>
                                        <td><?php echo sanitizeOutput($s['descricao']); ?></td>
                                        <td><?php echo formatarMoeda($s['valor']); ?></td>
                                        <td>
                                            <?php if ($s['ativo']): ?>
                                                <span class="badge bg-success">Ativo</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Inativo</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a href="servicos.php?acao=editar&id=<?php echo $s['id']; ?>" class="btn btn-sm btn-primary">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="servicos.php?acao=excluir&id=<?php echo $s['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir este serviço?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center">Nenhum serviço cadastrado.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
