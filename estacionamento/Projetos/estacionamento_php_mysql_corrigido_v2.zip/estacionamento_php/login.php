<?php
/**
 * Página de login do sistema
 */
require_once 'includes/session.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

// Se o usuário já estiver autenticado, redirecionar para a página inicial
if (isAuthenticated()) {
    header('Location: admin/index.php');
    exit;
}

$erro = '';

// Processar o formulário de login
if (isPostRequest()) {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $erro = 'Erro de segurança. Por favor, tente novamente.';
    } else {
        $login = $_POST['login'] ?? '';
        $senha = $_POST['senha'] ?? '';
        
        if (empty($login) || empty($senha)) {
            $erro = 'Por favor, preencha todos os campos.';
        } else {
            // Tentar autenticar o usuário
            $usuario = autenticarUsuario($login, $senha);
            
            if ($usuario) {
                // Criar sessão para o usuário
                criarSessaoUsuario($usuario);
                
                // Redirecionar para a página inicial
                header('Location: admin/index.php');
                exit;
            } else {
                $erro = 'Login ou senha incorretos.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Estacionamento</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/components.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="login-container">
            <div class="login-card">
                <div class="login-header">
                    <h1>Sistema de Estacionamento</h1>
                    <p>Faça login para acessar o sistema</p>
                </div>
                
                <?php if (!empty($erro)): ?>
                    <div class="alert alert-danger">
                        <?php echo sanitizeOutput($erro); ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="login.php" class="login-form">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                    
                    <div class="form-group">
                        <label for="login">Login</label>
                        <input type="text" id="login" name="login" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="senha">Senha</label>
                        <input type="password" id="senha" name="senha" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">Entrar</button>
                    </div>
                </form>
                
                <div class="login-footer">
                    <p>Esqueceu sua senha? Entre em contato com o administrador.</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
