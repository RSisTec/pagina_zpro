<?php
/**
 * Dashboard do superadmin
 */
session_start();

// Incluir arquivo de configuração
require_once 'config.php';

// Verificar se está logado
requireSuperadminLogin();

// Incluir funções de banco de dados
require_once '../config/database.php';

// Obter estatísticas gerais
try {
    $conn = getConnection();
    
    // Total de empresas
    $query = "SELECT COUNT(*) as total FROM empresas";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $totalEmpresas = $stmt->fetch()['total'] ?? 0;
    
    // Total de usuários
    $query = "SELECT COUNT(*) as total FROM usuarios";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $totalUsuarios = $stmt->fetch()['total'] ?? 0;
    
    // Total de veículos
    $query = "SELECT COUNT(*) as total FROM veiculos";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $totalVeiculos = $stmt->fetch()['total'] ?? 0;
    
    // Total de mensalistas
    $query = "SELECT COUNT(*) as total FROM mensalistas";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $totalMensalistas = $stmt->fetch()['total'] ?? 0;
    
    // Faturamento total
    $query = "SELECT SUM(valor_total) as total FROM veiculos WHERE saida IS NOT NULL";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $faturamentoTotal = $stmt->fetch()['total'] ?? 0;
    
    // Empresas recentes
    $query = "SELECT id, nome, data_cadastro FROM empresas ORDER BY data_cadastro DESC LIMIT 5";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $empresasRecentes = $stmt->fetchAll();
    
    // Últimos acessos
    $query = "SELECT u.nome as usuario, e.nome as empresa, u.ultimo_acesso 
              FROM usuarios u 
              JOIN empresas e ON u.empresa_id = e.id 
              WHERE u.ultimo_acesso IS NOT NULL 
              ORDER BY u.ultimo_acesso DESC 
              LIMIT 10";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $ultimosAcessos = $stmt->fetchAll();
    
} catch (PDOException $e) {
    logError('Erro ao obter estatísticas do superadmin', $e);
    $totalEmpresas = 0;
    $totalUsuarios = 0;
    $totalVeiculos = 0;
    $totalMensalistas = 0;
    $faturamentoTotal = 0;
    $empresasRecentes = [];
    $ultimosAcessos = [];
}

// Função para formatar data
function formatarData($data, $incluirHora = false) {
    if (!$data) {
        return '-';
    }
    
    $date = new DateTime($data);
    
    if ($incluirHora) {
        return $date->format('d/m/Y H:i:s');
    }
    
    return $date->format('d/m/Y');
}

// Função para formatar moeda
function formatarMoeda($valor) {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Superadmin - Sistema de Estacionamento</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        
        .superadmin-navbar {
            background-color: #212529;
            padding: 15px 10px;
        }
        
        .superadmin-sidebar {
            min-width: 250px;
            max-width: 250px;
            background: #343a40;
            color: #fff;
            transition: all 0.3s;
            height: 100vh;
            position: fixed;
            z-index: 999;
        }
        
        .superadmin-sidebar .sidebar-header {
            padding: 20px;
            background: #212529;
        }
        
        .superadmin-sidebar ul.components {
            padding: 20px 0;
            border-bottom: 1px solid #4b545c;
        }
        
        .superadmin-sidebar ul p {
            color: #fff;
            padding: 10px;
        }
        
        .superadmin-sidebar ul li a {
            padding: 10px;
            font-size: 1.1em;
            display: block;
            color: #fff;
            text-decoration: none;
        }
        
        .superadmin-sidebar ul li a:hover {
            color: #fff;
            background: #495057;
        }
        
        .superadmin-sidebar ul li.active > a {
            color: #fff;
            background: #dc3545;
        }
        
        .superadmin-content {
            width: 100%;
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s;
            margin-left: 250px;
        }
        
        .superadmin-content.active {
            margin-left: 0;
        }
        
        .card-stats {
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            border: none;
        }
        
        .card-stats .card-body {
            padding: 20px;
        }
        
        .card-stats .icon {
            font-size: 3em;
            opacity: 0.5;
        }
        
        .card-stats .numbers {
            text-align: right;
        }
        
        .card-stats .numbers p {
            margin-bottom: 0;
            font-size: 14px;
            color: #888;
        }
        
        .card-stats .numbers h3 {
            margin-bottom: 0;
            font-weight: bold;
        }
        
        .bg-info-light {
            background-color: #cff4fc;
            color: #055160;
        }
        
        .bg-success-light {
            background-color: #d1e7dd;
            color: #0f5132;
        }
        
        .bg-warning-light {
            background-color: #fff3cd;
            color: #664d03;
        }
        
        .bg-danger-light {
            background-color: #f8d7da;
            color: #842029;
        }
        
        .superadmin-badge {
            background-color: #dc3545;
            color: #fff;
            padding: 2px 5px;
            border-radius: 4px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-left: 5px;
        }
        
        @media (max-width: 768px) {
            .superadmin-sidebar {
                margin-left: -250px;
            }
            .superadmin-sidebar.active {
                margin-left: 0;
            }
            .superadmin-content {
                margin-left: 0;
            }
            .superadmin-content.active {
                margin-left: 250px;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" class="superadmin-sidebar">
            <div class="sidebar-header">
                <h3>SUPERADMIN <span class="superadmin-badge">v1.0</span></h3>
            </div>
            
            <ul class="list-unstyled components">
                <li class="active">
                    <a href="index.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
                </li>
                <li>
                    <a href="empresas.php"><i class="fas fa-building me-2"></i> Empresas</a>
                </li>
                <li>
                    <a href="usuarios.php"><i class="fas fa-users me-2"></i> Usuários</a>
                </li>
                <li>
                    <a href="relatorios.php"><i class="fas fa-chart-bar me-2"></i> Relatórios</a>
                </li>
                <li>
                    <a href="configuracoes.php"><i class="fas fa-cogs me-2"></i> Configurações</a>
                </li>
                <li>
                    <a href="logs.php"><i class="fas fa-history me-2"></i> Logs do Sistema</a>
                </li>
                <li>
                    <a href="backup.php"><i class="fas fa-database me-2"></i> Backup</a>
                </li>
                <li>
                    <a href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a>
                </li>
            </ul>
        </nav>
        
        <!-- Page Content -->
        <div id="content" class="superadmin-content">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-dark superadmin-navbar">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <div class="ms-auto d-flex align-items-center">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle text-light" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-shield me-1"></i> Superadmin
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="perfil.php"><i class="fas fa-user-cog me-2"></i> Perfil</a></li>
                                <li><a class="dropdown-item" href="alterar_senha.php"><i class="fas fa-key me-2"></i> Alterar Senha</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            
            <h1 class="mb-4">Dashboard</h1>
            
            <!-- Stats Cards -->
            <div class="row">
                <div class="col-md-3">
                    <div class="card card-stats">
                        <div class="card-body bg-info-light">
                            <div class="row">
                                <div class="col-5">
                                    <div class="icon">
                                        <i class="fas fa-building"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="numbers">
                                        <p>Empresas</p>
                                        <h3><?php echo $totalEmpresas; ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer bg-light p-3">
                            <a href="empresas.php" class="text-info text-decoration-none">
                                <span class="me-1">Ver detalhes</span>
                                <i class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card card-stats">
                        <div class="card-body bg-success-light">
                            <div class="row">
                                <div class="col-5">
                                    <div class="icon">
                                        <i class="fas fa-users"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="numbers">
                                        <p>Usuários</p>
                                        <h3><?php echo $totalUsuarios; ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer bg-light p-3">
                            <a href="usuarios.php" class="text-success text-decoration-none">
                                <span class="me-1">Ver detalhes</span>
                                <i class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card card-stats">
                        <div class="card-body bg-warning-light">
                            <div class="row">
                                <div class="col-5">
                                    <div class="icon">
                                        <i class="fas fa-car"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="numbers">
                                        <p>Veículos</p>
                                        <h3><?php echo $totalVeiculos; ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer bg-light p-3">
                            <a href="relatorios.php?tipo=veiculos" class="text-warning text-decoration-none">
                                <span class="me-1">Ver detalhes</span>
                                <i class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-3">
                    <div class="card card-stats">
                        <div class="card-body bg-danger-light">
                            <div class="row">
                                <div class="col-5">
                                    <div class="icon">
                                        <i class="fas fa-dollar-sign"></i>
                                    </div>
                                </div>
                                <div class="col-7">
                                    <div class="numbers">
                                        <p>Faturamento</p>
                                        <h3><?php echo formatarMoeda($faturamentoTotal); ?></h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer bg-light p-3">
                            <a href="relatorios.php?tipo=faturamento" class="text-danger text-decoration-none">
                                <span class="me-1">Ver detalhes</span>
                                <i class="fas fa-arrow-circle-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Recent Companies -->
            <div class="row mt-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="card-title mb-0">Empresas Recentes</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
                                            <th>Data de Cadastro</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (count($empresasRecentes) > 0): ?>
                                            <?php foreach ($empresasRecentes as $empresa): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($empresa['nome']); ?></td>
                                                    <td><?php echo formatarData($empresa['data_cadastro']); ?></td>
                                                    <td>
                                                        <a href="empresas.php?acao=editar&id=<?php echo $empresa['id']; ?>" class="btn btn-sm btn-primary">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="3" class="text-center">Nenhuma empresa cadastrada.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <a href="empresas.php" class="btn btn-outline-primary btn-sm mt-3">Ver todas as empresas</a>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Logins -->
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="card-title mb-0">Últimos Acessos</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Usuário</th>
                                            <th>Empresa</th>
                                            <th>Data/Hora</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (count($ultimosAcessos) > 0): ?>
                                            <?php foreach ($ultimosAcessos as $acesso): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($acesso['usuario']); ?></td>
                                                    <td><?php echo htmlspecialchars($acesso['empresa']); ?></td>
                                                    <td><?php echo formatarData($acesso['ultimo_acesso'], true); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="3" class="text-center">Nenhum acesso registrado.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                            <a href="logs.php" class="btn btn-outline-primary btn-sm mt-3">Ver todos os logs</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- System Info -->
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="card-title mb-0">Informações do Sistema</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <p><strong>Versão do Sistema:</strong> 1.0</p>
                                    <p><strong>Versão do PHP:</strong> <?php echo phpversion(); ?></p>
                                    <p><strong>Servidor Web:</strong> <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Desconhecido'; ?></p>
                                </div>
                                <div class="col-md-4">
                                    <p><strong>Banco de Dados:</strong> MySQL</p>
                                    <p><strong>Total de Empresas:</strong> <?php echo $totalEmpresas; ?></p>
                                    <p><strong>Total de Usuários:</strong> <?php echo $totalUsuarios; ?></p>
                                </div>
                                <div class="col-md-4">
                                    <p><strong>Total de Veículos:</strong> <?php echo $totalVeiculos; ?></p>
                                    <p><strong>Total de Mensalistas:</strong> <?php echo $totalMensalistas; ?></p>
                                    <p><strong>Faturamento Total:</strong> <?php echo formatarMoeda($faturamentoTotal); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle sidebar
            document.getElementById('sidebarCollapse').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('active');
                document.getElementById('content').classList.toggle('active');
            });
        });
    </script>
</body>
</html>
