<?php
/**
 * Página de logout do superadmin
 */
session_start();

// Incluir arquivo de configuração
require_once 'config.php';

// Registrar ação no log
if (isset($_SESSION['superadmin_logged_in']) && $_SESSION['superadmin_logged_in'] === true) {
    logSuperadminAction('Logout', 'Logout realizado com sucesso');
}

// Destruir sessão
session_unset();
session_destroy();

// Redirecionar para a página de login
header('Location: login.php');
exit;
