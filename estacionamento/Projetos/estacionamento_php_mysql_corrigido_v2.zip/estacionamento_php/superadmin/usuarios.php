<?php
/**
 * Página de gestão de usuários do superadmin
 */
session_start();

// Incluir arquivo de configuração
require_once 'config.php';

// Verificar se está logado
requireSuperadminLogin();

// Incluir funções de banco de dados
require_once '../config/database.php';

// Inicializar variáveis
$mensagem = '';
$tipoMensagem = '';
$usuario = [
    'id' => '',
    'nome' => '',
    'email' => '',
    'login' => '',
    'senha' => '',
    'nivel' => 'operador',
    'empresa_id' => '',
    'ativo' => 1
];

// Filtro de empresa
$empresaFiltro = $_GET['empresa_id'] ?? '';

// Processar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? '';

// Processar exclusão
if ($acao === 'excluir' && !empty($id)) {
    try {
        $conn = getConnection();
        
        // Excluir usuário
        $query = "DELETE FROM usuarios WHERE id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        $mensagem = 'Usuário excluído com sucesso!';
        $tipoMensagem = 'success';
        
        // Registrar ação no log
        logSuperadminAction('Exclusão de usuário', "ID: $id");
    } catch (PDOException $e) {
        $mensagem = 'Erro ao excluir usuário. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
        logError('Erro ao excluir usuário', $e);
    }
}

// Carregar dados para edição
if ($acao === 'editar' && !empty($id)) {
    try {
        $conn = getConnection();
        
        $query = "SELECT u.*, e.nome as empresa_nome 
                  FROM usuarios u 
                  JOIN empresas e ON u.empresa_id = e.id 
                  WHERE u.id = :id";
        $stmt = $conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        $result = $stmt->fetch();
        
        if ($result) {
            $usuario = $result;
        } else {
            $mensagem = 'Usuário não encontrado.';
            $tipoMensagem = 'danger';
        }
    } catch (PDOException $e) {
        $mensagem = 'Erro ao carregar dados do usuário. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
        logError('Erro ao carregar usuário para edição', $e);
    }
}

// Processar formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifySuperadminCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $usuarioId = $_POST['id'] ?? '';
            $nome = $_POST['nome'] ?? '';
            $email = $_POST['email'] ?? '';
            $login = $_POST['login'] ?? '';
            $senha = $_POST['senha'] ?? '';
            $nivel = $_POST['nivel'] ?? '';
            $empresaId = $_POST['empresa_id'] ?? '';
            $ativo = isset($_POST['ativo']) ? 1 : 0;
            
            // Validar dados
            if (empty($nome) || empty($login) || empty($nivel) || empty($empresaId)) {
                $mensagem = 'Por favor, preencha todos os campos obrigatórios.';
                $tipoMensagem = 'danger';
                
                // Manter dados do formulário
                $usuario = [
                    'id' => $usuarioId,
                    'nome' => $nome,
                    'email' => $email,
                    'login' => $login,
                    'senha' => '',
                    'nivel' => $nivel,
                    'empresa_id' => $empresaId,
                    'ativo' => $ativo
                ];
            } else {
                // Verificar se o login já existe
                $queryVerificar = "SELECT id FROM usuarios WHERE login = :login AND id != :id";
                $stmtVerificar = $conn->prepare($queryVerificar);
                $stmtVerificar->bindParam(':login', $login);
                $stmtVerificar->bindParam(':id', $usuarioId);
                $stmtVerificar->execute();
                
                if ($stmtVerificar->rowCount() > 0) {
                    $mensagem = 'Este login já está em uso. Por favor, escolha outro.';
                    $tipoMensagem = 'danger';
                    
                    // Manter dados do formulário
                    $usuario = [
                        'id' => $usuarioId,
                        'nome' => $nome,
                        'email' => $email,
                        'login' => $login,
                        'senha' => '',
                        'nivel' => $nivel,
                        'empresa_id' => $empresaId,
                        'ativo' => $ativo
                    ];
                } else {
                    if (empty($usuarioId)) {
                        // Inserir novo usuário
                        if (empty($senha)) {
                            $mensagem = 'Por favor, informe uma senha para o novo usuário.';
                            $tipoMensagem = 'danger';
                            
                            // Manter dados do formulário
                            $usuario = [
                                'id' => $usuarioId,
                                'nome' => $nome,
                                'email' => $email,
                                'login' => $login,
                                'senha' => '',
                                'nivel' => $nivel,
                                'empresa_id' => $empresaId,
                                'ativo' => $ativo
                            ];
                        } else {
                            // Criptografar senha
                            $senhaCriptografada = password_hash($senha, PASSWORD_DEFAULT);
                            
                            $query = "INSERT INTO usuarios (nome, email, login, senha, nivel, empresa_id, ativo, data_cadastro) 
                                      VALUES (:nome, :email, :login, :senha, :nivel, :empresa_id, :ativo, NOW())";
                            $stmt = $conn->prepare($query);
                            $stmt->bindParam(':nome', $nome);
                            $stmt->bindParam(':email', $email);
                            $stmt->bindParam(':login', $login);
                            $stmt->bindParam(':senha', $senhaCriptografada);
                            $stmt->bindParam(':nivel', $nivel);
                            $stmt->bindParam(':empresa_id', $empresaId);
                            $stmt->bindParam(':ativo', $ativo);
                            $stmt->execute();
                            
                            $mensagem = 'Usuário cadastrado com sucesso!';
                            $tipoMensagem = 'success';
                            
                            // Registrar ação no log
                            logSuperadminAction('Cadastro de usuário', "Nome: $nome, Login: $login, Empresa: $empresaId");
                            
                            // Limpar formulário após sucesso
                            $usuario = [
                                'id' => '',
                                'nome' => '',
                                'email' => '',
                                'login' => '',
                                'senha' => '',
                                'nivel' => 'operador',
                                'empresa_id' => $empresaId, // Manter empresa selecionada
                                'ativo' => 1
                            ];
                        }
                    } else {
                        // Atualizar usuário existente
                        if (!empty($senha)) {
                            // Criptografar nova senha
                            $senhaCriptografada = password_hash($senha, PASSWORD_DEFAULT);
                            
                            $query = "UPDATE usuarios 
                                      SET nome = :nome, 
                                          email = :email, 
                                          login = :login, 
                                          senha = :senha, 
                                          nivel = :nivel, 
                                          empresa_id = :empresa_id, 
                                          ativo = :ativo 
                                      WHERE id = :id";
                            $stmt = $conn->prepare($query);
                            $stmt->bindParam(':senha', $senhaCriptografada);
                        } else {
                            // Manter senha atual
                            $query = "UPDATE usuarios 
                                      SET nome = :nome, 
                                          email = :email, 
                                          login = :login, 
                                          nivel = :nivel, 
                                          empresa_id = :empresa_id, 
                                          ativo = :ativo 
                                      WHERE id = :id";
                            $stmt = $conn->prepare($query);
                        }
                        
                        $stmt->bindParam(':nome', $nome);
                        $stmt->bindParam(':email', $email);
                        $stmt->bindParam(':login', $login);
                        $stmt->bindParam(':nivel', $nivel);
                        $stmt->bindParam(':empresa_id', $empresaId);
                        $stmt->bindParam(':ativo', $ativo);
                        $stmt->bindParam(':id', $usuarioId);
                        $stmt->execute();
                        
                        $mensagem = 'Usuário atualizado com sucesso!';
                        $tipoMensagem = 'success';
                        
                        // Registrar ação no log
                        logSuperadminAction('Atualização de usuário', "ID: $usuarioId, Nome: $nome");
                        
                        // Limpar formulário após sucesso
                        $usuario = [
                            'id' => '',
                            'nome' => '',
                            'email' => '',
                            'login' => '',
                            'senha' => '',
                            'nivel' => 'operador',
                            'empresa_id' => $empresaId, // Manter empresa selecionada
                            'ativo' => 1
                        ];
                    }
                }
            }
        } catch (PDOException $e) {
            $mensagem = 'Erro ao salvar usuário. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
            logError('Erro ao salvar usuário', $e);
        }
    }
}

// Obter lista de empresas
try {
    $conn = getConnection();
    
    $query = "SELECT id, nome FROM empresas WHERE ativo = 1 ORDER BY nome";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $empresas = $stmt->fetchAll();
} catch (PDOException $e) {
    $empresas = [];
    logError('Erro ao obter lista de empresas', $e);
}

// Obter lista de usuários
try {
    $conn = getConnection();
    
    $params = [];
    $whereClause = "";
    
    if (!empty($empresaFiltro)) {
        $whereClause = "WHERE u.empresa_id = :empresa_id";
        $params[':empresa_id'] = $empresaFiltro;
    }
    
    $query = "SELECT u.*, e.nome as empresa_nome 
              FROM usuarios u 
              JOIN empresas e ON u.empresa_id = e.id 
              $whereClause
              ORDER BY e.nome, u.nome";
    $stmt = $conn->prepare($query);
    
    foreach ($params as $param => $value) {
        $stmt->bindValue($param, $value);
    }
    
    $stmt->execute();
    $usuarios = $stmt->fetchAll();
} catch (PDOException $e) {
    $usuarios = [];
    logError('Erro ao obter lista de usuários', $e);
}

// Função para formatar data
function formatarData($data, $incluirHora = false) {
    if (!$data) {
        return '-';
    }
    
    $date = new DateTime($data);
    
    if ($incluirHora) {
        return $date->format('d/m/Y H:i:s');
    }
    
    return $date->format('d/m/Y');
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Usuários - Superadmin</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        
        .superadmin-navbar {
            background-color: #212529;
            padding: 15px 10px;
        }
        
        .superadmin-sidebar {
            min-width: 250px;
            max-width: 250px;
            background: #343a40;
            color: #fff;
            transition: all 0.3s;
            height: 100vh;
            position: fixed;
            z-index: 999;
        }
        
        .superadmin-sidebar .sidebar-header {
            padding: 20px;
            background: #212529;
        }
        
        .superadmin-sidebar ul.components {
            padding: 20px 0;
            border-bottom: 1px solid #4b545c;
        }
        
        .superadmin-sidebar ul p {
            color: #fff;
            padding: 10px;
        }
        
        .superadmin-sidebar ul li a {
            padding: 10px;
            font-size: 1.1em;
            display: block;
            color: #fff;
            text-decoration: none;
        }
        
        .superadmin-sidebar ul li a:hover {
            color: #fff;
            background: #495057;
        }
        
        .superadmin-sidebar ul li.active > a {
            color: #fff;
            background: #dc3545;
        }
        
        .superadmin-content {
            width: 100%;
            padding: 20px;
            min-height: 100vh;
            transition: all 0.3s;
            margin-left: 250px;
        }
        
        .superadmin-content.active {
            margin-left: 0;
        }
        
        .superadmin-badge {
            background-color: #dc3545;
            color: #fff;
            padding: 2px 5px;
            border-radius: 4px;
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-left: 5px;
        }
        
        @media (max-width: 768px) {
            .superadmin-sidebar {
                margin-left: -250px;
            }
            .superadmin-sidebar.active {
                margin-left: 0;
            }
            .superadmin-content {
                margin-left: 0;
            }
            .superadmin-content.active {
                margin-left: 250px;
            }
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" class="superadmin-sidebar">
            <div class="sidebar-header">
                <h3>SUPERADMIN <span class="superadmin-badge">v1.0</span></h3>
            </div>
            
            <ul class="list-unstyled components">
                <li>
                    <a href="index.php"><i class="fas fa-tachometer-alt me-2"></i> Dashboard</a>
                </li>
                <li>
                    <a href="empresas.php"><i class="fas fa-building me-2"></i> Empresas</a>
                </li>
                <li class="active">
                    <a href="usuarios.php"><i class="fas fa-users me-2"></i> Usuários</a>
                </li>
                <li>
                    <a href="relatorios.php"><i class="fas fa-chart-bar me-2"></i> Relatórios</a>
                </li>
                <li>
                    <a href="configuracoes.php"><i class="fas fa-cogs me-2"></i> Configurações</a>
                </li>
                <li>
                    <a href="logs.php"><i class="fas fa-history me-2"></i> Logs do Sistema</a>
                </li>
                <li>
                    <a href="backup.php"><i class="fas fa-database me-2"></i> Backup</a>
                </li>
                <li>
                    <a href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a>
                </li>
            </ul>
        </nav>
        
        <!-- Page Content -->
        <div id="content" class="superadmin-content">
            <!-- Navbar -->
            <nav class="navbar navbar-expand-lg navbar-dark superadmin-navbar">
                <div class="container-fluid">
                    <button type="button" id="sidebarCollapse" class="btn btn-dark">
                        <i class="fas fa-bars"></i>
                    </button>
                    
                    <div class="ms-auto d-flex align-items-center">
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle text-light" href="#" role="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user-shield me-1"></i> Superadmin
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="perfil.php"><i class="fas fa-user-cog me-2"></i> Perfil</a></li>
                                <li><a class="dropdown-item" href="alterar_senha.php"><i class="fas fa-key me-2"></i> Alterar Senha</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt me-2"></i> Sair</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </nav>
            
            <h1 class="mb-4">Gestão de Usuários</h1>
            
            <?php if (!empty($mensagem)): ?>
                <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
                    <?php echo $mensagem; ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
                </div>
            <?php endif; ?>
            
            <!-- Filtro de Empresa -->
            <div class="card mb-4">
                <div class="card-header bg-light">
                    <h5 class="card-title mb-0">Filtrar por Empresa</h5>
                </div>
                <div class="card-body">
                    <form method="GET" action="usuarios.php" class="row g-3">
                        <div class="col-md-6">
                            <select name="empresa_id" class="form-control">
                                <option value="">Todas as Empresas</option>
                                <?php foreach ($empresas as $emp): ?>
                                    <option value="<?php echo $emp['id']; ?>" <?php echo $empresaFiltro == $emp['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($emp['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <button type="submit" class="btn btn-primary">Filtrar</button>
                            <a href="usuarios.php" class="btn btn-secondary">Limpar Filtro</a>
                        </div>
                    </form>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="card-title mb-0"><?php echo empty($usuario['id']) ? 'Novo Usuário' : 'Editar Usuário'; ?></h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="usuarios.php<?php echo !empty($empresaFiltro) ? '?empresa_id=' . $empresaFiltro : ''; ?>">
                                <input type="hidden" name="csrf_token" value="<?php echo generateSuperadminCsrfToken(); ?>">
                                <input type="hidden" name="id" value="<?php echo htmlspecialchars($usuario['id']); ?>">
                                
                                <div class="mb-3">
                                    <label for="empresa_id" class="form-label">Empresa*</label>
                                    <select class="form-control" id="empresa_id" name="empresa_id" required>
                                        <option value="">Selecione uma empresa</option>
                                        <?php foreach ($empresas as $emp): ?>
                                            <option value="<?php echo $emp['id']; ?>" <?php echo $usuario['empresa_id'] == $emp['id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($emp['nome']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="nome" class="form-label">Nome*</label>
                                    <input type="text" class="form-control" id="nome" name="nome" value="<?php echo htmlspecialchars($usuario['nome']); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="email" class="form-label">E-mail</label>
                                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($usuario['email']); ?>">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="login" class="form-label">Login*</label>
                                    <input type="text" class="form-control" id="login" name="login" value="<?php echo htmlspecialchars($usuario['login']); ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="senha" class="form-label"><?php echo empty($usuario['id']) ? 'Senha*' : 'Nova Senha (deixe em branco para manter a atual)'; ?></label>
                                    <input type="password" class="form-control" id="senha" name="senha" <?php echo empty($usuario['id']) ? 'required' : ''; ?>>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="nivel" class="form-label">Nível de Acesso*</label>
                                    <select class="form-control" id="nivel" name="nivel" required>
                                        <option value="operador" <?php echo $usuario['nivel'] === 'operador' ? 'selected' : ''; ?>>Operador</option>
                                        <option value="admin" <?php echo $usuario['nivel'] === 'admin' ? 'selected' : ''; ?>>Administrador</option>
                                    </select>
                                </div>
                                
                                <div class="mb-3 form-check">
                                    <input type="checkbox" class="form-check-input" id="ativo" name="ativo" <?php echo $usuario['ativo'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="ativo">Usuário Ativo</label>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-primary">Salvar</button>
                                    <?php if (!empty($usuario['id'])): ?>
                                        <a href="usuarios.php<?php echo !empty($empresaFiltro) ? '?empresa_id=' . $empresaFiltro : ''; ?>" class="btn btn-secondary">Cancelar</a>
                                    <?php endif; ?>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header bg-light">
                            <h5 class="card-title mb-0">Lista de Usuários</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>Nome</th>
                                            <th>Login</th>
                                            <th>Empresa</th>
                                            <th>Nível</th>
                                            <th>Status</th>
                                            <th>Último Acesso</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (count($usuarios) > 0): ?>
                                            <?php foreach ($usuarios as $user): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($user['nome']); ?></td>
                                                    <td><?php echo htmlspecialchars($user['login']); ?></td>
                                                    <td><?php echo htmlspecialchars($user['empresa_nome']); ?></td>
                                                    <td>
                                                        <?php if ($user['nivel'] === 'admin'): ?>
                                                            <span class="badge bg-danger">Administrador</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-primary">Operador</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if ($user['ativo']): ?>
                                                            <span class="badge bg-success">Ativo</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-danger">Inativo</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo $user['ultimo_acesso'] ? formatarData($user['ultimo_acesso'], true) : 'Nunca acessou'; ?></td>
                                                    <td>
                                                        <div class="btn-group">
                                                            <a href="usuarios.php?acao=editar&id=<?php echo $user['id']; ?><?php echo !empty($empresaFiltro) ? '&empresa_id=' . $empresaFiltro : ''; ?>" class="btn btn-sm btn-primary" title="Editar">
                                                                <i class="fas fa-edit"></i>
                                                            </a>
                                                            <a href="usuarios.php?acao=excluir&id=<?php echo $user['id']; ?><?php echo !empty($empresaFiltro) ? '&empresa_id=' . $empresaFiltro : ''; ?>" class="btn btn-sm btn-danger" title="Excluir" onclick="return confirm('Tem certeza que deseja excluir este usuário?')">
                                                                <i class="fas fa-trash"></i>
                                                            </a>
                                                            <a href="usuarios.php?acao=resetar_senha&id=<?php echo $user['id']; ?><?php echo !empty($empresaFiltro) ? '&empresa_id=' . $empresaFiltro : ''; ?>" class="btn btn-sm btn-warning" title="Resetar Senha" onclick="return confirm('Tem certeza que deseja resetar a senha deste usuário?')">
                                                                <i class="fas fa-key"></i>
                                                            </a>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="7" class="text-center">Nenhum usuário encontrado.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Toggle sidebar
            document.getElementById('sidebarCollapse').addEventListener('click', function() {
                document.getElementById('sidebar').classList.toggle('active');
                document.getElementById('content').classList.toggle('active');
            });
        });
    </script>
</body>
</html>
