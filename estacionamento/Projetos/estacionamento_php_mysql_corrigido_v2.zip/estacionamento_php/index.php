<?php
/**
 * Página inicial do sistema - Consulta de tickets
 */
require_once 'init.php';

// Inicializar variáveis
$mensagem = '';
$tipoMensagem = '';
$ticket = null;

// Processar consulta de ticket
if (isPostRequest() && isset($_POST['consultar_ticket'])) {
    // Verificar CSRF token
    if (!isset($_POST['csrf_token']) || !verifyCsrfToken($_POST['csrf_token'])) {
        $mensagem = 'Erro de segurança. Por favor, tente novamente.';
        $tipoMensagem = 'danger';
    } else {
        try {
            $conn = getConnection();
            
            // Obter dados do formulário
            $ticketNumero = $_POST['ticket_numero'] ?? '';
            $placa = $_POST['placa'] ?? '';
            
            // Validar dados
            if (empty($ticketNumero) && empty($placa)) {
                $mensagem = 'Por favor, informe o número do ticket ou a placa do veículo.';
                $tipoMensagem = 'danger';
            } else {
                // Consultar ticket
                if (!empty($ticketNumero)) {
                    $query = "SELECT v.*, e.nome as empresa_nome, e.endereco as empresa_endereco, e.telefone as empresa_telefone 
                              FROM veiculos v 
                              JOIN empresas e ON v.empresa_id = e.id 
                              WHERE v.ticket = :ticket";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':ticket', $ticketNumero);
                } else {
                    $query = "SELECT v.*, e.nome as empresa_nome, e.endereco as empresa_endereco, e.telefone as empresa_telefone 
                              FROM veiculos v 
                              JOIN empresas e ON v.empresa_id = e.id 
                              WHERE v.placa = :placa 
                              ORDER BY v.entrada DESC 
                              LIMIT 1";
                    $stmt = $conn->prepare($query);
                    $stmt->bindParam(':placa', $placa);
                }
                
                $stmt->execute();
                $ticket = $stmt->fetch();
                
                if (!$ticket) {
                    $mensagem = 'Ticket não encontrado. Verifique o número informado ou a placa do veículo.';
                    $tipoMensagem = 'danger';
                }
            }
        } catch (PDOException $e) {
            logError('Erro ao consultar ticket', $e);
            $mensagem = 'Erro ao consultar ticket. Por favor, tente novamente.';
            $tipoMensagem = 'danger';
        }
    }
}

// Obter lista de empresas para o seletor
try {
    $conn = getConnection();
    
    $query = "SELECT id, nome FROM empresas WHERE ativo = 1 ORDER BY nome";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $empresas = $stmt->fetchAll();
} catch (PDOException $e) {
    logError('Erro ao obter lista de empresas', $e);
    $empresas = [];
}

// Definir título da página
$tituloPagina = 'Sistema de Estacionamento - Consulta de Ticket';
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $tituloPagina; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    
    <!-- Estilos personalizados -->
    <link href="css/style.php" rel="stylesheet">
    <link href="css/components.php" rel="stylesheet">
    
    <style>
        body {
            background-color: #f8f9fa;
        }
        
        .ticket-container {
            max-width: 800px;
            margin: 50px auto;
        }
        
        .logo-container {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .logo-container img {
            max-width: 200px;
            height: auto;
        }
        
        .ticket-form {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
            margin-bottom: 30px;
        }
        
        .ticket-result {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }
        
        .ticket-header {
            border-bottom: 1px solid #eee;
            margin-bottom: 20px;
            padding-bottom: 20px;
        }
        
        .ticket-info {
            margin-bottom: 20px;
        }
        
        .ticket-footer {
            border-top: 1px solid #eee;
            margin-top: 20px;
            padding-top: 20px;
            text-align: center;
        }
        
        .login-link {
            text-align: center;
            margin-top: 20px;
        }
        
        @media print {
            .no-print {
                display: none;
            }
            
            .ticket-result {
                box-shadow: none;
                border: 1px solid #ddd;
            }
        }
    </style>
</head>
<body>
    <div class="container ticket-container">
        <div class="logo-container">
            <img src="img/logo.png" alt="Logo Sistema de Estacionamento" onerror="this.src='img/logo-default.png'">
        </div>
        
        <?php if (!empty($mensagem)): ?>
            <div class="alert alert-<?php echo $tipoMensagem; ?> alert-dismissible fade show" role="alert">
                <?php echo $mensagem; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
            </div>
        <?php endif; ?>
        
        <div class="ticket-form no-print">
            <h2 class="text-center mb-4">Consulta de Ticket</h2>
            
            <form method="POST" action="index.php">
                <input type="hidden" name="csrf_token" value="<?php echo generateCsrfToken(); ?>">
                <input type="hidden" name="consultar_ticket" value="1">
                
                <?php if (count($empresas) > 1): ?>
                    <div class="form-group mb-3">
                        <label for="empresa_id">Selecione a Empresa</label>
                        <select id="empresa_id" name="empresa_id" class="form-control">
                            <?php foreach ($empresas as $empresa): ?>
                                <option value="<?php echo $empresa['id']; ?>"><?php echo sanitizeOutput($empresa['nome']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endif; ?>
                
                <div class="form-group mb-3">
                    <label for="ticket_numero">Número do Ticket</label>
                    <input type="text" id="ticket_numero" name="ticket_numero" class="form-control" placeholder="Digite o número do ticket">
                </div>
                
                <div class="text-center mb-3">
                    <span>ou</span>
                </div>
                
                <div class="form-group mb-3">
                    <label for="placa">Placa do Veículo</label>
                    <input type="text" id="placa" name="placa" class="form-control" placeholder="Digite a placa do veículo">
                </div>
                
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">Consultar</button>
                </div>
            </form>
            
            <div class="login-link mt-4">
                <a href="login.php">Acesso Administrativo</a>
            </div>
        </div>
        
        <?php if ($ticket): ?>
            <div class="ticket-result" id="ticket-result">
                <div class="ticket-header">
                    <div class="row">
                        <div class="col-md-8">
                            <h3><?php echo sanitizeOutput($ticket['empresa_nome']); ?></h3>
                            <p><?php echo sanitizeOutput($ticket['empresa_endereco']); ?></p>
                            <p>Telefone: <?php echo sanitizeOutput($ticket['empresa_telefone']); ?></p>
                        </div>
                        <div class="col-md-4 text-end">
                            <h4>Ticket #<?php echo sanitizeOutput($ticket['ticket']); ?></h4>
                        </div>
                    </div>
                </div>
                
                <div class="ticket-info">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>Placa:</strong> <?php echo sanitizeOutput($ticket['placa']); ?></p>
                            <p><strong>Modelo:</strong> <?php echo sanitizeOutput($ticket['modelo']); ?></p>
                            <p><strong>Cor:</strong> <?php echo sanitizeOutput($ticket['cor']); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Entrada:</strong> <?php echo formatarData($ticket['entrada'], true); ?></p>
                            <?php if ($ticket['saida']): ?>
                                <p><strong>Saída:</strong> <?php echo formatarData($ticket['saida'], true); ?></p>
                                <p><strong>Permanência:</strong> <?php echo calcularDiferencaHoras($ticket['entrada'], $ticket['saida']); ?></p>
                            <?php else: ?>
                                <p><strong>Permanência até agora:</strong> <?php echo calcularDiferencaHoras($ticket['entrada'], null); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <?php if ($ticket['saida']): ?>
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <div class="alert alert-info">
                                    <h5 class="mb-0">Veículo já retirado</h5>
                                    <p class="mb-0">Este veículo já foi retirado do estacionamento.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <p><strong>Valor:</strong> <?php echo formatarMoeda($ticket['valor_total']); ?></p>
                            </div>
                            <div class="col-md-6">
                                <p><strong>Forma de Pagamento:</strong> <?php echo sanitizeOutput($ticket['forma_pagamento']); ?></p>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <div class="alert alert-success">
                                    <h5 class="mb-0">Veículo no estacionamento</h5>
                                    <p class="mb-0">Este veículo encontra-se no estacionamento.</p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="ticket-footer">
                    <p class="mb-0">Obrigado por utilizar nossos serviços!</p>
                </div>
                
                <div class="d-grid gap-2 mt-4 no-print">
                    <button type="button" class="btn btn-secondary" onclick="window.print()">Imprimir</button>
                    <button type="button" class="btn btn-primary" onclick="window.location.href='index.php'">Nova Consulta</button>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Scripts personalizados -->
    <script src="js/main.php"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Máscara para placa
            const placaInput = document.getElementById('placa');
            if (placaInput) {
                placaInput.addEventListener('input', function(e) {
                    let value = e.target.value.toUpperCase();
                    e.target.value = value;
                });
            }
            
            // Máscara para ticket
            const ticketInput = document.getElementById('ticket_numero');
            if (ticketInput) {
                ticketInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    e.target.value = value;
                });
            }
        });
    </script>
</body>
</html>
