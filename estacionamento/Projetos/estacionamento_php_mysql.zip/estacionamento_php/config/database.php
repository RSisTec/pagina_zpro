<?php
/**
 * Configuração de conexão com o banco de dados MySQL
 * 
 * Este arquivo contém as configurações necessárias para conectar ao banco de dados MySQL
 */

// Configurações do banco de dados
$db_config = [
    'host' => 'localhost',
    'port' => '3306',
    'database' => 'estacionamento_db',
    'username' => 'root',
    'password' => 'root',
    'charset' => 'utf8mb4'
];

/**
 * Função para obter conexão com o banco de dados
 * 
 * @return PDO Conexão com o banco de dados
 */
function getConnection() {
    global $db_config;
    
    $dsn = "mysql:host={$db_config['host']};port={$db_config['port']};dbname={$db_config['database']};charset={$db_config['charset']}";
    
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    
    try {
        $pdo = new PDO(
            $dsn,
            $db_config['username'],
            $db_config['password'],
            $options
        );
        return $pdo;
    } catch (PDOException $e) {
        // Em ambiente de produção, não exibir detalhes do erro
        die("Erro de conexão com o banco de dados. Por favor, contate o administrador.");
    }
}
