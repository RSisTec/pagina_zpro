// Arquivo para requisições à API externa
// Contém funções para comunicação com o backend via API REST

// Importar configurações
// Certifique-se de incluir o arquivo config.js antes deste arquivo em todas as páginas HTML

// Namespace para APIs
const api = {
    // Função auxiliar para fazer requisições à API
    _request: async function(endpoint, method = 'GET', data = null, headers = {}) {
        try {
            // Verificar se a configuração está disponível
            if (!config || !config.apiBaseUrl) {
                throw new Error('Configuração da API não encontrada');
            }
            
            // Construir URL completa
            const url = `${config.apiBaseUrl}/${endpoint}`;
            
            // Configurar headers padrão
            const defaultHeaders = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            };
            
            // Obter token de autenticação se disponível
            const session = JSON.parse(localStorage.getItem('session') || 'null');
            if (session && session.token) {
                defaultHeaders['Authorization'] = `Bearer ${session.token}`;
            }
            
            // Mesclar headers
            const requestHeaders = { ...defaultHeaders, ...headers };
            
            // Configurar requisição
            const requestOptions = {
                method,
                headers: requestHeaders,
                timeout: config.requestTimeout || 30000
            };
            
            // Adicionar corpo da requisição se necessário
            if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
                requestOptions.body = JSON.stringify(data);
            }
            
            // Log de requisição se habilitado
            if (config.enableRequestLogs) {
                console.log(`API Request: ${method} ${url}`, data);
            }
            
            // Fazer requisição
            const response = await fetch(url, requestOptions);
            
            // Verificar status da resposta
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw {
                    status: response.status,
                    statusText: response.statusText,
                    data: errorData
                };
            }
            
            // Processar resposta
            const responseData = await response.json();
            
            // Log de resposta se habilitado
            if (config.enableRequestLogs) {
                console.log(`API Response: ${method} ${url}`, responseData);
            }
            
            return responseData;
        } catch (error) {
            // Log de erro
            console.error('API Error:', error);
            
            // Rejeitar promessa com erro formatado
            throw {
                mensagem: error.data?.mensagem || error.message || 'Erro na comunicação com o servidor',
                status: error.status || 0,
                original: error
            };
        }
    },
    
    // Autenticar usuário
    autenticar: function(login, senha) {
        return this._request('auth/login', 'POST', { login, senha });
    },
    
    // Consultar veículo por placa
    consultarPlaca: function(placa) {
        return this._request(`veiculos/placa/${placa}`, 'GET');
    },
    
    // Adicionar veículo ao pátio
    adicionarVeiculo: function(veiculo) {
        return this._request('veiculos', 'POST', veiculo);
    },
    
    // Listar veículos no pátio
    listarVeiculosNoPatio: function() {
        return this._request('veiculos/patio', 'GET');
    },
    
    // Buscar veículo por ticket
    buscarVeiculoPorTicket: function(ticket) {
        return this._request(`veiculos/ticket/${ticket}`, 'GET');
    },
    
    // Registrar saída de veículo
    registrarSaida: function(ticket, formaPagamento, cpfNota) {
        return this._request(`veiculos/saida/${ticket}`, 'POST', { formaPagamento, cpfNota });
    },
    
    // Listar mensalistas
    listarMensalistas: function() {
        return this._request('mensalistas', 'GET');
    },
    
    // Cadastrar mensalista
    cadastrarMensalista: function(mensalista) {
        return this._request('mensalistas', 'POST', mensalista);
    },
    
    // Atualizar mensalista
    atualizarMensalista: function(id, mensalista) {
        return this._request(`mensalistas/${id}`, 'PUT', mensalista);
    },
    
    // Excluir mensalista
    excluirMensalista: function(id) {
        return this._request(`mensalistas/${id}`, 'DELETE');
    },
    
    // Listar isentos
    listarIsentos: function() {
        return this._request('isentos', 'GET');
    },
    
    // Cadastrar isento
    cadastrarIsento: function(isento) {
        return this._request('isentos', 'POST', isento);
    },
    
    // Atualizar isento
    atualizarIsento: function(id, isento) {
        return this._request(`isentos/${id}`, 'PUT', isento);
    },
    
    // Excluir isento
    excluirIsento: function(id) {
        return this._request(`isentos/${id}`, 'DELETE');
    },
    
    // Listar serviços
    listarServicos: function() {
        return this._request('servicos', 'GET');
    },
    
    // Cadastrar serviço
    cadastrarServico: function(servico) {
        return this._request('servicos', 'POST', servico);
    },
    
    // Atualizar serviço
    atualizarServico: function(id, servico) {
        return this._request(`servicos/${id}`, 'PUT', servico);
    },
    
    // Excluir serviço
    excluirServico: function(id) {
        return this._request(`servicos/${id}`, 'DELETE');
    },
    
    // Adicionar serviço ao veículo
    adicionarServicoAoVeiculo: function(ticket, servico) {
        return this._request(`veiculos/${ticket}/servicos`, 'POST', servico);
    },
    
    // Listar preços
    listarPrecos: function() {
        return this._request('precos', 'GET');
    },
    
    // Cadastrar preço
    cadastrarPreco: function(preco) {
        return this._request('precos', 'POST', preco);
    },
    
    // Atualizar preço
    atualizarPreco: function(id, preco) {
        return this._request(`precos/${id}`, 'PUT', preco);
    },
    
    // Excluir preço
    excluirPreco: function(id) {
        return this._request(`precos/${id}`, 'DELETE');
    },
    
    // Ativar preço
    ativarPreco: function(id) {
        return this._request(`precos/${id}/ativar`, 'POST');
    },
    
    // Listar usuários
    listarUsuarios: function() {
        return this._request('usuarios', 'GET');
    },
    
    // Cadastrar usuário
    cadastrarUsuario: function(usuario) {
        return this._request('usuarios', 'POST', usuario);
    },
    
    // Atualizar usuário
    atualizarUsuario: function(id, usuario) {
        return this._request(`usuarios/${id}`, 'PUT', usuario);
    },
    
    // Excluir usuário
    excluirUsuario: function(id) {
        return this._request(`usuarios/${id}`, 'DELETE');
    },
    
    // Gerar relatório de veículos
    gerarRelatorioVeiculos: function(filtros) {
        return this._request('relatorios/veiculos', 'POST', filtros);
    },
    
    // Gerar relatório de faturamento
    gerarRelatorioFaturamento: function(filtros) {
        return this._request('relatorios/faturamento', 'POST', filtros);
    }
};
