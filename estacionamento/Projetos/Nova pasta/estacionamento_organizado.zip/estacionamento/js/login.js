// Script para a página de login
document.addEventListener('DOMContentLoaded', function() {
    // Placeholder para o logo
    const logoPlaceholder = document.getElementById('logo-placeholder');
    logoPlaceholder.onerror = function() {
        this.src = 'https://via.placeholder.com/150x50?text=EstacionaFacil';
    };
    
    const loginLogoPlaceholder = document.getElementById('login-logo-placeholder');
    loginLogoPlaceholder.onerror = function() {
        this.src = 'https://via.placeholder.com/150x50?text=EstacionaFacil';
    };
    
    // Toggle do menu mobile
    const navToggle = document.getElementById('nav-toggle');
    const navList = document.getElementById('nav-list');
    
    navToggle.addEventListener('click', function() {
        navList.classList.toggle('active');
    });
    
    // Formulário de login
    const loginForm = document.getElementById('login-form');
    const loginError = document.getElementById('login-error');
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const usuario = document.getElementById('usuario').value;
        const senha = document.getElementById('senha').value;
        
        if (!usuario || !senha) {
            showNotification('Por favor, preencha todos os campos', 'error');
            return;
        }
        
        // Verificar se é o primeiro acesso (usuário admin/admin)
        if (usuario === 'admin' && senha === 'admin') {
            // Salvar usuário no localStorage
            const adminUser = {
                id: '1',
                nome: 'Administrador',
                usuario: 'admin',
                senha: 'admin', // Em produção, isso seria um hash
                nivel: 'admin',
                ativo: true
            };
            
            // Inicializar o localStorage se for o primeiro acesso
            if (!localStorage.getItem('usuarios')) {
                localStorage.setItem('usuarios', JSON.stringify([adminUser]));
            }
            
            // Salvar sessão
            const session = {
                userId: '1',
                nome: 'Administrador',
                nivel: 'admin',
                expiresAt: new Date().getTime() + (8 * 60 * 60 * 1000) // 8 horas
            };
            
            localStorage.setItem('session', JSON.stringify(session));
            
            // Redirecionar para o dashboard
            window.location.href = 'admin.html';
            return;
        }
        
        // Verificar usuários cadastrados
        const usuarios = JSON.parse(localStorage.getItem('usuarios') || '[]');
        const usuarioEncontrado = usuarios.find(u => u.usuario === usuario && u.senha === senha && u.ativo);
        
        if (usuarioEncontrado) {
            // Salvar sessão
            const session = {
                userId: usuarioEncontrado.id,
                nome: usuarioEncontrado.nome,
                nivel: usuarioEncontrado.nivel,
                expiresAt: new Date().getTime() + (8 * 60 * 60 * 1000) // 8 horas
            };
            
            localStorage.setItem('session', JSON.stringify(session));
            
            // Redirecionar para o dashboard
            window.location.href = 'admin.html';
        } else {
            loginError.style.display = 'block';
            setTimeout(() => {
                loginError.style.display = 'none';
            }, 3000);
        }
    });
    
    // Notificações
    const notification = document.getElementById('notification');
    const closeNotification = document.getElementById('close-notification');
    const notificationMessage = document.getElementById('notification-message');
    
    function showNotification(message, type = 'info') {
        notificationMessage.textContent = message;
        notification.className = 'notification notification-' + type + ' show';
        
        setTimeout(function() {
            hideNotification();
        }, 5000);
    }
    
    function hideNotification() {
        notification.classList.remove('show');
    }
    
    closeNotification.addEventListener('click', hideNotification);
});
