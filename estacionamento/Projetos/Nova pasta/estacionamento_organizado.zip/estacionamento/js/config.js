// Arquivo de configuração da API
// Contém a URL base para todas as requisições à API externa

const config = {
    // URL base da API externa
    // Esta URL será usada como prefixo para todas as requisições
    apiBaseUrl: 'https://api.estacionamento.com.br/v1',
    
    // Timeout padrão para requisições (em milissegundos)
    requestTimeout: 30000,
    
    // Versão da API
    apiVersion: 'v1',
    
    // Habilitar logs de requisições
    enableRequestLogs: true,
    
    // Configurações de retry para falhas de conexão
    retry: {
        maxRetries: 3,
        retryDelay: 1000,
        retryStatusCodes: [408, 429, 500, 502, 503, 504]
    }
};
