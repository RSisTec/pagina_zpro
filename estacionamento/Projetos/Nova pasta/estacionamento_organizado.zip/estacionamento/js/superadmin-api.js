// Arquivo para APIs específicas do superadmin
// Contém funções para gerenciamento de empresas e superadmin

// Importar configurações
// Certifique-se de incluir o arquivo config.js antes deste arquivo em todas as páginas HTML

// Namespace para APIs do superadmin
const superadminAPI = {
    // Função auxiliar para fazer requisições à API
    _request: async function(endpoint, method = 'GET', data = null, headers = {}) {
        try {
            // Verificar se a configuração está disponível
            if (!config || !config.apiBaseUrl) {
                throw new Error('Configuração da API não encontrada');
            }
            
            // Construir URL completa
            const url = `${config.apiBaseUrl}/admin/${endpoint}`;
            
            // Configurar headers padrão
            const defaultHeaders = {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            };
            
            // Obter token de autenticação se disponível
            const session = JSON.parse(localStorage.getItem('superadmin_session') || 'null');
            if (session && session.token) {
                defaultHeaders['Authorization'] = `Bearer ${session.token}`;
            }
            
            // Mesclar headers
            const requestHeaders = { ...defaultHeaders, ...headers };
            
            // Configurar requisição
            const requestOptions = {
                method,
                headers: requestHeaders,
                timeout: config.requestTimeout || 30000
            };
            
            // Adicionar corpo da requisição se necessário
            if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
                requestOptions.body = JSON.stringify(data);
            }
            
            // Log de requisição se habilitado
            if (config.enableRequestLogs) {
                console.log(`API Request: ${method} ${url}`, data);
            }
            
            // Fazer requisição
            const response = await fetch(url, requestOptions);
            
            // Verificar status da resposta
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw {
                    status: response.status,
                    statusText: response.statusText,
                    data: errorData
                };
            }
            
            // Processar resposta
            const responseData = await response.json();
            
            // Log de resposta se habilitado
            if (config.enableRequestLogs) {
                console.log(`API Response: ${method} ${url}`, responseData);
            }
            
            return responseData;
        } catch (error) {
            // Log de erro
            console.error('API Error:', error);
            
            // Rejeitar promessa com erro formatado
            throw {
                mensagem: error.data?.mensagem || error.message || 'Erro na comunicação com o servidor',
                status: error.status || 0,
                original: error
            };
        }
    },
    
    // Autenticar superadmin
    autenticarSuperadmin: function(login, senha) {
        return this._request('auth/login', 'POST', { login, senha });
    },
    
    // Verificar sessão do superadmin
    verificarSessaoSuperadmin: function() {
        return this._request('auth/session', 'GET');
    },
    
    // Encerrar sessão do superadmin
    encerrarSessaoSuperadmin: function() {
        return this._request('auth/logout', 'POST');
    },
    
    // Obter estatísticas globais
    obterEstatisticasGlobais: function() {
        return this._request('estatisticas', 'GET');
    },
    
    // Listar empresas
    listarEmpresas: function(filtros = {}) {
        // Converter filtros para query string
        const queryParams = new URLSearchParams();
        
        if (filtros.status && filtros.status !== 'todos') {
            queryParams.append('status', filtros.status);
        }
        
        if (filtros.licenca && filtros.licenca !== 'todas') {
            queryParams.append('licenca', filtros.licenca);
        }
        
        if (filtros.busca) {
            queryParams.append('busca', filtros.busca);
        }
        
        const queryString = queryParams.toString();
        const endpoint = `empresas${queryString ? '?' + queryString : ''}`;
        
        return this._request(endpoint, 'GET');
    },
    
    // Obter empresa
    obterEmpresa: function(id) {
        return this._request(`empresas/${id}`, 'GET');
    },
    
    // Cadastrar empresa
    cadastrarEmpresa: function(dadosEmpresa, dadosAdmin) {
        return this._request('empresas', 'POST', { empresa: dadosEmpresa, admin: dadosAdmin });
    },
    
    // Atualizar empresa
    atualizarEmpresa: function(id, dadosEmpresa) {
        return this._request(`empresas/${id}`, 'PUT', dadosEmpresa);
    },
    
    // Alterar status da empresa
    alterarStatusEmpresa: function(id, status) {
        return this._request(`empresas/${id}/status`, 'PATCH', { status });
    },
    
    // Excluir empresa
    excluirEmpresa: function(id) {
        return this._request(`empresas/${id}`, 'DELETE');
    }
};
