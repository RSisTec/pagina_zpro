// Script para a página inicial (index.js)
document.addEventListener('DOMContentLoaded', function() {
    // Placeholder para o logo
    const logoPlaceholder = document.getElementById('logo-placeholder');
    logoPlaceholder.onerror = function() {
        this.src = 'https://via.placeholder.com/150x50?text=EstacionaFacil';
    };
    
    // Toggle do menu mobile
    const navToggle = document.getElementById('nav-toggle');
    const navList = document.getElementById('nav-list');
    
    navToggle.addEventListener('click', function() {
        navList.classList.toggle('active');
    });
    
    // Tabs de consulta
    const tabs = document.querySelectorAll('.search-tab');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Hide all tab contents
            document.getElementById('ticket-tab').style.display = 'none';
            document.getElementById('telefone-tab').style.display = 'none';
            
            // Show selected tab content
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId + '-tab').style.display = 'block';
        });
    });
    
    // Modal de resultado
    const resultModal = document.getElementById('result-modal');
    const closeModal = document.getElementById('close-modal');
    const closeResult = document.getElementById('close-result');
    
    function showModal() {
        resultModal.classList.add('active');
    }
    
    function hideModal() {
        resultModal.classList.remove('active');
    }
    
    closeModal.addEventListener('click', hideModal);
    closeResult.addEventListener('click', hideModal);
    
    // Fechar modal ao clicar fora
    resultModal.addEventListener('click', function(e) {
        if (e.target === resultModal) {
            hideModal();
        }
    });
    
    // Formulários de consulta
    const ticketForm = document.getElementById('ticket-form');
    const telefoneForm = document.getElementById('telefone-form');
    
    ticketForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const ticket = document.getElementById('ticket').value;
        
        if (!ticket) {
            showNotification('Por favor, digite o número do ticket', 'error');
            return;
        }
        
        // Aqui seria feita a consulta à API
        // Por enquanto, apenas mostra o modal com dados de exemplo
        showModal();
    });
    
    telefoneForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const telefone = document.getElementById('telefone').value;
        
        if (!telefone) {
            showNotification('Por favor, digite o número de telefone', 'error');
            return;
        }
        
        // Aqui seria feita a consulta à API
        // Por enquanto, apenas mostra o modal com dados de exemplo
        showModal();
    });
    
    // Notificações
    const notification = document.getElementById('notification');
    const closeNotification = document.getElementById('close-notification');
    const notificationMessage = document.getElementById('notification-message');
    
    function showNotification(message, type = 'info') {
        notificationMessage.textContent = message;
        notification.className = 'notification notification-' + type + ' show';
        
        setTimeout(function() {
            hideNotification();
        }, 5000);
    }
    
    function hideNotification() {
        notification.classList.remove('show');
    }
    
    closeNotification.addEventListener('click', hideNotification);
});
