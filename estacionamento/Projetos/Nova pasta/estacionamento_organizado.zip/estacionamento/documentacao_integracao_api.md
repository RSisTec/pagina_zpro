# Documentação de Integração com API Externa

## Visão Geral

Este documento descreve as modificações realizadas no sistema de estacionamento para utilizar uma API externa como fonte de dados. Todas as operações de leitura e escrita de dados agora são realizadas através de requisições HTTP para a API externa, utilizando uma URL base configurável.

## Arquivos Modificados

1. **config.js** (novo)
   - Arquivo de configuração central que define a URL base da API e outras configurações
   - Deve ser incluído antes de qualquer arquivo de API em todas as páginas HTML

2. **api.js**
   - Reescrito para utilizar requisições HTTP à API externa
   - Todas as funções mantêm a mesma assinatura para compatibilidade com o código existente
   - Utiliza a URL base definida em config.js

3. **superadmin-api.js**
   - Reescrito para utilizar requisições HTTP à API externa
   - Todas as funções mantêm a mesma assinatura para compatibilidade com o código existente
   - Utiliza a URL base definida em config.js com prefixo "/admin"

4. **main.js**
   - Simplificado para remover funções de acesso a dados local
   - Mantém apenas funções utilitárias que não dependem de acesso a dados

## Como Configurar

### 1. Configuração da URL Base

Abra o arquivo `js/config.js` e configure a URL base da API:

```javascript
const config = {
    // URL base da API externa
    apiBaseUrl: 'https://api.estacionamento.com.br/v1',
    
    // Outras configurações...
};
```

Substitua `'https://api.estacionamento.com.br/v1'` pela URL base da sua API.

### 2. Inclusão dos Scripts

Em todas as páginas HTML, certifique-se de incluir os scripts na seguinte ordem:

```html
<!-- Scripts -->
<script src="js/config.js"></script>
<script src="js/main.js"></script>
<script src="js/api.js"></script>
<!-- Outros scripts específicos da página -->
```

Para páginas de superadmin, inclua também:

```html
<script src="js/superadmin-api.js"></script>
```

## Estrutura da API

### Endpoints Principais

A API deve fornecer os seguintes endpoints:

#### Autenticação
- `POST /auth/login` - Autenticação de usuário
- `POST /admin/auth/login` - Autenticação de superadmin

#### Veículos
- `GET /veiculos/placa/{placa}` - Consultar veículo por placa
- `POST /veiculos` - Adicionar veículo ao pátio
- `GET /veiculos/patio` - Listar veículos no pátio
- `GET /veiculos/ticket/{ticket}` - Buscar veículo por ticket
- `POST /veiculos/saida/{ticket}` - Registrar saída de veículo

#### Mensalistas
- `GET /mensalistas` - Listar mensalistas
- `POST /mensalistas` - Cadastrar mensalista
- `PUT /mensalistas/{id}` - Atualizar mensalista
- `DELETE /mensalistas/{id}` - Excluir mensalista

#### Isentos
- `GET /isentos` - Listar isentos
- `POST /isentos` - Cadastrar isento
- `PUT /isentos/{id}` - Atualizar isento
- `DELETE /isentos/{id}` - Excluir isento

#### Serviços
- `GET /servicos` - Listar serviços
- `POST /servicos` - Cadastrar serviço
- `PUT /servicos/{id}` - Atualizar serviço
- `DELETE /servicos/{id}` - Excluir serviço
- `POST /veiculos/{ticket}/servicos` - Adicionar serviço ao veículo

#### Preços
- `GET /precos` - Listar preços
- `POST /precos` - Cadastrar preço
- `PUT /precos/{id}` - Atualizar preço
- `DELETE /precos/{id}` - Excluir preço
- `POST /precos/{id}/ativar` - Ativar preço

#### Usuários
- `GET /usuarios` - Listar usuários
- `POST /usuarios` - Cadastrar usuário
- `PUT /usuarios/{id}` - Atualizar usuário
- `DELETE /usuarios/{id}` - Excluir usuário

#### Relatórios
- `POST /relatorios/veiculos` - Gerar relatório de veículos
- `POST /relatorios/faturamento` - Gerar relatório de faturamento

#### Superadmin (Prefixo /admin)
- `GET /admin/estatisticas` - Obter estatísticas globais
- `GET /admin/empresas` - Listar empresas
- `GET /admin/empresas/{id}` - Obter empresa
- `POST /admin/empresas` - Cadastrar empresa
- `PUT /admin/empresas/{id}` - Atualizar empresa
- `PATCH /admin/empresas/{id}/status` - Alterar status da empresa
- `DELETE /admin/empresas/{id}` - Excluir empresa

### Formato de Dados

Todas as requisições e respostas utilizam o formato JSON. Os cabeçalhos padrão são:

```
Content-Type: application/json
Accept: application/json
```

Para endpoints autenticados, o token deve ser enviado no cabeçalho:

```
Authorization: Bearer {token}
```

## Autenticação

O sistema utiliza autenticação baseada em token. Após o login bem-sucedido, o token é armazenado no localStorage e enviado em todas as requisições subsequentes.

## Tratamento de Erros

Todas as requisições incluem tratamento de erros padronizado. Os erros da API são formatados e exibidos ao usuário através do sistema de notificações.

## Considerações para Implementação da API

Ao implementar a API externa, certifique-se de:

1. Seguir a estrutura de endpoints documentada
2. Manter compatibilidade com os formatos de dados esperados
3. Implementar autenticação baseada em token
4. Fornecer mensagens de erro claras e informativas
5. Implementar controle de acesso baseado em níveis de usuário
6. Garantir que todas as operações sejam transacionais quando apropriado

## Próximos Passos

1. Implementar a API externa conforme a documentação
2. Testar a integração em ambiente de desenvolvimento
3. Ajustar os endpoints conforme necessário
4. Implantar em ambiente de produção
