# Sistema de Estacionamento

## Visão Geral
Este é um sistema de estacionamento moderno e responsivo, 100% baseado em HTML, CSS e JavaScript puros, sem backend. Toda a lógica de negócios, leitura, gravação e exclusão de dados é feita por meio de uma API externa, enquanto os cálculos de permanência e valor são processados no frontend.

## Estrutura do Sistema
O sistema possui três áreas principais:

1. **Área do Cliente**: Consulta pública de informações do ticket de estacionamento
2. **Área Administrativa**: Gestão do estacionamento por parte da empresa
3. **Área do SuperAdmin**: Cadastro e gestão de empresas (clientes do sistema)

## Arquivos e Diretórios
```
/
├── index.html                  (Área do Cliente/Pública)
├── login.html                  (Login para Administradores de Empresas)
├── superadmin-login.html       (Login para SuperAdmin)
├── admin-dashboard.html        (Dashboard da Área Administrativa da Empresa)
├── superadmin-dashboard.html   (Dashboard da Área do SuperAdmin)
├── css/
│   ├── style.css               (Estilos gerais e modais)
│   └── responsive.css          (Estilos para responsividade)
├── js/
│   ├── config.js               (Configuração da API)
│   ├── auth.js                 (Funções de autenticação)
│   ├── api.js                  (Funções para chamadas à API)
│   ├── ui.js                   (Funções para manipulação de UI)
│   ├── superadmin.js           (Lógica específica do SuperAdmin)
│   ├── admin.js                (Lógica específica da Área Administrativa)
│   ├── common.js               (Funções JS comuns)
│   └── calculations.js         (Lógica para cálculos de tempo e valor)
└── assets/                     (Imagens, ícones, etc.)
```

## Funcionalidades Principais

### Área do Cliente
- Consulta por número do ticket ou telefone
- Exibição dos resultados: tempo de permanência, dados do veículo, valor estimado
- Exibição de informações estáticas do estacionamento

### Autenticação
- Login para administradores e operadores de estacionamento
- Login para SuperAdmin
- Proteção de rotas com verificação de token
- Níveis de acesso: SuperAdmin, Master, Operador, Visualizador
- Logout seguro

### Área do SuperAdmin
- Dashboard de empresas com lista de todas as empresas cadastradas
- Destaque visual para licenças expiradas ou próximas do vencimento
- Cadastro, edição e exclusão de empresas
- Gestão de usuários por empresa

### Área Administrativa
- Dashboard principal com visualização do pátio atual
- Registro de entrada e saída de veículos
- Cálculo automático de tempo de permanência e valor a pagar
- Gestão de preços, mensalistas e isentos
- Serviços avulsos e relatórios

## Integração com API
O sistema recebe apenas uma variável com a URL base da API, e todas as rotas são montadas dinamicamente com base nela. A configuração da URL base pode ser feita na área do SuperAdmin.

## Tecnologias Utilizadas
- HTML5: Estrutura semântica das páginas
- CSS3: Estilização, responsividade, animações
- JavaScript (ES6+): Lógica de frontend, manipulação do DOM, requisições assíncronas

## Como Usar

### Configuração Inicial
1. Defina a URL base da API no arquivo `js/config.js` ou através da área de configurações do SuperAdmin
2. Acesse o sistema através do arquivo `index.html` para a área do cliente ou `login.html` para a área administrativa

### Credenciais de Acesso
- Para acessar a área administrativa: Use as credenciais fornecidas pelo SuperAdmin
- Para acessar a área do SuperAdmin: Use as credenciais de SuperAdmin fornecidas pelo administrador do sistema

## Responsividade
O sistema é totalmente responsivo, adaptando-se a diferentes tamanhos de tela (celular, tablet e desktop) através do uso de Flexbox e Grid.

## Segurança
- Armazenamento seguro de token JWT no localStorage
- Controle de acesso baseado em níveis de permissão
- Validação de entrada de dados no frontend
- Prevenção de cliques duplos e tratamento de erros

## Observações
- O sistema não possui banco de dados local. Todos os dados são gerenciados pela API externa.
- A lógica de associação de usuários a empresas e a validade de licenças são gerenciadas pela API.
