/**
 * Common JS
 * Este arquivo contém funções comuns utilizadas em todo o sistema
 */

// Classe para funções comuns
class CommonService {
    constructor() {
        // Inicializar
    }

    // Formatar data para exibição
    formatDate(dateString) {
        if (!dateString) return '-';
        
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return dateString;
        
        return date.toLocaleDateString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
    }

    // Formatar data e hora para exibição
    formatDateTime(dateString) {
        if (!dateString) return '-';
        
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return dateString;
        
        return date.toLocaleDateString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // Formatar valor monetário
    formatCurrency(value) {
        if (value === undefined || value === null) return 'R$ 0,00';
        
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(value);
    }

    // Validar placa de veículo (formatos antigo e Mercosul)
    validatePlaca(placa) {
        if (!placa) return false;
        
        // Remover espaços e traços
        placa = placa.replace(/[\s-]/g, '').toUpperCase();
        
        // Formato antigo: AAA0000
        const oldFormat = /^[A-Z]{3}[0-9]{4}$/;
        
        // Formato Mercosul: AAA0A00
        const mercosulFormat = /^[A-Z]{3}[0-9][A-Z][0-9]{2}$/;
        
        return oldFormat.test(placa) || mercosulFormat.test(placa);
    }

    // Formatar placa para exibição
    formatPlaca(placa) {
        if (!placa) return '';
        
        // Remover espaços e traços
        placa = placa.replace(/[\s-]/g, '').toUpperCase();
        
        // Formato Mercosul: AAA0A00
        if (/^[A-Z]{3}[0-9][A-Z][0-9]{2}$/.test(placa)) {
            return `${placa.slice(0, 3)}-${placa.slice(3)}`;
        }
        
        // Formato antigo: AAA0000
        if (/^[A-Z]{3}[0-9]{4}$/.test(placa)) {
            return `${placa.slice(0, 3)}-${placa.slice(3)}`;
        }
        
        return placa;
    }

    // Validar CPF
    validateCPF(cpf) {
        if (!cpf) return false;
        
        // Remover caracteres não numéricos
        cpf = cpf.replace(/\D/g, '');
        
        if (cpf.length !== 11) return false;
        
        // Verificar se todos os dígitos são iguais
        if (/^(\d)\1+$/.test(cpf)) return false;
        
        // Validação dos dígitos verificadores
        let sum = 0;
        let remainder;
        
        // Primeiro dígito verificador
        for (let i = 1; i <= 9; i++) {
            sum += parseInt(cpf.substring(i - 1, i)) * (11 - i);
        }
        
        remainder = (sum * 10) % 11;
        if (remainder === 10 || remainder === 11) remainder = 0;
        if (remainder !== parseInt(cpf.substring(9, 10))) return false;
        
        // Segundo dígito verificador
        sum = 0;
        for (let i = 1; i <= 10; i++) {
            sum += parseInt(cpf.substring(i - 1, i)) * (12 - i);
        }
        
        remainder = (sum * 10) % 11;
        if (remainder === 10 || remainder === 11) remainder = 0;
        if (remainder !== parseInt(cpf.substring(10, 11))) return false;
        
        return true;
    }

    // Formatar CPF para exibição
    formatCPF(cpf) {
        if (!cpf) return '';
        
        // Remover caracteres não numéricos
        cpf = cpf.replace(/\D/g, '');
        
        if (cpf.length !== 11) return cpf;
        
        return cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
    }

    // Validar CNPJ
    validateCNPJ(cnpj) {
        if (!cnpj) return false;
        
        // Remover caracteres não numéricos
        cnpj = cnpj.replace(/\D/g, '');
        
        if (cnpj.length !== 14) return false;
        
        // Verificar se todos os dígitos são iguais
        if (/^(\d)\1+$/.test(cnpj)) return false;
        
        // Validação dos dígitos verificadores
        let size = cnpj.length - 2;
        let numbers = cnpj.substring(0, size);
        let digits = cnpj.substring(size);
        let sum = 0;
        let pos = size - 7;
        
        // Primeiro dígito verificador
        for (let i = size; i >= 1; i--) {
            sum += parseInt(numbers.charAt(size - i)) * pos--;
            if (pos < 2) pos = 9;
        }
        
        let result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
        if (result !== parseInt(digits.charAt(0))) return false;
        
        // Segundo dígito verificador
        size += 1;
        numbers = cnpj.substring(0, size);
        sum = 0;
        pos = size - 7;
        
        for (let i = size; i >= 1; i--) {
            sum += parseInt(numbers.charAt(size - i)) * pos--;
            if (pos < 2) pos = 9;
        }
        
        result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
        if (result !== parseInt(digits.charAt(1))) return false;
        
        return true;
    }

    // Formatar CNPJ para exibição
    formatCNPJ(cnpj) {
        if (!cnpj) return '';
        
        // Remover caracteres não numéricos
        cnpj = cnpj.replace(/\D/g, '');
        
        if (cnpj.length !== 14) return cnpj;
        
        return cnpj.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
    }

    // Formatar telefone para exibição
    formatPhone(phone) {
        if (!phone) return '';
        
        // Remover caracteres não numéricos
        phone = phone.replace(/\D/g, '');
        
        if (phone.length === 11) {
            // Celular com DDD
            return phone.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
        } else if (phone.length === 10) {
            // Telefone fixo com DDD
            return phone.replace(/(\d{2})(\d{4})(\d{4})/, '($1) $2-$3');
        } else if (phone.length === 9) {
            // Celular sem DDD
            return phone.replace(/(\d{5})(\d{4})/, '$1-$2');
        } else if (phone.length === 8) {
            // Telefone fixo sem DDD
            return phone.replace(/(\d{4})(\d{4})/, '$1-$2');
        }
        
        return phone;
    }

    // Gerar ID único
    generateUniqueId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2, 5).toUpperCase();
    }

    // Verificar se uma data está próxima de expirar (em dias)
    isDateNearExpiry(dateString, daysThreshold = 30) {
        if (!dateString) return false;
        
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return false;
        
        const today = new Date();
        const diffTime = date.getTime() - today.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        return diffDays > 0 && diffDays <= daysThreshold;
    }

    // Verificar se uma data já expirou
    isDateExpired(dateString) {
        if (!dateString) return false;
        
        const date = new Date(dateString);
        if (isNaN(date.getTime())) return false;
        
        const today = new Date();
        
        // Definir hora, minuto, segundo e milissegundo para 23:59:59.999
        date.setHours(23, 59, 59, 999);
        
        return date < today;
    }

    // Obter status de uma data de validade
    getExpiryStatus(dateString) {
        if (this.isDateExpired(dateString)) {
            return 'expired'; // Expirado
        } else if (this.isDateNearExpiry(dateString)) {
            return 'warning'; // Próximo a expirar
        } else {
            return 'active'; // Ativo
        }
    }

    // Formatar status de expiração para exibição
    formatExpiryStatus(status) {
        switch (status) {
            case 'expired':
                return '<span class="status-badge status-expired">Expirado</span>';
            case 'warning':
                return '<span class="status-badge status-warning">Próximo a expirar</span>';
            case 'active':
                return '<span class="status-badge status-active">Ativo</span>';
            default:
                return '<span class="status-badge">Desconhecido</span>';
        }
    }
}

// Criar instância global do serviço de funções comuns
window.commonService = new CommonService();
