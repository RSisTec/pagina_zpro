/**
 * Autenticação
 * Este arquivo contém funções para autenticação, verificação de token e controle de acesso
 */

// Classe para gerenciar autenticação
class AuthService {
    constructor() {
        this.tokenKey = 'authToken';
        this.userDataKey = 'userData';
        this.tokenExpiryKey = 'tokenExpiry';
    }

    // Salvar dados de autenticação
    saveAuthData(token, userData, expiryInHours = 24) {
        localStorage.setItem(this.tokenKey, token);
        localStorage.setItem(this.userDataKey, JSON.stringify(userData));
        
        // Calcular data de expiração
        const expiryDate = new Date();
        expiryDate.setHours(expiryDate.getHours() + expiryInHours);
        localStorage.setItem(this.tokenExpiryKey, expiryDate.toISOString());
    }

    // Obter token
    getToken() {
        return localStorage.getItem(this.tokenKey);
    }

    // Obter dados do usuário
    getUserData() {
        const userData = localStorage.getItem(this.userDataKey);
        return userData ? JSON.parse(userData) : null;
    }

    // Verificar se o usuário está autenticado
    isAuthenticated() {
        const token = this.getToken();
        if (!token) return false;

        // Verificar expiração
        const expiry = localStorage.getItem(this.tokenExpiryKey);
        if (!expiry) return false;

        const expiryDate = new Date(expiry);
        const now = new Date();
        
        return expiryDate > now;
    }

    // Verificar se o usuário é SuperAdmin
    isSuperAdmin() {
        const userData = this.getUserData();
        return userData && userData.role === 'superadmin';
    }

    // Verificar nível de acesso
    hasAccessLevel(requiredLevel) {
        const userData = this.getUserData();
        if (!userData || !userData.nivelAcesso) return false;

        const nivelAcesso = userData.nivelAcesso.toLowerCase();
        
        // Níveis de acesso em ordem decrescente de permissão
        const levels = ['superadmin', 'master', 'operador', 'visualizador'];
        
        const userLevelIndex = levels.indexOf(nivelAcesso);
        const requiredLevelIndex = levels.indexOf(requiredLevel.toLowerCase());
        
        // Usuário tem acesso se seu nível for igual ou superior ao requerido
        return userLevelIndex !== -1 && userLevelIndex <= requiredLevelIndex;
    }

    // Fazer login
    async login(email, password) {
        try {
            const response = await window.apiService.login(email, password);
            
            if (response && response.token) {
                this.saveAuthData(response.token, response.user);
                return true;
            }
            return false;
        } catch (error) {
            console.error('Erro ao fazer login:', error);
            return false;
        }
    }

    // Fazer login como SuperAdmin
    async superadminLogin(email, password) {
        try {
            const response = await window.apiService.superadminLogin(email, password);
            
            if (response && response.token) {
                this.saveAuthData(response.token, { ...response.user, role: 'superadmin' });
                return true;
            }
            return false;
        } catch (error) {
            console.error('Erro ao fazer login como SuperAdmin:', error);
            return false;
        }
    }

    // Fazer logout
    logout() {
        localStorage.removeItem(this.tokenKey);
        localStorage.removeItem(this.userDataKey);
        localStorage.removeItem(this.tokenExpiryKey);
    }

    // Redirecionar com base no nível de acesso
    redirectBasedOnRole() {
        if (this.isSuperAdmin()) {
            window.location.href = 'superadmin-dashboard.html';
        } else if (this.isAuthenticated()) {
            window.location.href = 'admin-dashboard.html';
        } else {
            window.location.href = 'login.html';
        }
    }

    // Proteger página
    protectPage(allowedRoles = []) {
        if (!this.isAuthenticated()) {
            window.location.href = 'login.html';
            return false;
        }

        // Se não houver restrição de papéis, qualquer usuário autenticado pode acessar
        if (allowedRoles.length === 0) {
            return true;
        }

        // Verificar se o usuário tem um dos papéis permitidos
        const userData = this.getUserData();
        const userRole = this.isSuperAdmin() ? 'superadmin' : userData.nivelAcesso.toLowerCase();
        
        if (!allowedRoles.includes(userRole)) {
            // Redirecionar com base no papel atual
            this.redirectBasedOnRole();
            return false;
        }

        return true;
    }
}

// Criar instância global do serviço de autenticação
window.authService = new AuthService();

// Inicializar eventos de login quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos na página de login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const loginButton = document.getElementById('loginButton');
            
            // Mostrar loader
            loginButton.disabled = true;
            loginButton.querySelector('.btn-text').style.display = 'none';
            loginButton.querySelector('.btn-loader').style.display = 'inline-block';
            
            try {
                const success = await window.authService.login(email, password);
                
                if (success) {
                    window.authService.redirectBasedOnRole();
                } else {
                    window.uiService.showAlert('Erro de autenticação', 'Email ou senha incorretos. Por favor, tente novamente.');
                }
            } catch (error) {
                window.uiService.showAlert('Erro', 'Ocorreu um erro ao tentar fazer login. Por favor, tente novamente.');
                console.error('Erro no login:', error);
            } finally {
                // Esconder loader
                loginButton.disabled = false;
                loginButton.querySelector('.btn-text').style.display = 'inline';
                loginButton.querySelector('.btn-loader').style.display = 'none';
            }
        });
    }
    
    // Verificar se estamos na página de login do SuperAdmin
    const superadminLoginForm = document.getElementById('superadminLoginForm');
    if (superadminLoginForm) {
        superadminLoginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const loginButton = document.getElementById('loginButton');
            
            // Mostrar loader
            loginButton.disabled = true;
            loginButton.querySelector('.btn-text').style.display = 'none';
            loginButton.querySelector('.btn-loader').style.display = 'inline-block';
            
            try {
                const success = await window.authService.superadminLogin(email, password);
                
                if (success) {
                    window.location.href = 'superadmin-dashboard.html';
                } else {
                    window.uiService.showAlert('Erro de autenticação', 'Email ou senha incorretos. Por favor, tente novamente.');
                }
            } catch (error) {
                window.uiService.showAlert('Erro', 'Ocorreu um erro ao tentar fazer login. Por favor, tente novamente.');
                console.error('Erro no login:', error);
            } finally {
                // Esconder loader
                loginButton.disabled = false;
                loginButton.querySelector('.btn-text').style.display = 'inline';
                loginButton.querySelector('.btn-loader').style.display = 'none';
            }
        });
    }
    
    // Verificar se há botão de logout
    const logoutButton = document.getElementById('logoutButton');
    if (logoutButton) {
        logoutButton.addEventListener('click', function() {
            window.authService.logout();
            window.location.href = 'login.html';
        });
    }
    
    // Exibir informações do usuário se estiver em uma página protegida
    const userNameElement = document.getElementById('userName');
    const userAccessLevelElement = document.getElementById('userAccessLevel');
    
    if (userNameElement && userAccessLevelElement && window.authService.isAuthenticated()) {
        const userData = window.authService.getUserData();
        
        if (userData) {
            userNameElement.textContent = userData.email || 'Usuário';
            
            if (window.authService.isSuperAdmin()) {
                userAccessLevelElement.textContent = 'SuperAdmin';
            } else {
                userAccessLevelElement.textContent = userData.nivelAcesso || 'Usuário';
            }
        }
    }
});
