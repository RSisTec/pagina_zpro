/**
 * API Service
 * Este arquivo contém funções para realizar chamadas à API
 */

// Classe para gerenciar chamadas à API
class ApiService {
    constructor() {
        this.baseUrl = window.configApi.getApiBaseUrl();
    }

    // Atualiza a URL base se necessário
    updateBaseUrl() {
        this.baseUrl = window.configApi.getApiBaseUrl();
    }

    // Método para obter o token de autenticação
    getAuthToken() {
        return localStorage.getItem('authToken');
    }

    // Método para construir headers com autenticação
    getHeaders(includeAuth = true) {
        const headers = {
            'Content-Type': 'application/json'
        };

        if (includeAuth) {
            const token = this.getAuthToken();
            if (token) {
                headers['Authorization'] = `Bearer ${token}`;
            }
        }

        return headers;
    }

    // Método GET
    async get(endpoint, params = {}, requiresAuth = true) {
        this.updateBaseUrl();
        
        // Construir URL com parâmetros de consulta
        let url = `${this.baseUrl}${endpoint}`;
        if (Object.keys(params).length > 0) {
            const queryParams = new URLSearchParams();
            for (const key in params) {
                if (params[key] !== undefined && params[key] !== null) {
                    queryParams.append(key, params[key]);
                }
            }
            url += `?${queryParams.toString()}`;
        }

        try {
            const response = await fetch(url, {
                method: 'GET',
                headers: this.getHeaders(requiresAuth)
            });

            if (!response.ok) {
                throw new Error(`Erro na requisição: ${response.status} ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error('Erro na requisição GET:', error);
            throw error;
        }
    }

    // Método POST
    async post(endpoint, data = {}, requiresAuth = true) {
        this.updateBaseUrl();
        
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                method: 'POST',
                headers: this.getHeaders(requiresAuth),
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error(`Erro na requisição: ${response.status} ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error('Erro na requisição POST:', error);
            throw error;
        }
    }

    // Método PUT
    async put(endpoint, data = {}, requiresAuth = true) {
        this.updateBaseUrl();
        
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                method: 'PUT',
                headers: this.getHeaders(requiresAuth),
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error(`Erro na requisição: ${response.status} ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error('Erro na requisição PUT:', error);
            throw error;
        }
    }

    // Método DELETE
    async delete(endpoint, requiresAuth = true) {
        this.updateBaseUrl();
        
        try {
            const response = await fetch(`${this.baseUrl}${endpoint}`, {
                method: 'DELETE',
                headers: this.getHeaders(requiresAuth)
            });

            if (!response.ok) {
                throw new Error(`Erro na requisição: ${response.status} ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error('Erro na requisição DELETE:', error);
            throw error;
        }
    }

    // Endpoints específicos
    
    // Autenticação
    async login(email, password) {
        return this.post('/auth/login', { email, password }, false);
    }

    async superadminLogin(email, password) {
        return this.post('/auth/superadmin-login', { email, password }, false);
    }

    // Pátio
    async getPatioVeiculos() {
        return this.get('/patio');
    }

    // Entrada e Saída
    async registrarEntrada(dados) {
        return this.post('/entrada', dados);
    }

    async registrarSaida(dados) {
        return this.post('/saida', dados);
    }

    // Ticket
    async buscarTicket(ticketId) {
        return this.get('/ticket', { ticketId }, false);
    }

    // Histórico
    async buscarHistoricoPlaca(placa) {
        return this.get('/historico', { placa });
    }

    // Mensalistas
    async getMensalistas() {
        return this.get('/mensalistas');
    }

    async criarMensalista(dados) {
        return this.post('/mensalistas', dados);
    }

    async atualizarMensalista(id, dados) {
        return this.put(`/mensalistas/${id}`, dados);
    }

    async deletarMensalista(id) {
        return this.delete(`/mensalistas/${id}`);
    }

    // Isentos
    async getIsentos() {
        return this.get('/isentos');
    }

    async criarIsento(dados) {
        return this.post('/isentos', dados);
    }

    async atualizarIsento(id, dados) {
        return this.put(`/isentos/${id}`, dados);
    }

    async deletarIsento(id) {
        return this.delete(`/isentos/${id}`);
    }

    // Serviços
    async getServicos() {
        return this.get('/servicos');
    }

    async registrarServicoAvulso(dados) {
        return this.post('/servicos-avulsos', dados);
    }

    // Preços
    async getPrecos() {
        return this.get('/precos');
    }

    async atualizarPrecos(dados) {
        return this.put('/precos', dados);
    }

    // Relatórios
    async getRelatorios(dataInicial, dataFinal) {
        return this.get('/relatorios', { data_inicial: dataInicial, data_final: dataFinal });
    }

    // Empresas (SuperAdmin)
    async getEmpresas() {
        return this.get('/empresas');
    }

    async criarEmpresa(dados) {
        return this.post('/empresas', dados);
    }

    async atualizarEmpresa(id, dados) {
        return this.put(`/empresas/${id}`, dados);
    }

    async deletarEmpresa(id) {
        return this.delete(`/empresas/${id}`);
    }

    // Usuários (SuperAdmin)
    async getUsuariosEmpresa(empresaId) {
        return this.get(`/users/empresa/${empresaId}`);
    }

    async criarUsuarioEmpresa(dados) {
        return this.post('/auth/register/empresa', dados);
    }

    async atualizarUsuario(id, dados) {
        return this.put(`/users/${id}`, dados);
    }

    async deletarUsuario(id) {
        return this.delete(`/users/${id}`);
    }

    // Mensagens
    async enviarMensagem(dados) {
        return this.post('/mensagem', dados);
    }
}

// Criar instância global do serviço de API
window.apiService = new ApiService();
