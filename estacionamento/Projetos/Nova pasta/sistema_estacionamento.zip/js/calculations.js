/**
 * Calculations JS
 * Este arquivo contém funções para cálculos de tempo de permanência e valores
 */

// Classe para cálculos
class CalculationsService {
    constructor() {
        this.precos = null;
    }

    // Carregar preços da API
    async loadPrecos() {
        try {
            this.precos = await window.apiService.getPrecos();
            return this.precos;
        } catch (error) {
            console.error('Erro ao carregar preços:', error);
            return null;
        }
    }

    // Obter preços atuais
    getPrecos() {
        return this.precos;
    }

    // Calcular tempo de permanência em minutos
    calcularTempoMinutos(dataHoraEntrada) {
        if (!dataHoraEntrada) return 0;
        
        const entrada = new Date(dataHoraEntrada);
        const agora = new Date();
        
        if (isNaN(entrada.getTime())) return 0;
        
        // Diferença em milissegundos
        const diff = agora.getTime() - entrada.getTime();
        
        // Converter para minutos
        return Math.floor(diff / (1000 * 60));
    }

    // Formatar tempo de permanência para exibição
    formatarTempoPermanencia(minutos) {
        if (minutos === undefined || minutos === null) return '-';
        
        const dias = Math.floor(minutos / (60 * 24));
        const horas = Math.floor((minutos % (60 * 24)) / 60);
        const mins = minutos % 60;
        
        let resultado = '';
        
        if (dias > 0) {
            resultado += `${dias}d `;
        }
        
        if (horas > 0 || dias > 0) {
            resultado += `${horas}h `;
        }
        
        resultado += `${mins}m`;
        
        return resultado.trim();
    }

    // Calcular valor a pagar com base no tempo de permanência
    calcularValorPagar(minutos) {
        if (!this.precos || minutos === undefined || minutos === null) return 0;
        
        // Converter minutos para horas (arredondando para cima)
        const horas = Math.ceil(minutos / 60);
        
        // Verificar se é diária
        if (horas >= 12 && this.precos.diaria) {
            // Calcular número de diárias
            const diarias = Math.ceil(horas / 24);
            return diarias * this.precos.diaria;
        }
        
        // Verificar faixas de preço
        if (this.precos.faixas && this.precos.faixas.length > 0) {
            // Ordenar faixas por hora inicial
            const faixasOrdenadas = [...this.precos.faixas].sort((a, b) => a.horaInicial - b.horaInicial);
            
            // Encontrar faixa correspondente
            for (let i = faixasOrdenadas.length - 1; i >= 0; i--) {
                const faixa = faixasOrdenadas[i];
                if (horas >= faixa.horaInicial) {
                    // Se for a última faixa ou estiver dentro do limite da faixa
                    if (i === faixasOrdenadas.length - 1 || horas < faixasOrdenadas[i + 1].horaInicial) {
                        // Calcular valor base da faixa
                        let valor = faixa.valor;
                        
                        // Adicionar horas adicionais se necessário
                        const horasAdicionais = horas - faixa.horaInicial;
                        if (horasAdicionais > 0 && this.precos.horaAdicional) {
                            valor += horasAdicionais * this.precos.horaAdicional;
                        }
                        
                        return valor;
                    }
                }
            }
        }
        
        // Caso não encontre faixa, usar hora adicional como base
        if (this.precos.horaAdicional) {
            return horas * this.precos.horaAdicional;
        }
        
        return 0;
    }

    // Verificar se um veículo é mensalista
    async verificarMensalista(placa) {
        if (!placa) return false;
        
        try {
            const mensalistas = await window.apiService.getMensalistas();
            
            if (!mensalistas || !Array.isArray(mensalistas)) return false;
            
            // Encontrar mensalista com a placa correspondente
            const mensalista = mensalistas.find(m => 
                m.placa && m.placa.replace(/[\s-]/g, '').toUpperCase() === placa.replace(/[\s-]/g, '').toUpperCase()
            );
            
            if (!mensalista) return false;
            
            // Verificar se o mensalista está ativo (data de validade)
            if (mensalista.dataValidade) {
                const dataValidade = new Date(mensalista.dataValidade);
                const hoje = new Date();
                
                // Definir hora, minuto, segundo e milissegundo para 23:59:59.999
                dataValidade.setHours(23, 59, 59, 999);
                
                if (dataValidade < hoje) {
                    return false; // Mensalista com contrato expirado
                }
            }
            
            return true;
        } catch (error) {
            console.error('Erro ao verificar mensalista:', error);
            return false;
        }
    }

    // Verificar se um veículo é isento
    async verificarIsento(placa) {
        if (!placa) return false;
        
        try {
            const isentos = await window.apiService.getIsentos();
            
            if (!isentos || !Array.isArray(isentos)) return false;
            
            // Encontrar isento com a placa correspondente
            const isento = isentos.find(i => 
                i.placa && i.placa.replace(/[\s-]/g, '').toUpperCase() === placa.replace(/[\s-]/g, '').toUpperCase()
            );
            
            if (!isento) return false;
            
            // Verificar se o isento está ativo (data de validade)
            if (isento.dataValidade) {
                const dataValidade = new Date(isento.dataValidade);
                const hoje = new Date();
                
                // Definir hora, minuto, segundo e milissegundo para 23:59:59.999
                dataValidade.setHours(23, 59, 59, 999);
                
                if (dataValidade < hoje) {
                    return false; // Isento com período expirado
                }
            }
            
            return true;
        } catch (error) {
            console.error('Erro ao verificar isento:', error);
            return false;
        }
    }

    // Verificar se um veículo já está no pátio
    async verificarVeiculoNoPatio(placa) {
        if (!placa) return false;
        
        try {
            const veiculosPatio = await window.apiService.getPatioVeiculos();
            
            if (!veiculosPatio || !Array.isArray(veiculosPatio)) return false;
            
            // Encontrar veículo com a placa correspondente
            return veiculosPatio.some(v => 
                v.placa && v.placa.replace(/[\s-]/g, '').toUpperCase() === placa.replace(/[\s-]/g, '').toUpperCase()
            );
        } catch (error) {
            console.error('Erro ao verificar veículo no pátio:', error);
            return false;
        }
    }

    // Calcular valor total de serviços selecionados
    calcularValorServicos(servicosIds, listaServicos) {
        if (!servicosIds || !Array.isArray(servicosIds) || !listaServicos || !Array.isArray(listaServicos)) {
            return 0;
        }
        
        let valorTotal = 0;
        
        servicosIds.forEach(id => {
            const servico = listaServicos.find(s => s.id === id);
            if (servico && servico.valor) {
                valorTotal += parseFloat(servico.valor);
            }
        });
        
        return valorTotal;
    }
}

// Criar instância global do serviço de cálculos
window.calculationsService = new CalculationsService();
