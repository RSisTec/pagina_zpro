/**
 * Configuração da API
 * Este arquivo contém a configuração da URL base da API
 */

// URL base da API - pode ser alterada pelo administrador
const API_BASE_URL = "https://api.exemplo.com";

// Função para obter a URL base da API
function getApiBaseUrl() {
    // Verificar se existe uma URL personalizada no localStorage
    const customUrl = localStorage.getItem('apiBaseUrl');
    return customUrl || API_BASE_URL;
}

// Função para definir uma nova URL base da API
function setApiBaseUrl(url) {
    if (!url) return false;
    
    // Validar formato da URL
    try {
        new URL(url);
        localStorage.setItem('apiBaseUrl', url);
        return true;
    } catch (e) {
        console.error("URL inválida:", e);
        return false;
    }
}

// Exportar as funções para uso em outros arquivos
window.configApi = {
    getApiBaseUrl,
    setApiBaseUrl
};
