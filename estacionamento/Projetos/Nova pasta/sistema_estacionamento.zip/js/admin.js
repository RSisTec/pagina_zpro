/**
 * Admin JS
 * Este arquivo contém funções específicas para a área administrativa
 */

// Classe para gerenciar a área administrativa
class AdminService {
    constructor() {
        this.patioData = [];
        this.mensalistasData = [];
        this.isentosData = [];
        this.servicosData = [];
    }

    // Inicializar a área administrativa
    async init() {
        // Proteger página
        if (!window.authService.protectPage(['master', 'operador', 'visualizador'])) {
            return;
        }

        // Carregar dados iniciais
        await this.carregarPatio();
        
        // Carregar preços
        await window.calculationsService.loadPrecos();
        
        // Inicializar eventos
        this.initEventos();
        
        // Atualizar informações do usuário
        this.atualizarInfoUsuario();
        
        // Iniciar atualização automática do pátio
        this.iniciarAtualizacaoAutomatica();
    }

    // Inicializar eventos
    initEventos() {
        // Botão de nova entrada
        const novaEntradaBtn = document.getElementById('novaEntradaBtn');
        if (novaEntradaBtn) {
            novaEntradaBtn.addEventListener('click', () => {
                window.uiService.clearForm('entradaForm');
                window.uiService.showModal('entradaModal');
            });
        }
        
        // Botão de saída
        const saidaBtn = document.getElementById('saidaBtn');
        if (saidaBtn) {
            saidaBtn.addEventListener('click', () => {
                window.uiService.clearForm('saidaForm');
                document.getElementById('ticketInfoSaida').style.display = 'none';
                document.getElementById('formaPagamentoGroup').style.display = 'none';
                document.getElementById('cpfGroup').style.display = 'none';
                document.getElementById('opcoesSaidaGroup').style.display = 'none';
                document.getElementById('confirmarSaidaBtn').disabled = true;
                window.uiService.showModal('saidaModal');
            });
        }
        
        // Botão de cancelar entrada
        const cancelarEntradaBtn = document.getElementById('cancelarEntradaBtn');
        if (cancelarEntradaBtn) {
            cancelarEntradaBtn.addEventListener('click', () => {
                window.uiService.closeModal('entradaModal');
            });
        }
        
        // Botão de confirmar entrada
        const confirmarEntradaBtn = document.getElementById('confirmarEntradaBtn');
        if (confirmarEntradaBtn) {
            confirmarEntradaBtn.addEventListener('click', () => this.registrarEntrada());
        }
        
        // Campo de placa na entrada
        const placaEntrada = document.getElementById('placaEntrada');
        if (placaEntrada) {
            placaEntrada.addEventListener('blur', () => this.buscarHistoricoPlaca());
        }
        
        // Botão de cancelar saída
        const cancelarSaidaBtn = document.getElementById('cancelarSaidaBtn');
        if (cancelarSaidaBtn) {
            cancelarSaidaBtn.addEventListener('click', () => {
                window.uiService.closeModal('saidaModal');
            });
        }
        
        // Botão de confirmar saída
        const confirmarSaidaBtn = document.getElementById('confirmarSaidaBtn');
        if (confirmarSaidaBtn) {
            confirmarSaidaBtn.addEventListener('click', () => this.registrarSaida());
        }
        
        // Campo de ticket na saída
        const ticketIdSaida = document.getElementById('ticketIdSaida');
        if (ticketIdSaida) {
            ticketIdSaida.addEventListener('blur', () => this.buscarTicket());
        }
    }

    // Atualizar informações do usuário
    atualizarInfoUsuario() {
        const userData = window.authService.getUserData();
        
        if (userData) {
            const userNameElement = document.getElementById('userName');
            const userAccessLevelElement = document.getElementById('userAccessLevel');
            
            if (userNameElement) {
                userNameElement.textContent = userData.email || 'Usuário';
            }
            
            if (userAccessLevelElement) {
                userAccessLevelElement.textContent = userData.nivelAcesso || 'Usuário';
            }
        }
    }

    // Iniciar atualização automática do pátio
    iniciarAtualizacaoAutomatica() {
        // Atualizar a cada 60 segundos
        setInterval(() => {
            this.carregarPatio();
        }, 60000);
    }

    // Carregar dados do pátio
    async carregarPatio() {
        try {
            const response = await window.apiService.getPatioVeiculos();
            
            if (response && Array.isArray(response)) {
                this.patioData = response;
                this.renderizarTabelaPatio();
            }
        } catch (error) {
            console.error('Erro ao carregar pátio:', error);
            window.uiService.showAlert('Erro', 'Não foi possível carregar os dados do pátio. Por favor, tente novamente.');
        }
    }

    // Renderizar tabela do pátio
    renderizarTabelaPatio() {
        const columns = [
            { field: 'ticketId', formatter: (value) => value || '-' },
            { field: 'placa', formatter: (value) => window.commonService.formatPlaca(value) },
            { field: 'modelo', formatter: (value) => value || '-' },
            { field: 'cor', formatter: (value) => value || '-' },
            { 
                field: 'dataHoraEntrada', 
                formatter: (value) => window.commonService.formatDateTime(value) 
            },
            { 
                field: 'dataHoraEntrada', 
                formatter: (value) => {
                    const minutos = window.calculationsService.calcularTempoMinutos(value);
                    return window.calculationsService.formatarTempoPermanencia(minutos);
                }
            }
        ];
        
        const actions = [
            {
                text: 'Saída',
                class: 'btn-secondary',
                handler: (data) => {
                    window.uiService.clearForm('saidaForm');
                    document.getElementById('ticketIdSaida').value = data.ticketId;
                    this.buscarTicket();
                    window.uiService.showModal('saidaModal');
                }
            }
        ];
        
        window.uiService.fillTable('patioTableBody', this.patioData, columns, actions);
    }

    // Buscar histórico da placa
    async buscarHistoricoPlaca() {
        const placa = document.getElementById('placaEntrada').value;
        
        if (!placa || placa.trim() === '') return;
        
        if (!window.commonService.validatePlaca(placa)) {
            window.uiService.showAlert('Aviso', 'Placa inválida. Por favor, verifique o formato.');
            return;
        }
        
        try {
            // Verificar se o veículo já está no pátio
            const jaEstaNoPatio = await window.calculationsService.verificarVeiculoNoPatio(placa);
            
            if (jaEstaNoPatio) {
                window.uiService.showAlert('Aviso', 'Este veículo já está no pátio.');
            }
            
            // Verificar se é mensalista
            const ehMensalista = await window.calculationsService.verificarMensalista(placa);
            
            // Verificar se é isento
            const ehIsento = await window.calculationsService.verificarIsento(placa);
            
            // Buscar histórico
            const historico = await window.apiService.buscarHistoricoPlaca(placa);
            
            if (historico && historico.length > 0) {
                // Preencher campos com dados do último registro
                const ultimoRegistro = historico[0];
                
                document.getElementById('modeloEntrada').value = ultimoRegistro.modelo || '';
                document.getElementById('corEntrada').value = ultimoRegistro.cor || '';
            }
            
            // Destacar visualmente se for mensalista ou isento
            const placaInput = document.getElementById('placaEntrada');
            
            placaInput.classList.remove('mensalista', 'isento');
            
            if (ehMensalista) {
                placaInput.classList.add('mensalista');
                window.uiService.showAlert('Informação', 'Este veículo é mensalista.');
            }
            
            if (ehIsento) {
                placaInput.classList.add('isento');
                window.uiService.showAlert('Informação', 'Este veículo é isento.');
            }
        } catch (error) {
            console.error('Erro ao buscar histórico da placa:', error);
        }
    }

    // Registrar entrada de veículo
    async registrarEntrada() {
        if (!window.uiService.validateForm('entradaForm')) {
            window.uiService.showAlert('Aviso', 'Por favor, preencha todos os campos obrigatórios.');
            return;
        }
        
        const formData = window.uiService.getFormData('entradaForm');
        
        if (!window.commonService.validatePlaca(formData.placa)) {
            window.uiService.showAlert('Aviso', 'Placa inválida. Por favor, verifique o formato.');
            return;
        }
        
        // Verificar se o veículo já está no pátio
        const jaEstaNoPatio = await window.calculationsService.verificarVeiculoNoPatio(formData.placa);
        
        if (jaEstaNoPatio) {
            window.uiService.showAlert('Aviso', 'Este veículo já está no pátio.');
            return;
        }
        
        try {
            window.uiService.toggleButtonLoader('confirmarEntradaBtn', true);
            
            const response = await window.apiService.registrarEntrada({
                placa: formData.placa,
                modelo: formData.modelo,
                cor: formData.cor,
                telefone: formData.telefone || null,
                imprimirTicket: formData.imprimirTicket || false
            });
            
            if (response && response.success) {
                window.uiService.showAlert('Sucesso', 'Entrada registrada com sucesso!', () => {
                    window.uiService.closeModal('entradaModal');
                    this.carregarPatio();
                });
            } else {
                window.uiService.showAlert('Erro', 'Não foi possível registrar a entrada. Por favor, tente novamente.');
            }
        } catch (error) {
            console.error('Erro ao registrar entrada:', error);
            window.uiService.showAlert('Erro', 'Ocorreu um erro ao registrar a entrada. Por favor, tente novamente.');
        } finally {
            window.uiService.toggleButtonLoader('confirmarEntradaBtn', false);
        }
    }

    // Buscar ticket
    async buscarTicket() {
        const ticketId = document.getElementById('ticketIdSaida').value;
        
        if (!ticketId || ticketId.trim() === '') {
            document.getElementById('ticketInfoSaida').style.display = 'none';
            document.getElementById('formaPagamentoGroup').style.display = 'none';
            document.getElementById('cpfGroup').style.display = 'none';
            document.getElementById('opcoesSaidaGroup').style.display = 'none';
            document.getElementById('confirmarSaidaBtn').disabled = true;
            return;
        }
        
        try {
            const response = await window.apiService.buscarTicket(ticketId);
            
            if (response && response.ticketId) {
                // Preencher informações do ticket
                document.getElementById('placaSaida').textContent = window.commonService.formatPlaca(response.placa);
                document.getElementById('modeloSaida').textContent = response.modelo || '-';
                document.getElementById('corSaida').textContent = response.cor || '-';
                document.getElementById('entradaSaida').textContent = window.commonService.formatDateTime(response.dataHoraEntrada);
                
                // Calcular tempo de permanência
                const minutos = window.calculationsService.calcularTempoMinutos(response.dataHoraEntrada);
                document.getElementById('permanenciaSaida').textContent = window.calculationsService.formatarTempoPermanencia(minutos);
                
                // Calcular valor a pagar
                let valorPagar = 0;
                
                // Verificar se é mensalista ou isento
                const ehMensalista = await window.calculationsService.verificarMensalista(response.placa);
                const ehIsento = await window.calculationsService.verificarIsento(response.placa);
                
                if (!ehMensalista && !ehIsento) {
                    valorPagar = window.calculationsService.calcularValorPagar(minutos);
                }
                
                document.getElementById('valorSaida').textContent = window.commonService.formatCurrency(valorPagar);
                
                // Mostrar informações e campos adicionais
                document.getElementById('ticketInfoSaida').style.display = 'block';
                document.getElementById('formaPagamentoGroup').style.display = 'block';
                document.getElementById('cpfGroup').style.display = 'block';
                document.getElementById('opcoesSaidaGroup').style.display = 'block';
                document.getElementById('confirmarSaidaBtn').disabled = false;
                
                // Destacar visualmente se for mensalista ou isento
                const ticketInfo = document.getElementById('ticketInfoSaida');
                
                ticketInfo.classList.remove('mensalista', 'isento');
                
                if (ehMensalista) {
                    ticketInfo.classList.add('mensalista');
                    window.uiService.showAlert('Informação', 'Este veículo é mensalista.');
                }
                
                if (ehIsento) {
                    ticketInfo.classList.add('isento');
                    window.uiService.showAlert('Informação', 'Este veículo é isento.');
                }
            } else {
                window.uiService.showAlert('Aviso', 'Ticket não encontrado. Por favor, verifique o número informado.');
                document.getElementById('ticketInfoSaida').style.display = 'none';
                document.getElementById('formaPagamentoGroup').style.display = 'none';
                document.getElementById('cpfGroup').style.display = 'none';
                document.getElementById('opcoesSaidaGroup').style.display = 'none';
                document.getElementById('confirmarSaidaBtn').disabled = true;
            }
        } catch (error) {
            console.error('Erro ao buscar ticket:', error);
            window.uiService.showAlert('Erro', 'Ocorreu um erro ao buscar o ticket. Por favor, tente novamente.');
        }
    }

    // Registrar saída de veículo
    async registrarSaida() {
        const ticketId = document.getElementById('ticketIdSaida').value;
        const formaPagamento = document.getElementById('formaPagamento').value;
        
        if (!ticketId || ticketId.trim() === '') {
            window.uiService.showAlert('Aviso', 'Por favor, informe o número do ticket.');
            return;
        }
        
        if (!formaPagamento || formaPagamento.trim() === '') {
            window.uiService.showAlert('Aviso', 'Por favor, selecione a forma de pagamento.');
            return;
        }
        
        try {
            window.uiService.toggleButtonLoader('confirmarSaidaBtn', true);
            
            // Obter valor a pagar do elemento
            const valorText = document.getElementById('valorSaida').textContent;
            const valorPago = parseFloat(valorText.replace(/[^\d,]/g, '').replace(',', '.')) || 0;
            
            const cpf = document.getElementById('cpfSaida').value;
            const enviarMensagem = document.getElementById('enviarMensagem').checked;
            const imprimirComprovante = document.getElementById('imprimirComprovante').checked;
            
            const response = await window.apiService.registrarSaida({
                ticketId,
                valorPago,
                formaPagamento,
                cpf: cpf || null,
                enviarMensagem,
                imprimirComprovante
            });
            
            if (response && response.success) {
                window.uiService.showAlert('Sucesso', 'Saída registrada com sucesso!', () => {
                    window.uiService.closeModal('saidaModal');
                    this.carregarPatio();
                });
            } else {
                window.uiService.showAlert('Erro', 'Não foi possível registrar a saída. Por favor, tente novamente.');
            }
        } catch (error) {
            console.error('Erro ao registrar saída:', error);
            window.uiService.showAlert('Erro', 'Ocorreu um erro ao registrar a saída. Por favor, tente novamente.');
        } finally {
            window.uiService.toggleButtonLoader('confirmarSaidaBtn', false);
        }
    }
}

// Criar instância global do serviço administrativo
window.adminService = new AdminService();

// Inicializar quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos na página do dashboard administrativo
    if (document.querySelector('.admin-dashboard')) {
        window.adminService.init();
    }
});
