/**
 * SuperAdmin JS
 * Este arquivo contém funções específicas para a área do SuperAdmin
 */

// Classe para gerenciar a área do SuperAdmin
class SuperAdminService {
    constructor() {
        this.empresasData = [];
        this.usuariosData = [];
        this.empresaSelecionada = null;
    }

    // Inicializar a área do SuperAdmin
    async init() {
        // Proteger página
        if (!window.authService.protectPage(['superadmin'])) {
            return;
        }

        // Carregar dados iniciais
        await this.carregarEmpresas();
        
        // Inicializar eventos
        this.initEventos();
        
        // Atualizar informações do usuário
        this.atualizarInfoUsuario();
    }

    // Inicializar eventos
    initEventos() {
        // Botão de nova empresa
        const novaEmpresaBtn = document.getElementById('novaEmpresaBtn');
        if (novaEmpresaBtn) {
            novaEmpresaBtn.addEventListener('click', () => {
                window.uiService.clearForm('empresaForm');
                document.getElementById('empresaModalTitle').textContent = 'Nova Empresa';
                window.uiService.showModal('empresaModal');
            });
        }
        
        // Botão de cancelar empresa
        const cancelarEmpresaBtn = document.getElementById('cancelarEmpresaBtn');
        if (cancelarEmpresaBtn) {
            cancelarEmpresaBtn.addEventListener('click', () => {
                window.uiService.closeModal('empresaModal');
            });
        }
        
        // Botão de salvar empresa
        const salvarEmpresaBtn = document.getElementById('salvarEmpresaBtn');
        if (salvarEmpresaBtn) {
            salvarEmpresaBtn.addEventListener('click', () => this.salvarEmpresa());
        }
        
        // Botão de fechar usuários
        const fecharUsuariosBtn = document.getElementById('fecharUsuariosBtn');
        if (fecharUsuariosBtn) {
            fecharUsuariosBtn.addEventListener('click', () => {
                window.uiService.closeModal('usuariosModal');
            });
        }
        
        // Botão de novo usuário
        const novoUsuarioBtn = document.getElementById('novoUsuarioBtn');
        if (novoUsuarioBtn) {
            novoUsuarioBtn.addEventListener('click', () => {
                window.uiService.clearForm('usuarioForm');
                document.getElementById('usuarioModalTitle').textContent = 'Novo Usuário';
                document.getElementById('empresaIdUsuario').value = this.empresaSelecionada;
                document.getElementById('senhaUsuario').required = true;
                document.querySelector('.senha-group small').style.display = 'none';
                window.uiService.showModal('usuarioModal');
            });
        }
        
        // Botão de cancelar usuário
        const cancelarUsuarioBtn = document.getElementById('cancelarUsuarioBtn');
        if (cancelarUsuarioBtn) {
            cancelarUsuarioBtn.addEventListener('click', () => {
                window.uiService.closeModal('usuarioModal');
            });
        }
        
        // Botão de salvar usuário
        const salvarUsuarioBtn = document.getElementById('salvarUsuarioBtn');
        if (salvarUsuarioBtn) {
            salvarUsuarioBtn.addEventListener('click', () => this.salvarUsuario());
        }
        
        // Formulário de configuração
        const configForm = document.getElementById('configForm');
        if (configForm) {
            configForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.salvarConfiguracao();
            });
            
            // Carregar URL atual
            const apiBaseUrlInput = document.getElementById('apiBaseUrl');
            if (apiBaseUrlInput) {
                apiBaseUrlInput.value = window.configApi.getApiBaseUrl();
            }
        }
    }

    // Atualizar informações do usuário
    atualizarInfoUsuario() {
        const userData = window.authService.getUserData();
        
        if (userData) {
            const userNameElement = document.getElementById('userName');
            
            if (userNameElement) {
                userNameElement.textContent = userData.email || 'SuperAdmin';
            }
        }
    }

    // Carregar empresas
    async carregarEmpresas() {
        try {
            const response = await window.apiService.getEmpresas();
            
            if (response && Array.isArray(response)) {
                this.empresasData = response;
                this.renderizarTabelaEmpresas();
            }
        } catch (error) {
            console.error('Erro ao carregar empresas:', error);
            window.uiService.showAlert('Erro', 'Não foi possível carregar as empresas. Por favor, tente novamente.');
        }
    }

    // Renderizar tabela de empresas
    renderizarTabelaEmpresas() {
        const columns = [
            { field: 'nome', formatter: (value) => value || '-' },
            { field: 'cnpj', formatter: (value) => window.commonService.formatCNPJ(value) },
            { 
                field: 'dataValidadeLicenca', 
                formatter: (value) => window.commonService.formatDate(value) 
            },
            { 
                field: 'dataValidadeLicenca', 
                formatter: (value) => {
                    const status = window.commonService.getExpiryStatus(value);
                    return window.commonService.formatExpiryStatus(status);
                }
            }
        ];
        
        const actions = [
            {
                text: 'Editar',
                class: 'btn-primary',
                handler: (data) => this.editarEmpresa(data)
            },
            {
                text: 'Usuários',
                class: 'btn-secondary',
                handler: (data) => this.gerenciarUsuarios(data)
            },
            {
                text: 'Excluir',
                class: 'btn-danger',
                handler: (data) => this.confirmarExclusaoEmpresa(data)
            }
        ];
        
        window.uiService.fillTable('empresasTableBody', this.empresasData, columns, actions);
    }

    // Editar empresa
    editarEmpresa(empresa) {
        window.uiService.clearForm('empresaForm');
        document.getElementById('empresaModalTitle').textContent = 'Editar Empresa';
        window.uiService.fillForm('empresaForm', empresa);
        window.uiService.showModal('empresaModal');
    }

    // Salvar empresa
    async salvarEmpresa() {
        if (!window.uiService.validateForm('empresaForm')) {
            window.uiService.showAlert('Aviso', 'Por favor, preencha todos os campos obrigatórios.');
            return;
        }
        
        const formData = window.uiService.getFormData('empresaForm');
        
        if (formData.cnpj && !window.commonService.validateCNPJ(formData.cnpj)) {
            window.uiService.showAlert('Aviso', 'CNPJ inválido. Por favor, verifique o formato.');
            return;
        }
        
        try {
            window.uiService.toggleButtonLoader('salvarEmpresaBtn', true);
            
            let response;
            
            if (formData.id) {
                // Atualizar empresa existente
                response = await window.apiService.atualizarEmpresa(formData.id, {
                    nome: formData.nome,
                    cnpj: formData.cnpj,
                    endereco: formData.endereco,
                    telefone: formData.telefone,
                    email: formData.email,
                    dataValidadeLicenca: formData.dataValidadeLicenca
                });
            } else {
                // Criar nova empresa
                response = await window.apiService.criarEmpresa({
                    nome: formData.nome,
                    cnpj: formData.cnpj,
                    endereco: formData.endereco,
                    telefone: formData.telefone,
                    email: formData.email,
                    dataValidadeLicenca: formData.dataValidadeLicenca
                });
            }
            
            if (response && response.success) {
                window.uiService.showAlert('Sucesso', 'Empresa salva com sucesso!', () => {
                    window.uiService.closeModal('empresaModal');
                    this.carregarEmpresas();
                });
            } else {
                window.uiService.showAlert('Erro', 'Não foi possível salvar a empresa. Por favor, tente novamente.');
            }
        } catch (error) {
            console.error('Erro ao salvar empresa:', error);
            window.uiService.showAlert('Erro', 'Ocorreu um erro ao salvar a empresa. Por favor, tente novamente.');
        } finally {
            window.uiService.toggleButtonLoader('salvarEmpresaBtn', false);
        }
    }

    // Confirmar exclusão de empresa
    confirmarExclusaoEmpresa(empresa) {
        window.uiService.showConfirm(
            `Tem certeza que deseja excluir a empresa "${empresa.nome}"? Esta ação não pode ser desfeita.`,
            () => this.excluirEmpresa(empresa.id)
        );
    }

    // Excluir empresa
    async excluirEmpresa(id) {
        try {
            const response = await window.apiService.deletarEmpresa(id);
            
            if (response && response.success) {
                window.uiService.showAlert('Sucesso', 'Empresa excluída com sucesso!', () => {
                    this.carregarEmpresas();
                });
            } else {
                window.uiService.showAlert('Erro', 'Não foi possível excluir a empresa. Por favor, tente novamente.');
            }
        } catch (error) {
            console.error('Erro ao excluir empresa:', error);
            window.uiService.showAlert('Erro', 'Ocorreu um erro ao excluir a empresa. Por favor, tente novamente.');
        }
    }

    // Gerenciar usuários de uma empresa
    async gerenciarUsuarios(empresa) {
        this.empresaSelecionada = empresa.id;
        document.getElementById('empresaNomeUsuarios').textContent = empresa.nome;
        
        try {
            const response = await window.apiService.getUsuariosEmpresa(empresa.id);
            
            if (response && Array.isArray(response)) {
                this.usuariosData = response;
                this.renderizarTabelaUsuarios();
                window.uiService.showModal('usuariosModal');
            } else {
                window.uiService.showAlert('Erro', 'Não foi possível carregar os usuários. Por favor, tente novamente.');
            }
        } catch (error) {
            console.error('Erro ao carregar usuários:', error);
            window.uiService.showAlert('Erro', 'Ocorreu um erro ao carregar os usuários. Por favor, tente novamente.');
        }
    }

    // Renderizar tabela de usuários
    renderizarTabelaUsuarios() {
        const columns = [
            { field: 'email', formatter: (value) => value || '-' },
            { 
                field: 'nivelAcesso', 
                formatter: (value) => {
                    switch (value) {
                        case 'master': return 'Master';
                        case 'operador': return 'Operador';
                        case 'visualizador': return 'Visualizador';
                        default: return value || '-';
                    }
                }
            }
        ];
        
        const actions = [
            {
                text: 'Editar',
                class: 'btn-primary',
                handler: (data) => this.editarUsuario(data)
            },
            {
                text: 'Excluir',
                class: 'btn-danger',
                handler: (data) => this.confirmarExclusaoUsuario(data)
            }
        ];
        
        window.uiService.fillTable('usuariosTableBody', this.usuariosData, columns, actions);
    }

    // Editar usuário
    editarUsuario(usuario) {
        window.uiService.clearForm('usuarioForm');
        document.getElementById('usuarioModalTitle').textContent = 'Editar Usuário';
        window.uiService.fillForm('usuarioForm', usuario);
        document.getElementById('empresaIdUsuario').value = this.empresaSelecionada;
        document.getElementById('senhaUsuario').required = false;
        document.querySelector('.senha-group small').style.display = 'block';
        window.uiService.showModal('usuarioModal');
    }

    // Salvar usuário
    async salvarUsuario() {
        if (!window.uiService.validateForm('usuarioForm')) {
            window.uiService.showAlert('Aviso', 'Por favor, preencha todos os campos obrigatórios.');
            return;
        }
        
        const formData = window.uiService.getFormData('usuarioForm');
        
        try {
            window.uiService.toggleButtonLoader('salvarUsuarioBtn', true);
            
            let response;
            
            if (formData.id) {
                // Atualizar usuário existente
                const dadosAtualizacao = {
                    email: formData.email,
                    nivelAcesso: formData.nivelAcesso
                };
                
                // Incluir senha apenas se foi preenchida
                if (formData.password && formData.password.trim() !== '') {
                    dadosAtualizacao.password = formData.password;
                }
                
                response = await window.apiService.atualizarUsuario(formData.id, dadosAtualizacao);
            } else {
                // Criar novo usuário
                response = await window.apiService.criarUsuarioEmpresa({
                    empresaId: formData.empresaId,
                    email: formData.email,
                    password: formData.password,
                    nivelAcesso: formData.nivelAcesso
                });
            }
            
            if (response && response.success) {
                window.uiService.showAlert('Sucesso', 'Usuário salvo com sucesso!', () => {
                    window.uiService.closeModal('usuarioModal');
                    this.gerenciarUsuarios({ id: this.empresaSelecionada, nome: document.getElementById('empresaNomeUsuarios').textContent });
                });
            } else {
                window.uiService.showAlert('Erro', 'Não foi possível salvar o usuário. Por favor, tente novamente.');
            }
        } catch (error) {
            console.error('Erro ao salvar usuário:', error);
            window.uiService.showAlert('Erro', 'Ocorreu um erro ao salvar o usuário. Por favor, tente novamente.');
        } finally {
            window.uiService.toggleButtonLoader('salvarUsuarioBtn', false);
        }
    }

    // Confirmar exclusão de usuário
    confirmarExclusaoUsuario(usuario) {
        window.uiService.showConfirm(
            `Tem certeza que deseja excluir o usuário "${usuario.email}"? Esta ação não pode ser desfeita.`,
            () => this.excluirUsuario(usuario.id)
        );
    }

    // Excluir usuário
    async excluirUsuario(id) {
        try {
            const response = await window.apiService.deletarUsuario(id);
            
            if (response && response.success) {
                window.uiService.showAlert('Sucesso', 'Usuário excluído com sucesso!', () => {
                    this.gerenciarUsuarios({ id: this.empresaSelecionada, nome: document.getElementById('empresaNomeUsuarios').textContent });
                });
            } else {
                window.uiService.showAlert('Erro', 'Não foi possível excluir o usuário. Por favor, tente novamente.');
            }
        } catch (error) {
            console.error('Erro ao excluir usuário:', error);
            window.uiService.showAlert('Erro', 'Ocorreu um erro ao excluir o usuário. Por favor, tente novamente.');
        }
    }

    // Salvar configuração
    salvarConfiguracao() {
        const apiBaseUrl = document.getElementById('apiBaseUrl').value;
        
        if (!apiBaseUrl || apiBaseUrl.trim() === '') {
            window.uiService.showAlert('Aviso', 'Por favor, informe a URL base da API.');
            return;
        }
        
        try {
            const success = window.configApi.setApiBaseUrl(apiBaseUrl);
            
            if (success) {
                window.uiService.showAlert('Sucesso', 'Configuração salva com sucesso!');
            } else {
                window.uiService.showAlert('Erro', 'URL inválida. Por favor, verifique o formato.');
            }
        } catch (error) {
            console.error('Erro ao salvar configuração:', error);
            window.uiService.showAlert('Erro', 'Ocorreu um erro ao salvar a configuração. Por favor, tente novamente.');
        }
    }
}

// Criar instância global do serviço do SuperAdmin
window.superAdminService = new SuperAdminService();

// Inicializar quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos na página do dashboard do SuperAdmin
    if (document.querySelector('.superadmin-dashboard')) {
        window.superAdminService.init();
    }
});
