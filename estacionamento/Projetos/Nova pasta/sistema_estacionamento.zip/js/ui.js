/**
 * UI Service
 * Este arquivo contém funções para manipulação da interface do usuário
 */

// Classe para gerenciar a interface do usuário
class UiService {
    constructor() {
        this.activeModals = [];
    }

    // Mostrar modal
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (!modal) return;
        
        modal.classList.add('active');
        this.activeModals.push(modalId);
        
        // Adicionar evento de fechamento ao clicar no X
        const closeButtons = modal.querySelectorAll('.close-modal');
        closeButtons.forEach(button => {
            button.addEventListener('click', () => this.closeModal(modalId));
        });
        
        // Adicionar evento de fechamento ao clicar fora do modal
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                this.closeModal(modalId);
            }
        });
        
        // Impedir scroll do body
        document.body.style.overflow = 'hidden';
    }

    // Fechar modal
    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (!modal) return;
        
        modal.classList.remove('active');
        this.activeModals = this.activeModals.filter(id => id !== modalId);
        
        // Restaurar scroll do body se não houver mais modais ativos
        if (this.activeModals.length === 0) {
            document.body.style.overflow = '';
        }
    }

    // Fechar todos os modais
    closeAllModals() {
        const modalsToClose = [...this.activeModals];
        modalsToClose.forEach(modalId => this.closeModal(modalId));
    }

    // Mostrar alerta
    showAlert(title, message, callback = null) {
        const alertModal = document.getElementById('alertModal');
        if (!alertModal) return;
        
        const titleElement = document.getElementById('alertTitle') || document.getElementById('modalTitle');
        const messageElement = document.getElementById('alertMessage') || document.getElementById('modalMessage');
        const okButton = document.getElementById('alertOkBtn') || document.getElementById('modalOkButton');
        
        if (titleElement) titleElement.textContent = title;
        if (messageElement) messageElement.textContent = message;
        
        if (okButton) {
            // Remover listeners antigos
            const newOkButton = okButton.cloneNode(true);
            okButton.parentNode.replaceChild(newOkButton, okButton);
            
            newOkButton.addEventListener('click', () => {
                this.closeModal('alertModal');
                if (callback && typeof callback === 'function') {
                    callback();
                }
            });
        }
        
        this.showModal('alertModal');
    }

    // Mostrar confirmação
    showConfirm(message, confirmCallback, cancelCallback = null) {
        const confirmModal = document.getElementById('confirmModal');
        if (!confirmModal) return;
        
        const messageElement = document.getElementById('confirmMessage');
        const confirmButton = document.getElementById('confirmBtn');
        const cancelButton = document.getElementById('cancelConfirmBtn');
        
        if (messageElement) messageElement.textContent = message;
        
        if (confirmButton) {
            // Remover listeners antigos
            const newConfirmButton = confirmButton.cloneNode(true);
            confirmButton.parentNode.replaceChild(newConfirmButton, confirmButton);
            
            newConfirmButton.addEventListener('click', () => {
                this.closeModal('confirmModal');
                if (confirmCallback && typeof confirmCallback === 'function') {
                    confirmCallback();
                }
            });
        }
        
        if (cancelButton) {
            // Remover listeners antigos
            const newCancelButton = cancelButton.cloneNode(true);
            cancelButton.parentNode.replaceChild(newCancelButton, cancelButton);
            
            newCancelButton.addEventListener('click', () => {
                this.closeModal('confirmModal');
                if (cancelCallback && typeof cancelCallback === 'function') {
                    cancelCallback();
                }
            });
        }
        
        this.showModal('confirmModal');
    }

    // Mostrar/esconder loader em botão
    toggleButtonLoader(buttonId, show) {
        const button = document.getElementById(buttonId);
        if (!button) return;
        
        const textElement = button.querySelector('.btn-text');
        const loaderElement = button.querySelector('.btn-loader');
        
        if (textElement && loaderElement) {
            if (show) {
                button.disabled = true;
                textElement.style.display = 'none';
                loaderElement.style.display = 'inline-block';
            } else {
                button.disabled = false;
                textElement.style.display = 'inline';
                loaderElement.style.display = 'none';
            }
        }
    }

    // Alternar entre seções de conteúdo
    switchSection(sectionId) {
        // Esconder todas as seções
        const sections = document.querySelectorAll('.content-section');
        sections.forEach(section => {
            section.classList.remove('active');
        });
        
        // Mostrar a seção selecionada
        const targetSection = document.getElementById(sectionId + 'Section');
        if (targetSection) {
            targetSection.classList.add('active');
        }
        
        // Atualizar navegação lateral
        const navItems = document.querySelectorAll('.sidebar-nav li');
        navItems.forEach(item => {
            item.classList.remove('active');
            
            const link = item.querySelector('a');
            if (link && link.getAttribute('data-section') === sectionId) {
                item.classList.add('active');
            }
        });
    }

    // Limpar formulário
    clearForm(formId) {
        const form = document.getElementById(formId);
        if (!form) return;
        
        form.reset();
        
        // Limpar campos hidden
        const hiddenInputs = form.querySelectorAll('input[type="hidden"]');
        hiddenInputs.forEach(input => {
            input.value = '';
        });
    }

    // Preencher formulário com dados
    fillForm(formId, data) {
        const form = document.getElementById(formId);
        if (!form || !data) return;
        
        // Percorrer todos os campos do formulário
        Array.from(form.elements).forEach(element => {
            const name = element.name;
            if (!name || name === '') return;
            
            // Verificar se existe o dado correspondente
            if (data[name] !== undefined) {
                if (element.type === 'checkbox') {
                    element.checked = Boolean(data[name]);
                } else if (element.type === 'radio') {
                    element.checked = (element.value === String(data[name]));
                } else if (element.tagName === 'SELECT') {
                    // Para select, procurar a opção correspondente
                    Array.from(element.options).forEach(option => {
                        option.selected = (option.value === String(data[name]));
                    });
                } else {
                    // Para inputs normais
                    element.value = data[name];
                }
            }
        });
    }

    // Obter dados do formulário
    getFormData(formId) {
        const form = document.getElementById(formId);
        if (!form) return null;
        
        const formData = {};
        
        // Percorrer todos os campos do formulário
        Array.from(form.elements).forEach(element => {
            const name = element.name;
            if (!name || name === '') return;
            
            if (element.type === 'checkbox') {
                formData[name] = element.checked;
            } else if (element.type === 'radio') {
                if (element.checked) {
                    formData[name] = element.value;
                }
            } else {
                formData[name] = element.value;
            }
        });
        
        return formData;
    }

    // Validar formulário
    validateForm(formId) {
        const form = document.getElementById(formId);
        if (!form) return false;
        
        let isValid = true;
        
        // Percorrer todos os campos obrigatórios
        const requiredFields = form.querySelectorAll('[required]');
        requiredFields.forEach(field => {
            if (!field.value || field.value.trim() === '') {
                isValid = false;
                field.classList.add('invalid');
                
                // Adicionar evento para remover classe de erro ao digitar
                field.addEventListener('input', function() {
                    if (this.value.trim() !== '') {
                        this.classList.remove('invalid');
                    }
                });
            } else {
                field.classList.remove('invalid');
            }
        });
        
        return isValid;
    }

    // Criar linha de tabela
    createTableRow(data, columns, actions = []) {
        const row = document.createElement('tr');
        
        // Adicionar células de dados
        columns.forEach(column => {
            const cell = document.createElement('td');
            
            if (typeof column === 'string') {
                // Coluna simples
                cell.textContent = data[column] || '';
            } else if (typeof column === 'object') {
                // Coluna com formatação personalizada
                if (column.formatter && typeof column.formatter === 'function') {
                    cell.innerHTML = column.formatter(data[column.field], data);
                } else {
                    cell.textContent = data[column.field] || '';
                }
                
                // Adicionar classes
                if (column.class) {
                    cell.className = column.class;
                }
            }
            
            row.appendChild(cell);
        });
        
        // Adicionar célula de ações
        if (actions.length > 0) {
            const actionsCell = document.createElement('td');
            actionsCell.className = 'action-cell';
            
            actions.forEach(action => {
                const button = document.createElement('button');
                button.className = `btn ${action.class || 'btn-primary'}`;
                button.textContent = action.text;
                
                if (action.icon) {
                    const icon = document.createElement('span');
                    icon.className = action.icon;
                    button.prepend(icon);
                }
                
                if (action.handler && typeof action.handler === 'function') {
                    button.addEventListener('click', () => action.handler(data));
                }
                
                actionsCell.appendChild(button);
            });
            
            row.appendChild(actionsCell);
        }
        
        return row;
    }

    // Preencher tabela com dados
    fillTable(tableBodyId, data, columns, actions = []) {
        const tableBody = document.getElementById(tableBodyId);
        if (!tableBody || !Array.isArray(data)) return;
        
        // Limpar tabela
        tableBody.innerHTML = '';
        
        // Adicionar linhas
        if (data.length === 0) {
            const emptyRow = document.createElement('tr');
            const emptyCell = document.createElement('td');
            emptyCell.colSpan = columns.length + (actions.length > 0 ? 1 : 0);
            emptyCell.textContent = 'Nenhum registro encontrado';
            emptyCell.className = 'text-center';
            emptyRow.appendChild(emptyCell);
            tableBody.appendChild(emptyRow);
        } else {
            data.forEach(item => {
                const row = this.createTableRow(item, columns, actions);
                tableBody.appendChild(row);
            });
        }
    }

    // Alternar menu mobile
    toggleMobileMenu() {
        const sidebar = document.querySelector('.sidebar');
        const overlay = document.querySelector('.sidebar-overlay');
        
        if (sidebar) {
            sidebar.classList.toggle('active');
        }
        
        if (overlay) {
            overlay.classList.toggle('active');
        }
    }
}

// Criar instância global do serviço de UI
window.uiService = new UiService();

// Inicializar eventos de UI quando o documento estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar navegação lateral
    const navLinks = document.querySelectorAll('.sidebar-nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            if (section) {
                window.uiService.switchSection(section);
            }
        });
    });
    
    // Inicializar toggle de menu mobile
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', function() {
            window.uiService.toggleMobileMenu();
        });
    }
    
    // Inicializar overlay do menu mobile
    const sidebarOverlay = document.querySelector('.sidebar-overlay');
    if (sidebarOverlay) {
        sidebarOverlay.addEventListener('click', function() {
            window.uiService.toggleMobileMenu();
        });
    }
});
