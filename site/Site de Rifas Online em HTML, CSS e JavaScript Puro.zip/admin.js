/**
 * Arquivo JavaScript para o painel administrativo
 */

// Variáveis globais
let rifasData = [];
let vendasData = [];
let clientesData = [];
let estatisticasData = {};

// Função para inicializar a página
async function inicializarPagina() {
    try {
        // Verificar qual página está sendo exibida
        const paginaAtual = obterPaginaAtual();
        
        // Carregar dados específicos da página
        switch (paginaAtual) {
            case 'dashboard':
                await carregarDadosDashboard();
                break;
            case 'rifas':
                await carregarRifas();
                break;
            case 'criar-rifa':
                configurarFormularioRifa();
                break;
            case 'editar-rifa':
                await carregarDadosEdicaoRifa();
                break;
            case 'gerenciar-rifa':
                await carregarDadosGerenciamentoRifa();
                break;
            case 'vendas':
                await carregarVendas();
                break;
            case 'clientes':
                await carregarClientes();
                break;
        }
        
        // Configurar eventos comuns
        configurarEventosComuns();
        
    } catch (error) {
        console.error('Erro ao inicializar página:', error);
        utils.mostrarNotificacao('Erro ao carregar dados', 'erro');
    }
}

// Função para obter a página atual
function obterPaginaAtual() {
    const path = window.location.pathname;
    const pagina = path.split('/').pop().replace('.html', '');
    
    return pagina || 'dashboard';
}

// Função para carregar dados do dashboard
async function carregarDadosDashboard() {
    try {
        // Simular carregamento de estatísticas
        estatisticasData = {
            totalRifas: 6,
            totalVendas: 124,
            totalClientes: 87,
            faturamentoTotal: 3450.00
        };
        
        // Atualizar cards de estatísticas
        document.getElementById('total-rifas').textContent = estatisticasData.totalRifas;
        document.getElementById('total-vendas').textContent = estatisticasData.totalVendas;
        document.getElementById('total-clientes').textContent = estatisticasData.totalClientes;
        document.getElementById('total-faturamento').textContent = utils.formatarMoeda(estatisticasData.faturamentoTotal);
        
        // Carregar rifas recentes
        await carregarRifasRecentes();
        
        // Carregar vendas recentes
        await carregarVendasRecentes();
        
    } catch (error) {
        console.error('Erro ao carregar dados do dashboard:', error);
        throw error;
    }
}

// Função para carregar rifas recentes
async function carregarRifasRecentes() {
    try {
        // Obter rifas da API
        const response = await api.obterRifas();
        
        if (response.success) {
            rifasData = response.data;
            
            // Exibir apenas as 5 primeiras rifas
            const rifasRecentes = rifasData.slice(0, 5);
            
            // Atualizar tabela de rifas
            const tabelaRifas = document.getElementById('tabela-rifas');
            
            if (tabelaRifas) {
                tabelaRifas.innerHTML = '';
                
                rifasRecentes.forEach(rifa => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${rifa.titulo}</td>
                        <td>${utils.formatarData(rifa.dataSorteio)}</td>
                        <td>${utils.formatarMoeda(rifa.valor)}</td>
                        <td>${rifa.numerosVendidos}/${rifa.totalNumeros}</td>
                        <td><span class="status-badge badge-${obterClasseStatus(rifa.status)}">${obterTextoStatus(rifa.status)}</span></td>
                        <td>
                            <div class="action-buttons">
                                <a href="gerenciar-rifa.html?id=${rifa.id}" class="btn-action btn-view" title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="editar-rifa.html?id=${rifa.id}" class="btn-action btn-edit" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button class="btn-action btn-delete" title="Excluir" data-id="${rifa.id}">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    `;
                    
                    tabelaRifas.appendChild(tr);
                });
                
                // Configurar eventos de exclusão
                configurarEventosExclusao();
            }
        }
    } catch (error) {
        console.error('Erro ao carregar rifas recentes:', error);
        throw error;
    }
}

// Função para carregar vendas recentes
async function carregarVendasRecentes() {
    try {
        // Simular carregamento de vendas recentes
        vendasData = [
            {
                id: 'venda1',
                cliente: 'João Silva',
                rifa: 'iPhone 15 Pro Max',
                numeros: [12, 34, 56],
                data: '2025-05-18T14:30:00',
                valor: 30.00,
                status: 'confirmado'
            },
            {
                id: 'venda2',
                cliente: 'Maria Oliveira',
                rifa: 'PlayStation 5 + 3 Jogos',
                numeros: [7, 21, 42, 65],
                data: '2025-05-17T10:15:00',
                valor: 20.00,
                status: 'confirmado'
            },
            {
                id: 'venda3',
                cliente: 'Pedro Santos',
                rifa: 'Smart TV 65" 4K',
                numeros: [18, 27],
                data: '2025-05-16T16:45:00',
                valor: 16.00,
                status: 'aguardando'
            },
            {
                id: 'venda4',
                cliente: 'Ana Costa',
                rifa: 'Vale Compras R$ 1.000',
                numeros: [101, 102, 103, 104, 105],
                data: '2025-05-15T09:20:00',
                valor: 12.50,
                status: 'cancelado'
            }
        ];
        
        // Atualizar tabela de vendas
        const tabelaVendas = document.getElementById('tabela-vendas');
        
        if (tabelaVendas) {
            tabelaVendas.innerHTML = '';
            
            vendasData.forEach(venda => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${venda.cliente}</td>
                    <td>${venda.rifa}</td>
                    <td>${venda.numeros.join(', ')}</td>
                    <td>${utils.formatarData(venda.data)}</td>
                    <td>${utils.formatarMoeda(venda.valor)}</td>
                    <td><span class="status-badge badge-${obterClasseStatusVenda(venda.status)}">${obterTextoStatusVenda(venda.status)}</span></td>
                `;
                
                tabelaVendas.appendChild(tr);
            });
        }
    } catch (error) {
        console.error('Erro ao carregar vendas recentes:', error);
        throw error;
    }
}

// Função para carregar todas as rifas
async function carregarRifas() {
    try {
        // Mostrar spinner de carregamento
        const tabelaRifas = document.getElementById('tabela-rifas-completa');
        if (tabelaRifas) {
            tabelaRifas.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center">
                        <div class="loading-spinner">
                            <i class="fas fa-spinner fa-spin"></i>
                            <p>Carregando rifas...</p>
                        </div>
                    </td>
                </tr>
            `;
        }
        
        // Obter rifas da API
        const response = await api.obterRifas();
        
        if (response.success) {
            rifasData = response.data;
            
            // Atualizar tabela de rifas
            if (tabelaRifas) {
                tabelaRifas.innerHTML = '';
                
                if (rifasData.length === 0) {
                    tabelaRifas.innerHTML = `
                        <tr>
                            <td colspan="7" class="text-center">
                                <p>Nenhuma rifa encontrada</p>
                            </td>
                        </tr>
                    `;
                    return;
                }
                
                rifasData.forEach(rifa => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${rifa.titulo}</td>
                        <td>${utils.formatarData(rifa.dataSorteio)}</td>
                        <td>${utils.formatarMoeda(rifa.valor)}</td>
                        <td>${rifa.numerosVendidos}/${rifa.totalNumeros}</td>
                        <td><span class="status-badge badge-${obterClasseStatus(rifa.status)}">${obterTextoStatus(rifa.status)}</span></td>
                        <td>
                            <div class="action-buttons">
                                <a href="gerenciar-rifa.html?id=${rifa.id}" class="btn-action btn-view" title="Visualizar">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="editar-rifa.html?id=${rifa.id}" class="btn-action btn-edit" title="Editar">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <button class="btn-action btn-delete" title="Excluir" data-id="${rifa.id}">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    `;
                    
                    tabelaRifas.appendChild(tr);
                });
                
                // Configurar eventos de exclusão
                configurarEventosExclusao();
            }
        } else {
            utils.mostrarNotificacao('Erro ao carregar rifas', 'erro');
        }
    } catch (error) {
        console.error('Erro ao carregar rifas:', error);
        utils.mostrarNotificacao('Erro ao carregar rifas', 'erro');
    }
}

// Função para configurar formulário de criação de rifa
function configurarFormularioRifa() {
    const formRifa = document.getElementById('form-rifa');
    
    if (formRifa) {
        // Configurar preview de imagem
        const inputImagem = document.getElementById('imagem');
        const previewImagem = document.querySelector('.image-preview');
        const previewImg = previewImagem.querySelector('img');
        
        if (inputImagem && previewImagem) {
            inputImagem.addEventListener('change', (e) => {
                const file = e.target.files[0];
                
                if (file) {
                    const reader = new FileReader();
                    
                    reader.onload = (e) => {
                        previewImg.src = e.target.result;
                        previewImagem.classList.add('has-image');
                    };
                    
                    reader.readAsDataURL(file);
                } else {
                    previewImg.src = '';
                    previewImagem.classList.remove('has-image');
                }
            });
        }
        
        // Configurar envio do formulário
        formRifa.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            // Obter dados do formulário
            const titulo = document.getElementById('titulo').value;
            const descricao = document.getElementById('descricao').value;
            const valor = parseFloat(document.getElementById('valor').value);
            const totalNumeros = parseInt(document.getElementById('total-numeros').value);
            const dataSorteio = document.getElementById('data-sorteio').value;
            const status = document.getElementById('status').value;
            
            // Validar dados
            if (!titulo || !descricao || isNaN(valor) || isNaN(totalNumeros) || !dataSorteio) {
                utils.mostrarNotificacao('Preencha todos os campos obrigatórios', 'erro');
                return;
            }
            
            // Criar objeto da rifa
            const novaRifa = {
                titulo,
                descricao,
                valor,
                totalNumeros,
                dataSorteio,
                status,
                imagem: previewImg.src || 'https://placehold.co/600x400/4e54c8/ffffff?text=Rifa'
            };
            
            try {
                // Desabilitar botão durante o envio
                const btnSubmit = formRifa.querySelector('button[type="submit"]');
                btnSubmit.disabled = true;
                btnSubmit.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Salvando...';
                
                // Enviar para API
                const response = await api.criarRifa(novaRifa);
                
                if (response.success) {
                    utils.mostrarNotificacao('Rifa criada com sucesso!', 'sucesso');
                    
                    // Redirecionar para lista de rifas
                    setTimeout(() => {
                        window.location.href = 'rifas.html';
                    }, 1500);
                } else {
                    utils.mostrarNotificacao(response.message || 'Erro ao criar rifa', 'erro');
                    btnSubmit.disabled = false;
                    btnSubmit.textContent = 'Salvar Rifa';
                }
            } catch (error) {
                console.error('Erro ao criar rifa:', error);
                utils.mostrarNotificacao('Erro ao criar rifa', 'erro');
                btnSubmit.disabled = false;
                btnSubmit.textContent = 'Salvar Rifa';
            }
        });
    }
}

// Função para carregar dados para edição de rifa
async function carregarDadosEdicaoRifa() {
    try {
        // Obter ID da rifa da URL
        const idRifa = utils.obterParametroUrl('id');
        
        if (!idRifa) {
            window.location.href = 'rifas.html';
            return;
        }
        
        // Obter detalhes da rifa
        const response = await api.obterRifaDetalhes(idRifa);
        
        if (response.success) {
            const rifa = response.data;
            
            // Preencher formulário
            document.getElementById('titulo').value = rifa.titulo;
            document.getElementById('descricao').value = rifa.descricaoCompleta || rifa.descricao;
            document.getElementById('valor').value = rifa.valor;
            document.getElementById('total-numeros').value = rifa.totalNumeros;
            
            // Formatar data para o formato do input date
            const dataSorteio = new Date(rifa.dataSorteio);
            const dataFormatada = dataSorteio.toISOString().split('T')[0];
            document.getElementById('data-sorteio').value = dataFormatada;
            
            document.getElementById('status').value = rifa.status;
            
            // Exibir imagem
            const previewImagem = document.querySelector('.image-preview');
            const previewImg = previewImagem.querySelector('img');
            
            if (rifa.imagem) {
                previewImg.src = rifa.imagem;
                previewImagem.classList.add('has-image');
            }
            
            // Configurar formulário
            configurarFormularioRifa();
            
            // Atualizar título da página
            document.querySelector('.page
(Content truncated due to size limit. Use line ranges to read in chunks)